/*
 * ConfigurationTest.java
 *
 * Created on 19. November 2002, 22:37
 */
package org.jconfig;

import java.util.HashMap;

import junit.framework.TestCase;
/**
 * test cases for the for the VariableManager
 *
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class VariableManagerTest extends TestCase {
    
    
    public VariableManagerTest(String name) {
        super(name);
    }
    /**
     *  The main program for the ConfigurationTest class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(VariableManagerTest.class);
    }
    
    protected void setUp() {
    }
    
    protected void tearDown() {
    }
    
    public void testAddVars() {
        VariableManager vm = VariableManager.getInstance();
        vm.addVariable("test1", "hello", "vartest");
        vm.addVariable("test2","world","vartest");
        HashMap all = vm.getVariables("vartest");
        assertEquals(2,all.size());
    }
    
    public void testReplaceVariable() {
        VariableManager vm = VariableManager.getInstance();
        vm.addVariable("replace","me", "replace1");
        String line = "please ${replace}";
        String ret = vm.replaceVariables(line,"replace1");
        assertEquals("please me",ret);
    }
    
    public void testReplaceSeveralVariable() {
        VariableManager vm = VariableManager.getInstance();
        vm.addVariable("replace","me", "replace2");
        String line = "please ${replace} ${replace} ${replace}";
        String ret = vm.replaceVariables(line,"replace2");
        assertEquals("please me me me",ret);
    }
    
    public void testReplaceNEVariable() {
        VariableManager vm = VariableManager.getInstance();
        vm.addVariable("replace","me", "replace2");
        String line = "please ${replacer}";
        String ret = vm.replaceVariables(line,"replace2");
        assertEquals("please ${replacer}",ret);
    }
    
    public void testReplaceNECVariable() {
        VariableManager vm = VariableManager.getInstance();
        String line = "please ${replacer}";
        String ret = vm.replaceVariables(line,null);
        assertEquals("please ${replacer}",ret);
    }
    
    public void testReplaceMultiVariables() {
        VariableManager vm = VariableManager.getInstance();
        vm.addVariable("var1","val1", "replace2");
        vm.addVariable("var2","val2-${var1}", "replace2");
        String line = "please ${var2}";
        String ret = vm.replaceVariables(line,"replace2");
        assertEquals("please val2-val1",ret);
    }
    
    //
    // This section covers the env-variables
    //
    public void testReplaceEnvVariable() {
        VariableManager vm = VariableManager.getInstance();
        String line = "please ${env:NUMBER_OF_PROCESSORS}";
        String ret = vm.replaceEnvVar(line);
        assertEquals("please 1",ret);
    }
    
    public void testReplaceNEEnvVariable() {
        VariableManager vm = VariableManager.getInstance();
        String line = "please ${env:HELLO_WORLD}";
        String ret = vm.replaceEnvVar(line);
        assertEquals("please ${env:HELLO_WORLD}",ret);
    }
    
    public void testReplaceSeveralEnvVariable() {
        VariableManager vm = VariableManager.getInstance();
        String line = "please ${env:NUMBER_OF_PROCESSORS} - ${env:NUMBER_OF_PROCESSORS} - ${env:NUMBER_OF_PROCESSORS} - ${env:NUMBER_OF_PROCESSORS}";
        String ret = vm.replaceEnvVar(line);
        assertEquals("please 1 - 1 - 1 - 1",ret);
    }
    
    public void testReplaceSystemVariable() {
        VariableManager vm = VariableManager.getInstance();
        System.setProperty("HELLO","WORLD");
        String line = "please ${system:HELLO}";
        String ret = vm.replaceSystemVar(line);
        assertEquals("please WORLD",ret);
    }
    
    public void testReplaceNESystemVariable() {
        VariableManager vm = VariableManager.getInstance();
        String line = "please ${system:COOL}";
        String ret = vm.replaceSystemVar(line);
        assertEquals("please ${system:COOL}",ret);
    }
    
    public void testReplaceNoSystemVariable() {
        VariableManager vm = VariableManager.getInstance();
        String line = "please do not replace";
        String ret = vm.replaceSystemVar(line);
        assertEquals("please do not replace",ret);
    }
    
    public void testReplaceSeveralSystemVariables() {
        VariableManager vm = VariableManager.getInstance();
        System.setProperty("HELLO","WORLD");
        String line = "please ${system:HELLO}-${system:HELLO}-${system:HELLO}-${system:HELLO}";
        String ret = vm.replaceSystemVar(line);
        assertEquals("please WORLD-WORLD-WORLD-WORLD",ret);
    }
    
    /**
     * make sure we do not get back an included variable
     */
    public void testAddIncludedVariables() {
        VariableManager vm = VariableManager.getInstance();
        vm.addIncludedVariable("included_test", "hello", "vartest");
        String line = "${included_test}";
        String ret = vm.replaceVariables(line,"vartest");
        assertEquals("hello",ret);
        HashMap all = vm.getVariables("vartest");
        assertEquals(2,all.size());
        
    }
    
}
