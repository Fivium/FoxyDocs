/*
 * Created on 23.07.2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.jconfig.server;

import java.io.File;
import java.io.InputStream;

import junit.framework.TestCase;

import org.jconfig.Configuration;
import org.jconfig.handler.ConfigServerHandler;
import org.jconfig.utils.ConfigurationUtils;
/**
 * test cases for the new category object
 * these tests are an extension of the existing test
 * cases used in the ConfigurationTest
 *
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class ConfigServerTest extends TestCase {
    
    private static ConfigurationServer cs;
    private static final String URL = "jconfig://localhost:8766";
    /**
     * Constructor for CategoryTest.
     * @param arg0
     */
    public ConfigServerTest(String arg0) {
        super(arg0);        
    }
    
    public static void main(String[] args) {
        File file = ConfigurationUtils.getFileFromInputStream("config.xml");
        String documentRoot = file.getPath();
        documentRoot = documentRoot.substring(0,documentRoot.indexOf("config.xml"));
        cs = new ConfigurationServer(8766,documentRoot);        
        junit.textui.TestRunner.run(ConfigServerTest.class);
        cs.shutdown();
        System.exit(0);
    }
    
    public void setUp() throws Exception {        
    }
    
    public void testStartServer() {        
        java.net.URL jcfURL = null;
        InputStream is = null;
        try {            
            ConfigServerHandler urlHandler = new ConfigServerHandler();
            urlHandler.setURL(URL+"/config");
            Configuration config = urlHandler.load();
            assertNotNull(config);
            assertEquals("testuser",config.getProperty("USER",null,"JDBC"));
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }        
    }
    
    public void testAnotherServer() {        
        java.net.URL jcfURL = null;
        InputStream is = null;
        try {            
            ConfigServerHandler urlHandler = new ConfigServerHandler();
            urlHandler.setURL(URL+"/serverconfig");
            Configuration config = urlHandler.load();
            assertNotNull(config);
            assertEquals("serveruser",config.getProperty("USER",null,"JDBC"));
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }        
    }
    
    public void testNoFileFound() {        
        java.net.URL jcfURL = null;
        InputStream is = null;
        try {            
            ConfigServerHandler urlHandler = new ConfigServerHandler();
            urlHandler.setURL(URL+"/memyselfandi");
            Configuration config = urlHandler.load();
            fail("exception expected");
        }
        catch ( Exception e ) {            
        }        
    }
}
