package org.jconfig.server;

import java.io.InputStream;

import junit.framework.TestCase;

import org.jconfig.Configuration;
import org.jconfig.handler.ConfigServerHandler;
/**
 * NOTE: This testcase only works if you have a config server
 * running on a machine called r2d2! 
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class ExternalConfigServerTest extends TestCase {
    
    private static ConfigurationServer cs;
    private static final String URL = "jconfig://r2d2:8765";
    
    public ExternalConfigServerTest(String arg0) {
        super(arg0);        
    }
        
    public void setUp() throws Exception {        
    }
    
    public void testStartServer() {        
        java.net.URL jcfURL = null;
        InputStream is = null;
        try {            
            ConfigServerHandler urlHandler = new ConfigServerHandler();
            urlHandler.setURL(URL+"/config");
            Configuration config = urlHandler.load();
            assertNotNull(config);
            assertEquals("dice",config.getProperty("USER",null,"JDBC"));
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }        
    }        
}
