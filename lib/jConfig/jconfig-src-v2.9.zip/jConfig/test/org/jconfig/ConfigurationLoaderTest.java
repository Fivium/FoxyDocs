package org.jconfig;

import junit.framework.TestCase;

public class ConfigurationLoaderTest extends TestCase {

	public void testBasicLoad() throws Exception {
		Configuration config = ConfigurationLoader.load();
		assertNotNull(config);
		// do some basic checking
		assertEquals("/MyStuff",config.getProperty("servlet_context"));
	}
	
	public void testLoadSpecific() throws Exception {
		Configuration config = ConfigurationLoader.load("mywebsite");
		assertNotNull(config);
		// do some basic checking
		assertEquals("open.gif2",config.getProperty("ui.leftnav.image.openArrow"));
	}
	
	//
	// loading from file
	//
	public void testLoadSpecificFile() throws Exception {
		Configuration config = ConfigurationLoader.loadFile("test","testdata/website_config.xml");
		assertNotNull(config);
		// do some basic checking
		assertEquals("open.gif2",config.getProperty("ui.leftnav.image.openArrow"));
	}
	
	//
	// the script part 
	//
	public void testLoadScript() throws Exception {
		Configuration config = ConfigurationLoader.loadScript("simple");
		assertNotNull(config);
		// do some basic checks
		assertEquals("world",config.getProperty("hello"));
		assertEquals("100",config.getProperty("val1",null,"mycategory"));
	}
	
	public void testLoadScriptFromFile() throws Exception {
		Configuration config = ConfigurationLoader.loadScript("test","testdata/mysimple_config.script");
		assertNotNull(config);
		// do some basic checks
		assertEquals("world",config.getProperty("hello"));
		assertEquals("100",config.getProperty("val1",null,"mycategory"));
	}
}
