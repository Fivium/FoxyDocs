/*
 * ConfigurationTest.java
 *
 * Created on 19. November 2002, 22:37
 */
package org.jconfig;

import junit.framework.TestCase;

import org.jconfig.event.PropertyChangedEvent;
import org.jconfig.event.PropertyListener;
import org.jconfig.parser.DefaultConfigParser;
/**
 * test cases for the for the configuration
 *
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class ConfigurationTest extends TestCase implements PropertyListener {
    
    private Configuration cfg;
    public ConfigurationTest(String name) {
        super(name);
    }
    /**
     *  The main program for the ConfigurationTest class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(ConfigurationTest.class);
    }
    
    protected void setUp() {
        System.setProperty("jconfig.parser", DefaultConfigParser.class.getName());
        cfg = new DefaultConfiguration("ConfigurationTest");
        assertNotNull(cfg);
    }
    
    protected void tearDown() {
    }
    
    public void testGetAllCategoryNames() {
        String[] names = cfg.getCategoryNames();
        assertEquals(1,names.length);
        assertEquals("general",names[0]);
    }
    
    public void testSetCategory2() {
        cfg.setCategory("test");
        String[] names = cfg.getCategoryNames();
        assertEquals(2,names.length);
    }
    
    public void testAddMainCategory() {
        cfg.setCategory("test",true);
        String[] names = cfg.getCategoryNames();
        assertEquals(2,names.length);
        String main = cfg.getMainCategoryName();
        assertEquals("test",main);
    }
    
    public void testRemoveCategory() {
        cfg.setCategory("test");
        String[] names = cfg.getCategoryNames();
        assertEquals(2,names.length);
        cfg.removeCategory("test");
        names = cfg.getCategoryNames();
        assertEquals(1,names.length);
    }
    
    public void testGetNumberOfCategories() {
        cfg.setCategory("test");
        int count = cfg.getNumberOfCategories();
        assertEquals(2,count);
    }
    
    public void testSetAndGetExistingPropertyForMainCategory() {
        cfg.setProperty("testName","testValue");
        String prop = cfg.getProperty("testName");
        assertEquals("testValue",prop);
    }
    
    public void testGetNonExistingPropertyForMainCategory() {
        String prop = cfg.getProperty("nonExisting");
        assertEquals(null,prop);
    }
    
    public void testGetNonExistingPropertyWithDefaultForMainCategory() {
        String prop = cfg.getProperty("nonExisting","default");
        assertEquals("default",prop);
    }
    
    public void testSetAndGetExistingPropertyForNonMainCategory() {
        cfg.setCategory("test");
        cfg.setProperty("testName","testValue","test");
        String prop = cfg.getProperty("testName",null,"test");
        assertEquals("testValue",prop);
    }
    
    public void testGetNonExistingPropertyForNonMainCategory() {
        cfg.setCategory("test");
        String prop = cfg.getProperty("testName",null,"test");
        assertEquals(null,prop);
    }
    
    public void testGetNonExistingPropertyWithDefaultForNonMainCategory() {
        cfg.setCategory("test");
        String prop = cfg.getProperty("testName","default","test");
        assertEquals("default",prop);
    }
    
    public void testGetNonExistingPropertyWithInheritance() {
        cfg.setCategory("test");
        cfg.setProperty("upperTest","value");
        String prop = cfg.getProperty("upperTest",null,"test");
        assertEquals("value",prop);
    }
    
    public void testGetIntProperty() {
        cfg.setCategory("test");
        cfg.setProperty("intValue","1","test");
        int prop = cfg.getIntProperty("intValue",100,"test");
        assertEquals(1,prop);
        Category category = cfg.getCategory("test");
        assertEquals(prop, category.getIntProperty("intValue",100));
    }
    
    public void testGetBooleanProperty() {
        cfg.setCategory("test");
        cfg.setProperty("booleanValue","true","test");
        boolean prop = cfg.getBooleanProperty("booleanValue",true,"test");
        assertEquals(true,prop);
    }
    
    public void testGetLongProperty() {
        cfg.setCategory("test");
        cfg.setProperty("longValue","327681","test");
        long prop = cfg.getLongProperty("longValue",100000,"test");
        assertEquals(327681,prop);
    }
    
    public void testGetDoubleProperty() {
        cfg.setCategory("test");
        cfg.setProperty("doubleValue","32.43","test");
        double prop = cfg.getDoubleProperty("doubleValue",1.0,"test");
        assertEquals(32.43,prop,0.0);
    }

    public void testGetCharProperty() {
        cfg.setCategory("test");
        cfg.setProperty("charValue","C","test");
        char prop = cfg.getCharProperty("charValue",'D',"test");
        assertEquals('C',prop);
    }
    
    /**
     * Testing the PropertyListener:
     * Here we add a Property, modify the Property and then
     * remove the Property to verify the PropertyChangedEvents
     */
    public void testPropertyListener() {
        MockPropListener mpl = new MockPropListener();
        cfg.addPropertyListener(mpl, "test");
        cfg.setProperty("testName","testValue","test");
        PropertyChangedEvent e = mpl.getEvent();
        assertNotNull(e);
        assertEquals("Expected property name incorrect.", "testName", e.getPropertyName());
        assertEquals("Expected new value incorrect.", "testValue", e.getNewValue());
        assertEquals("Expected event type not found", PropertyChangedEvent.PROPERTY_ADDED, e.getEventType());
        assertNull("Expected null, because this property was added!", e.getOldValue());
        // change the property!
        cfg.setProperty("testName","newTestValue","test");
        e = mpl.getEvent();
        assertNotNull(e);
        assertEquals("Expected property name incorrect.", "testName", e.getPropertyName());
        assertEquals("Expected new value incorrect.", "newTestValue", e.getNewValue());
        assertEquals("Expected event type not found", PropertyChangedEvent.PROPERTY_CHANGED, e.getEventType());
        assertEquals("Expected old value to be set!", "testValue", e.getOldValue());
        // delete the property!
        cfg.setProperty("testName",null,"test");
        e = mpl.getEvent();
        assertNotNull(e);
        assertEquals("Expected property name incorrect.", "testName", e.getPropertyName());
        assertNull("Expected new value incorrect.", e.getNewValue());
        assertEquals("Expected event type not found", PropertyChangedEvent.PROPERTY_REMOVED, e.getEventType());
        assertEquals("Expected old value to be set!", "newTestValue", e.getOldValue());
    }
    
    public void propertyChanged(PropertyChangedEvent e) {        
        assertEquals("test",e.getNewValue());
        assertEquals("testName",e.getPropertyName());
        assertEquals("testValue", e.getOldValue());
    }
    
    public void testNumberOfCategories() {
        assertEquals(1, cfg.getNumberOfCategories());
    }
    
    public void testGetConfigName() {
        Configuration config = ConfigurationManager.getConfiguration("test");
        assertNotNull(config);
        assertEquals("test",config.getConfigName());
    }
    
    public void testSetCategory() {
        Configuration config = ConfigurationManager.getConfiguration("abc");
        config.setCategory("xyz", false);
        config.setCategory("xyz", true);
        assertEquals("xyz", config.getMainCategoryName());
    }
    
    public void testSetAndGetPropertyFromNEConfig() {
        Configuration config = ConfigurationManager.getConfiguration("abcd");
        config.setProperty("hello","world");
        String val = config.getProperty("hello");
        assertEquals("world",val);
    }
    
    public void testGetArray() {
        Configuration config = ConfigurationManager.getConfiguration();
        assertNotNull(config);
        String[] ar = config.getArray("array");
        assertNotNull(ar);
        assertEquals("is",ar[0]);
        assertEquals("out",ar[3]);
        ar = config.getArray("arr",new String[]{"hello","world"});
        assertNotNull(ar);
        assertEquals("world",ar[1]);
        ar = config.getArray("complexArray",new String[]{"hello","world"},"MyApp");
        assertNotNull(ar);
        assertEquals("hello",ar[0]);
        assertEquals("MyStuff",ar[1]);
    }
    
    public void testGetPropertyNames() {
        Configuration config = ConfigurationManager.getConfiguration();
        assertNotNull(config);
        String names[] = config.getPropertyNames("I do not exist");
        assertNull(names);
    }
    
    public void testGetPropertyWithEscape() {
        Configuration config = ConfigurationManager.getConfiguration();
        assertNotNull(config);
        String val = config.getProperty("getme",null,"MyApp");
        assertNotNull(val);        
    }
    
    public void testCreated() {
        Configuration config = ConfigurationManager.getConfiguration("I am new");
        assertNotNull(config);
        assertEquals(true,config.isNew());
    }
    
    public void testCreated2() {
        Configuration config = ConfigurationManager.getConfiguration();
        assertNotNull(config);
        assertEquals(false,config.isNew());
    }
    
    public void testRename() {
    	Configuration config = ConfigurationManager.getConfiguration();
    	Category c = config.getCategory("JDBC");
    	assertNotNull(c);
    	config.renameCategory("NEWNAME","JDBC");
    	assertEquals("jdbc:mysql://localhost/iportal",config.getProperty("URL",null,"NEWNAME"));
    	assertEquals(null,config.getProperty("URL",null,"JDBC"));
    }
    
    public void testMoreThanWords() {
    	Configuration config = ConfigurationManager.getConfiguration();
    	assertEquals("words",config.getProperty("even more",null,"More than words"));
    }
}
