package org.jconfig;

import java.util.Properties;

import junit.framework.TestCase;

/**
 * 
 * @author Andreas Mecky
 * @author Terry Dye
 *
 */
public class NestedConfGetPropsTest extends TestCase {

	/**
	 * 
	 */
	public NestedConfGetPropsTest() {
		super();
	}

	/**
	 * @param arg0
	 */
	public NestedConfGetPropsTest(String arg0) {
		super(arg0);
	}

	private static final Configuration cfg = ConfigurationManager
			.getConfiguration("mywebsite");

	/**
	 * test case inspired by jConfig user Dan Barber.
	 * 
	 * http://sourceforge.net/tracker/index.php?func=detail&aid=1186049&group_id=38356&atid=421669
	 * [ 1186049 ] inheritance - getProperties() does not return children
	 */
	public void testGetProps() {

		assertEquals("mywebsite", cfg.getConfigName());
		Properties props = cfg.getProperties();
		String openArrowKey = "ui.leftnav.image.openArrow";
		assertEquals("open.gif2", cfg.getProperty(openArrowKey));
		assertEquals(cfg.getProperty(openArrowKey), props.get(openArrowKey));

	}

}
