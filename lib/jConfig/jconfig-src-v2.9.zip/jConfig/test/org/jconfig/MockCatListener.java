/*
 * Created on 24.06.2004
 * Created by crappy eclipse.
 */
package org.jconfig;

import org.jconfig.event.CategoryChangedEvent;
import org.jconfig.event.CategoryListener;

/**
 * @author Mecky
 * shoot me because I am using eclipse
 */
public class MockCatListener extends MockPropListener implements CategoryListener {

	private CategoryChangedEvent ce;	
	
	public MockCatListener() {
		
	}
	
	public void categoryChanged(CategoryChangedEvent event) {
		ce = event;
	}
		
	public CategoryChangedEvent getCategoryChangedEvent() {
		return ce;
	}
	
}
