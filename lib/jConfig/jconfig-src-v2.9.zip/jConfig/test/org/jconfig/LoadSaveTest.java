package org.jconfig;

import junit.framework.TestCase;
import java.io.File;
import org.jconfig.handler.*;
import org.jconfig.parser.DefaultConfigParser;
import org.jconfig.parser.NestedConfigParser;

/**
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 *
 */
public class LoadSaveTest extends TestCase {
    
    /**
     * Constructor for ConfigurationManagerTest.
     * @param arg0
     */
    public LoadSaveTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(LoadSaveTest.class);
    }
    
    public void setUp() throws Exception {
        System.setProperty("jconfig.parser", DefaultConfigParser.class.getName());  
    }
    
    public void testGetInstance() {
        ConfigurationManager cm = ConfigurationManager.getInstance();
        Configuration config = ConfigurationManager.getConfiguration("test_ls");
        assertNotNull(config);
        String var = config.getVariable("user.name");
        assertEquals("developer",var);    
        try {
            cm.save("test_ls");        
        }
        catch (Exception e) {
            fail("unexpected exception");
        }
        cm.removeConfiguration("test_ls");
        config = ConfigurationManager.getConfiguration("test_ls");
        assertNotNull(config);
        var = config.getVariable("user.name");
        assertEquals("developer",var);    
    }
    
    public void testLoadAndSaveConfigEscape() {
        System.setProperty("jconfig.parser", NestedConfigParser.class.getName());    
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");          
        try {
            cfg.setProperty("path1","<testme\">","addon");            
            String fileName = System.getProperty("java.io.tmpdir")+File.separator+"test_config.xml";                        
            XMLFileHandler handler = new XMLFileHandler(fileName);
            handler.store(cfg);
            Configuration new_cfg = handler.load("just_a_test");
            assertEquals("<testme\">",new_cfg.getProperty("path1",null,"addon"));            
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }
}