/*
 * Created on Feb 26, 2003
 *
 * To change this generated comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.jconfig.utils;

import java.io.IOException;

import junit.framework.TestCase;

/** 
 */
public class ExtensionGraphTest extends TestCase {
    
    /**
     * Constructor for ResourceLocatorTest.
     * @param arg0
     */
    public ExtensionGraphTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(ExtensionGraphTest.class);
    }
    
    /**
     * Test for void ResourceLocator()
     */
    public void testCheck1() throws IOException {
        ExtensionGraph eg = new ExtensionGraph();
        eg.addExtension("A","B");
        eg.addExtension("B","C");
        eg.addExtension("C","A");
        boolean ret = eg.checkDependencies("A");
        assertTrue(ret);
    }
    
    public void testCheck2() throws IOException {
        ExtensionGraph eg = new ExtensionGraph();
        eg.addExtension("A","B");        
        eg.addExtension("C","A");
        boolean ret = eg.checkDependencies("A");
        assertTrue(!ret);
    }
    
    public void testCheck3() throws IOException {
        ExtensionGraph eg = new ExtensionGraph();
        eg.addExtension("A","B");        
        eg.addExtension("B","A");
        boolean ret = eg.checkDependencies("A");
        assertTrue(ret);
    }
    
}
