/*
 * JDBCBeanHelper.java
 *
 * Created on 28. September 2004, 12:39
 */

package org.jconfig.utils;

/**
 *
 * @author  Administrator
 */
public class JDBCBeanHelper {
    
    private String URL;
    private String DRIVER;
    private String PWD;
    private String USER;
    /**
     *
     */
    public JDBCBeanHelper() {
    }
    
    /**
     * Getter for property URL.
     * @return Value of property URL.
     */
    public java.lang.String getURL() {
        return URL;
    }
    
    /**
     * Setter for property URL.
     * @param URL New value of property URL.
     */
    public void setURL(java.lang.String URL) {
        this.URL = URL;
    }
    
    /**
     * Getter for property DRIVER.
     * @return Value of property DRIVER.
     */
    public java.lang.String getDRIVER() {
        return DRIVER;
    }
    
    /**
     * Setter for property DRIVER.
     * @param DRIVER New value of property DRIVER.
     */
    public void setDRIVER(java.lang.String DRIVER) {
        this.DRIVER = DRIVER;
    }
    
    /**
     * Getter for property PWD.
     * @return Value of property PWD.
     */
    public java.lang.String getPWD() {
        return PWD;
    }
    
    /**
     * Setter for property PWD.
     * @param PWD New value of property PWD.
     */
    public void setPWD(java.lang.String PWD) {
        this.PWD = PWD;
    }
    
    /**
     * Getter for property USER.
     * @return Value of property USER.
     */
    public java.lang.String getUSER() {
        return USER;
    }
    
    /**
     * Setter for property USER.
     * @param USER New value of property USER.
     */
    public void setUSER(java.lang.String USER) {
        this.USER = USER;
    }
    
}
