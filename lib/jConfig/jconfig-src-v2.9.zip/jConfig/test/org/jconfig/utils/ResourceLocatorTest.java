/*
 * Created on Feb 26, 2003
 *
 * To change this generated comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.jconfig.utils;

import java.io.IOException;

import junit.framework.TestCase;

/**
 * @author terry
 *
 * To change this generated comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ResourceLocatorTest extends TestCase {
    
    /**
     * Constructor for ResourceLocatorTest.
     * @param arg0
     */
    public ResourceLocatorTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(ResourceLocatorTest.class);
    }
    
    /**
     * Test for void ResourceLocator()
     */
    public void testResourceLocator() throws IOException {
        ResourceLocator locator = new ResourceLocator("config.xml");
        assertNotNull(locator);
        assertEquals("config.xml",locator.getName());
    }
            
        /*
         * Test for void ResourceLocator(String)
         */
    public void testResourceLocatorString() {
    }
    
    public void testFindResource() {
    }
    
    public void testGetName() {
    }
    
    public void testGetInputStream() {
    }
    
    public void testLastModified() {
    }
    
    public void testGetDirectory() {
    }
    
        /*
         * Test for String toString()
         */
    public void testToString() {
    }
    
}
