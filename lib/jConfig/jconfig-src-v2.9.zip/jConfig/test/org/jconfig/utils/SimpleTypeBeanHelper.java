/*
 * SimpleTypeBeanHelper.java
 *
 * Created on 28. September 2004, 12:46
 */

package org.jconfig.utils;

/**
 *
 * @author  Administrator
 */
public class SimpleTypeBeanHelper {
    
    private char charValue;
    private double doubleValue;
    private int intValue;
    private long longValue;
    /**
     *
     */
    public SimpleTypeBeanHelper() {
    }
    
    /**
     * Getter for property charValue.
     * @return Value of property charValue.
     */
    public char getCharValue() {
        return charValue;
    }
    
    /**
     * Setter for property charValue.
     * @param charValue New value of property charValue.
     */
    public void setCharValue(char charValue) {
        this.charValue = charValue;
    }
    
    /**
     * Getter for property doubleValue.
     * @return Value of property doubleValue.
     */
    public double getDoubleValue() {
        return doubleValue;
    }
    
    /**
     * Setter for property doubleValue.
     * @param doubleValue New value of property doubleValue.
     */
    public void setDoubleValue(double doubleValue) {
        this.doubleValue = doubleValue;
    }
    
    /**
     * Getter for property intValue.
     * @return Value of property intValue.
     */
    public int getIntValue() {
        return intValue;
    }
    
    /**
     * Setter for property intValue.
     * @param intValue New value of property intValue.
     */
    public void setIntValue(int intValue) {
        this.intValue = intValue;
    }
    
    /**
     * Getter for property longValue.
     * @return Value of property longValue.
     */
    public long getLongValue() {
        return longValue;
    }
    
    /**
     * Setter for property longValue.
     * @param longValue New value of property longValue.
     */
    public void setLongValue(long longValue) {
        this.longValue = longValue;
    }
    
}
