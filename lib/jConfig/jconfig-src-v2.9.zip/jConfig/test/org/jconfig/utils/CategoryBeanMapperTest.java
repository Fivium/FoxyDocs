/*
 * Created on Feb 26, 2003
 *
 * To change this generated comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.jconfig.utils;

import junit.framework.TestCase;

/** 
 */
public class CategoryBeanMapperTest extends TestCase {
    
    /**
     * Constructor for ResourceLocatorTest.
     * @param arg0
     */
    public CategoryBeanMapperTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(CategoryBeanMapperTest.class);
    }
    
    public void testMapBean() {
        JDBCBeanHelper helper = new JDBCBeanHelper();
        CategoryBeanMapper.mapBean(helper,"JDBC","default");
        assertEquals("dice",helper.getUSER());
    }
    
    public void testMapBean2() {
        SimpleTypeBeanHelper helper = new SimpleTypeBeanHelper();
        CategoryBeanMapper.mapBean(helper,"simpleTypes","default");
        assertEquals('C',helper.getCharValue());
        assertEquals(1,helper.getIntValue());
        assertTrue(helper.getDoubleValue()==12.3);
        assertEquals(326781,helper.getLongValue());
    }
        
}
