/*
 * ConfigurationTest.java
 *
 * Created on 19. November 2002, 22:37
 */
package org.jconfig;

import junit.framework.TestCase;
/**
 * test cases for the for the configuration
 * 
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class ExtensibleConfigurationTest extends TestCase {
    
    private Configuration cfg;
    public ExtensibleConfigurationTest(String name) {
        super(name);
    }
    /**
     *  The main program for the ConfigurationTest class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(ExtensibleConfigurationTest.class);
    }

    protected void setUp() { 
        cfg = new ExtensibleConfiguration("Test");        
        assertNotNull(cfg);
    }
    
    protected void tearDown() {
    }
    
    public void testInheritance() {
        Category cat1 = new DefaultCategory("cat1");
        cfg.setCategory(cat1);
        cfg.setProperty("hello","world","cat1");
        Category cat2 = new DefaultCategory("cat2");
        cat2.setExtendsCategory("cat1");
        cfg.setCategory(cat2);
        String val = cfg.getProperty("hello",null,"cat2");
        assertEquals("world",val);
        val = cfg.getProperty("hello2",null,"cat2");
        assertEquals(null,val);
    }
}
