/*
 * EventTest.java
 * JUnit based test
 *
 * Created on 24. Juni 2004, 09:51
 */

package org.jconfig;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jconfig.parser.DefaultConfigParser;
/**
 *
 * @author mecky
 */
public class DirtyFlagTest extends TestCase {
    
    private Configuration cfg;
    
    public DirtyFlagTest(java.lang.String testName) {
        super(testName);
    }
    
    protected void setUp() {
        System.setProperty("jconfig.parser", DefaultConfigParser.class.getName());
        cfg = new DefaultConfiguration("DirtyFlagTest");
        assertNotNull(cfg);
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(DirtyFlagTest.class);
        return suite;
    }
    
    public void testPropertyListener() {        
        cfg.setProperty("testName","testValue","test");
        assertTrue(cfg.hasChanged());
    }
    
}
