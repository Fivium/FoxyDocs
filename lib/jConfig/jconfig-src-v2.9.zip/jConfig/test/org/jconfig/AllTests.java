package org.jconfig;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.jconfig.handler.InputStreamHandlerTest;
import org.jconfig.handler.JDBCHandlerTest;
import org.jconfig.handler.LDAPHandlerTest;
import org.jconfig.handler.PropertiesHandlerTest;
import org.jconfig.handler.ScriptHandlerTest;
import org.jconfig.handler.URLHandlerTest;
import org.jconfig.handler.XMLFileHandlerTest;
import org.jconfig.parser.CDataConfigParserTest;
import org.jconfig.parser.ConfigParserFactoryTest;
import org.jconfig.parser.InheritanceParserTest;
import org.jconfig.parser.NestedConfigCategoryTest;
import org.jconfig.parser.NestedConfigParserTest;
import org.jconfig.utils.ResourceLocatorTest;

/**
 * Finally. We put all the tests together. It's easier to verify if things went
 * wrong.
 */
public class AllTests {

	/**
	 * 
	 * @param name
	 */
	public AllTests(String name) {

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		junit.textui.TestRunner.run(AllTests.suite());
	}

	/**
	 * @return
	 */
	public static Test suite() {
		TestSuite suite = new TestSuite("Test for org.jconfig");
		// $JUnit-BEGIN$
		suite.addTest(new TestSuite(DefaultConfigurationTest.class));
		suite.addTest(new TestSuite(NestedConfGetPropsTest.class));
		suite.addTest(new TestSuite(ConfigurationTest.class));
		suite.addTest(new TestSuite(ConfigurationManagerTest.class));
		suite.addTest(new TestSuite(InputStreamHandlerTest.class));
		if (false) { // requires LDAP server. Should provide arguments over
						// command line
			suite.addTest(new TestSuite(LDAPHandlerTest.class));
		}
		suite.addTest(new TestSuite(PropertiesHandlerTest.class));
		suite.addTest(new TestSuite(XMLFileHandlerTest.class));
		suite.addTest(new TestSuite(ScriptHandlerTest.class));
		suite.addTest(new TestSuite(URLHandlerTest.class));
		suite.addTest(new TestSuite(ResourceLocatorTest.class));
		suite.addTest(new TestSuite(CategoryTest.class));
		suite.addTest(new TestSuite(VariableManagerTest.class));
		suite.addTest(new TestSuite(LoadSaveTest.class));
		suite.addTest(new TestSuite(CDataConfigParserTest.class));
		suite.addTest(new TestSuite(NestedConfigParserTest.class));
		suite.addTest(new TestSuite(ConfigParserFactoryTest.class));
		suite.addTest(new TestSuite(JDBCHandlerTest.class));
		suite.addTest(new TestSuite(IncludePropertiesTest.class));
		suite.addTest(new TestSuite(InheritanceParserTest.class));
		suite.addTest(new TestSuite(NestedConfigCategoryTest.class));
		suite.addTest(new TestSuite(InheritanceTest.class));
		// $JUnit-END$
		return suite;
	}
}
