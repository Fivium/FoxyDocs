/*
 * Created on 24.06.2004
 * Created by crappy eclipse.
 */
package org.jconfig;

import org.jconfig.event.ConfigurationChangedEvent;
import org.jconfig.event.ConfigurationListener;

/**
 * @author Mecky
 * shoot me because I am using eclipse
 */
public class MockConfListener extends MockCatListener implements ConfigurationListener {

	private ConfigurationChangedEvent cnfe;
	
	public MockConfListener() {
		
	}
	
	public void configurationChanged(ConfigurationChangedEvent evt) {
		cnfe = evt;
	}
	
	public ConfigurationChangedEvent getConfigurationChangedEvent() {
		return cnfe;
	}

}
