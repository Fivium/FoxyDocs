/*
 * Created on 23.07.2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.jconfig;

import junit.framework.TestCase;

/**
 * test cases for the new category object
 * these tests are an extension of the existing test
 * cases used in the ConfigurationTest
 * 
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class CategoryTest extends TestCase {

	private Configuration cfg;

	/**
	 * Constructor for CategoryTest.
	 * @param arg0
	 */
	public CategoryTest(String arg0) {
		super(arg0);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(CategoryTest.class);
	}

	public void testSetBooleanProperty() {
		cfg.getCategory().setBooleanProperty("myBoolean", true);
		cfg.setBooleanProperty("myBoolean", true);
		assertEquals(cfg.getCategory().getBooleanProperty("myBoolean", false), true);
		assertEquals(cfg.getBooleanProperty("myBoolean", true),cfg.getCategory().getBooleanProperty("myBoolean", false));
		assertEquals(cfg.getBooleanProperty("Boolean", true),cfg.getCategory().getBooleanProperty("Boolean", true));
		cfg.setBooleanProperty("myBoolean", false);
		assertEquals(cfg.getCategory().getBooleanProperty("myBoolean", true), false);
		
		cfg.setBooleanProperty("myBoolean", true, "xtra");
		assertEquals(cfg.getBooleanProperty("myBoolean", false, "xtra"), cfg.getCategory("xtra").getBooleanProperty("myBoolean", true));
		
	}

	public void testSetLongProperty() {
		cfg.setLongProperty("myLong", 100);
		assertEquals(cfg.getLongProperty("myLong", -1l), cfg.getCategory().getLongProperty("myLong",-2l));
		cfg.getCategory().setLongProperty("myLong", 200l);
		assertEquals(cfg.getLongProperty("myLong", -1l), cfg.getCategory().getLongProperty("myLong",-2l));
		
		cfg.setLongProperty("myLong", 200, "xtra");
		assertEquals(cfg.getLongProperty("myLong", -1l, "xtra"), cfg.getCategory("xtra").getLongProperty("myLong",-2l));
	}
	
	public void testSetIntProperty() {
		cfg.setIntProperty("key", 100);
		assertEquals(cfg.getIntProperty("key", -1), cfg.getCategory().getIntProperty("key",-2));
		cfg.getCategory().setIntProperty("key", 200);
		assertEquals(cfg.getIntProperty("key", -1), cfg.getCategory().getIntProperty("key",-2));

		cfg.setIntProperty("intKey", 200, "xtra");
		assertEquals(cfg.getIntProperty("intKey", -1, "xtra"), cfg.getCategory("xtra").getIntProperty("intKey",-2));
	}
	
	public void testSetCharProperty() {
		cfg.setCharProperty("key", 'x');
		assertEquals(cfg.getCharProperty("key", 'a'), cfg.getCategory().getCharProperty("key",'b'));
		cfg.getCategory().setCharProperty("key", 'y');
		assertEquals(cfg.getCharProperty("key", 'a'), cfg.getCategory().getCharProperty("key",'b'));

		cfg.setCharProperty("key", 'x', "doobie");
		assertEquals(cfg.getCharProperty("key", 'a', "doobie"), cfg.getCategory("doobie").getCharProperty("key",'b'));
	}
	
	public void testSetDoubleProperty() {
		cfg.setDoubleProperty("key", 100.987d);
		assertEquals(cfg.getDoubleProperty("key", -1), cfg.getCategory().getDoubleProperty("key", -2), 0d);
		cfg.getCategory().setDoubleProperty("key", 200.987d);
		assertEquals(cfg.getDoubleProperty("key", -1), cfg.getCategory().getDoubleProperty("key",-2), 0d);

		cfg.setDoubleProperty("key", 100.987d, "catdog");
		assertEquals(cfg.getDoubleProperty("key", -1, "catdog"), cfg.getCategory("catdog").getDoubleProperty("key", -2), 0d);
	}
	
	public void testGetIntWithVar() {
		cfg.setProperty("ival","${intvar}123");
		int val = cfg.getIntProperty("ival",-1);
		assertEquals(11123,val);
	}
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		cfg = new DefaultConfiguration("Test");        
		assertNotNull(cfg);
		VariableManager vm = VariableManager.getInstance();    
        vm.addVariable("intvar","11", "Test");
	}

}
