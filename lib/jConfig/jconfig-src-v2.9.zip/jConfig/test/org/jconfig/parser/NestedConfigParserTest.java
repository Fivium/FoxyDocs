package org.jconfig.parser;

import java.io.File;

import junit.framework.TestCase;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManager;
import org.jconfig.handler.XMLFileHandler;
/**
 * Testcase for testig the NestedConfiguration
 *
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class NestedConfigParserTest extends TestCase {
    
    public NestedConfigParserTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(NestedConfigParserTest.class);
    }
    
    public void tearDown() throws Exception {
        System.setProperty("jconfig.parser","org.jconfig.parser.DefaultConfigParser");        
    }
    
    public void testParseNestedConfig() {
        System.setProperty("jconfig.parser","org.jconfig.parser.NestedConfigParser");
        Configuration config = ConfigurationManager.getConfiguration("nested");
        String next = config.getProperty("inner",null,"inner/myinner");
        assertEquals("value",next);
        next = config.getProperty("hello",null,"inner/myinner/moreinner");
        assertEquals("universe",next);
        next = config.getProperty("text",null,"inner/2");
        assertNull(next);
        next = config.getProperty("special",null,"inner/2");
        assertEquals("one",next);        
        config.setProperty("max","10000","inner/myinner/moreinner");
        next = config.getProperty("max",null,"inner/myinner/moreinner");
        assertEquals("10000",next);
        next = config.getProperty("vartest","not set","inner/myinner/moreinner");
        assertEquals("VarValue-is here",next);
        config.removeProperty("max","inner/myinner/moreinner");
        next = config.getProperty("max",null,"inner/myinner/moreinner");
        assertEquals(null,next);
    }
    
     public void testCreateNewTopLevelCategory() {
        System.setProperty("jconfig.parser","org.jconfig.parser.NestedConfigParser");
        Configuration config = ConfigurationManager.getConfiguration("nested");
        config.setProperty("another", "value", "brand/new");     
        assertEquals("value",config.getProperty("another",null,"brand/new"));  
     }
     
     public void testCreateNewNestedCategory() {
        System.setProperty("jconfig.parser","org.jconfig.parser.NestedConfigParser");
        Configuration config = ConfigurationManager.getConfiguration("nested");
        config.setProperty("hello", "new", "inner/myinner/new");        
        assertEquals("new",config.getProperty("hello",null,"inner/myinner/new"));     
    }
    
    public void testParseSaveLoadNestedConfig() {
        System.setProperty("jconfig.parser","org.jconfig.parser.NestedConfigParser");        
        try {
            XMLFileHandler fileHandler = new XMLFileHandler();
            String filename = System.getProperty("java.io.tmpdir")+"test_config.xml";            
            File file = new File(filename);
            fileHandler.setFile(file);
            Configuration config = ConfigurationManager.getConfiguration("nested");                        
            fileHandler.store(config);
            config = fileHandler.load(file, "MyTest");
            String next = config.getProperty("inner",null,"inner/myinner");
            assertEquals("value",next);
            next = config.getProperty("hello",null,"inner/myinner/moreinner");
            assertEquals("universe",next);
            next = config.getProperty("text",null,"inner/2");
            assertNull(next);
            next = config.getProperty("special",null,"inner/2");
            assertEquals("one",next);   
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }
    
}
