/*
 * Created on 23.07.2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.jconfig.parser;

import java.io.File;

import junit.framework.TestCase;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManager;
import org.jconfig.handler.XMLFileHandler;
/**
 * test cases for the new category object
 * these tests are an extension of the existing test
 * cases used in the ConfigurationTest
 *
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class CDataConfigParserTest extends TestCase {
    
    public CDataConfigParserTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(CDataConfigParserTest.class);
    }
    
    public void testParseCDataConfig() {
        System.setProperty("jconfig.parser","org.jconfig.parser.CDataConfigParser");
        Configuration config = ConfigurationManager.getConfiguration("advanced");
        String world = config.getProperty("hello");
        assertEquals("world",world);
        String escape = config.getProperty("escapetest");
        assertEquals(escape,"this\nis\nme");
        String special = config.getProperty("special",null,"inner");
        assertEquals("one",special);
        System.setProperty("jconfig.parser","org.jconfig.parser.DefaultConfigParser");
    }
    
    public void _testParseSaveLoadNestedConfig() {
        System.setProperty("jconfig.parser","org.jconfig.parser.CDataConfigParser");
        try {
            XMLFileHandler fileHandler = new XMLFileHandler();
            String filename = System.getProperty("java.io.tmpdir")+"cdata_test_config.xml";            
            File file = new File(filename);
            fileHandler.setFile(file);
            Configuration config = ConfigurationManager.getConfiguration("advanced");
            fileHandler.store(config);
            config = fileHandler.load(file, "MyTest");
            String special = config.getProperty("special",null,"inner");
            assertEquals("one",special);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }
    
}
