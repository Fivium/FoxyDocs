package org.jconfig.parser;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

import junit.framework.TestCase;
import org.jconfig.*;
/**
 * Testcase for testig the NestedConfiguration
 *
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class NestedConfigCategoryTest extends TestCase {
    
    public NestedConfigCategoryTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(NestedConfigCategoryTest.class);
    }
    
    public void tearDown() throws Exception {
        System.setProperty("jconfig.parser","org.jconfig.parser.DefaultConfigParser");
    }
    
    public void testGetCategoryNames() {
        ConfigurationManager.getInstance().removeConfiguration("nested");
        System.setProperty("jconfig.parser","org.jconfig.parser.NestedConfigParser");
        Configuration config = ConfigurationManager.getConfiguration("nested");
        String[] expected = {"inner","inner/myinner","inner/myinner/moreinner","MyApp","includeTest","general"};
        String[] names = config.getCategoryNames();
        Map map = new HashMap();
        for( int i = 0; i < names.length;i++ ) {
            map.put(names[i], names[i]);
        }
        for ( int i = 0; i < names.length;i++) {
            assertNotNull(map.get(expected[i]));
            NestedCategory nc = (NestedCategory)config.getCategory(names[i]);
            Collection children = nc.getChildCategories();
            if ( names[i].equals("inner")) {
                assertEquals(1,children.size());
            }
            Iterator it = children.iterator();
            while ( it.hasNext() ) {
                NestedCategory child = (NestedCategory)it.next();                
            }
        }         
    }      
    
    public void testGetCategory() {
        ConfigurationManager.getInstance().removeConfiguration("nested");
        System.setProperty("jconfig.parser","org.jconfig.parser.NestedConfigParser");
        Configuration config = ConfigurationManager.getConfiguration("nested");        
        NestedCategory nc = (NestedCategory)config.getCategory("inner/myinner/moreinner");
        assertNotNull(nc);
        assertEquals("moreinner",nc.getCategoryName());
    }      
}
