package org.jconfig.parser;

import junit.framework.TestCase;
import org.jconfig.Configuration;
import org.jconfig.ConfigurationManager;
/**
 * Testcase for testig the NestedConfiguration
 *
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class InheritanceParserTest extends TestCase {
    
    public InheritanceParserTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(InheritanceParserTest.class);
    }
    
    public void setUp() throws Exception {
        //ConfigurationManager.getInstance().removeConfiguration("e1");
        //ConfigurationManager.getInstance().removeConfiguration("e3");
        System.setProperty("jconfig.parser","org.jconfig.parser.NestedConfigParser");
    }
    
    public void tearDown() throws Exception {
        System.setProperty("jconfig.parser","org.jconfig.parser.DefaultConfigParser");
    }
    
    public void testParseConfig() {
        Configuration config = ConfigurationManager.getConfiguration("e1");
        String next = config.getProperty("inner",null,"inner/myinner");
        assertEquals("value",next);
        next = config.getProperty("hello",null,"inner/myinner/moreinner");
        assertEquals("universe",next);
        next = config.getProperty("text",null,"inner/2");
        assertNull(next);
        next = config.getProperty("special",null,"inner/2");
        assertEquals("two",next);
        config.setProperty("max","10000","inner/myinner/moreinner");
        next = config.getProperty("max",null,"inner/myinner/moreinner");
        assertEquals("10000",next);
        next = config.getProperty("vartest","not set","inner/myinner/moreinner");
        assertEquals("VarValue-is here",next);
        config.removeProperty("max","inner/myinner/moreinner");
        next = config.getProperty("max",null,"inner/myinner/moreinner");
        assertEquals(null,next);
    }
    
    public void testParseCircularDependency() {
        Configuration config2 = ConfigurationManager.getConfiguration("e1");
        Configuration config = ConfigurationManager.getConfiguration("e3");
        String next = config.getProperty("inner",null,"inner/myinner");
        // should not be set since the base config was not set
        System.out.println("next:"+next);
        assertNull(next);
    }
}
