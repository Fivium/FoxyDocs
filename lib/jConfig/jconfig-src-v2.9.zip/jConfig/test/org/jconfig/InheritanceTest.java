/*
 * ConfigurationTest.java
 *
 * Created on 19. November 2002, 22:37
 */
package org.jconfig;

import java.io.File;
import org.jconfig.handler.XMLFileHandler;
import junit.framework.TestCase;
import java.util.Properties;
import org.jconfig.parser.NestedConfigParser;
/**
 * test cases for the for the configuration
 *
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class InheritanceTest extends TestCase {
        
    public InheritanceTest(String name) {
        super(name);
    }
    /**
     *  The main program for the ConfigurationTest class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(InheritanceTest.class);
    }
    
    protected void setUp() {
        System.setProperty("jconfig.parser", NestedConfigParser.class.getName());    
        ConfigurationManager.getInstance().removeConfiguration("inheritance");
        ConfigurationManager.getInstance().removeConfiguration("base");
    }
    
    protected void tearDown() {
    }
    
    public void testGetAllCategoryNames() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        String[] names = cfg.getCategoryNames();
        assertEquals(10,names.length);        
    }
    
    public void testGetNumberOfCategories() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        int cnt = cfg.getNumberOfCategories();
        assertEquals(10,cnt);        
    }
    
    public void testGetProperties() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        Properties props = cfg.getProperties(); 
        assertEquals(6,props.size());
    }
    
    public void testGetIntProperty() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        int port = cfg.getIntProperty("port",-1,"testme");
        assertEquals(8080,port);
    }
    
    public void testGetIntProperty2() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        int number = cfg.getIntProperty("number",-1);
        assertEquals(100,number);
    }
    
    public void testGetLongProperty() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        long number = cfg.getLongProperty("longValue",-1,"simpleTypes");
        assertEquals(326781,number);
    }
    
    public void testGetBooleanProperty() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        boolean ret = cfg.getBooleanProperty("booleanValue",false,"simpleTypes");
        assertTrue(ret);
    }
    
    public void testGetCharProperty() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        char n = cfg.getCharProperty("charValue",'N',"simpleTypes");
        assertEquals(n,'C');
    }
    
    public void testGetDoubleProperty() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        double d = cfg.getDoubleProperty("doubleValue",-1.0,"simpleTypes");
        assertTrue((d==12.3));
    }
    
    public void testGetVar() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        String var = cfg.getProperty("varValue","not set","simpleTypes");
        assertEquals("VarValue",var);
    }
    
    public void testGetArray() {
        Configuration config = ConfigurationManager.getConfiguration("inheritance");
        String[] ar = config.getArray("array");
        assertNotNull(ar);
        assertEquals("is",ar[0]);
        assertEquals("out",ar[3]);
        ar = config.getArray("arr",new String[]{"hello","world"});
        assertNotNull(ar);
        assertEquals("world",ar[1]);
        ar = config.getArray("complexArray",new String[]{"hello","world"},"MyApp");
        assertNotNull(ar);
        assertEquals("hello",ar[0]);
        assertEquals("world",ar[1]);
    }
    
    public void _testSaveConfig() {
        Configuration cfg = ConfigurationManager.getConfiguration("inheritance");
        try {
            String fileName = System.getProperty("java.io.tmpdir")+File.separator+"test_config.xml";                        
            XMLFileHandler handler = new XMLFileHandler(fileName);
            handler.store(cfg);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }
    
}
