package org.jconfig;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * This TestCase was orignally written by Milind Nirgun. It has been extended
 * to cover parallel methods that should deliver the same results.
 * s
 * @author Milind Nirgun
 * @author Terry Dye
 *
 */
public class DefaultConfigurationTest extends TestCase 
{

	private static final Configuration config = ConfigurationManager.getConfiguration("env");

	/**
	 * @param name
	 */
	public DefaultConfigurationTest( String name )
	{
		super( name );
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		TestRunner.run( suite () );
	}

	/**
	 * @return
	 */
	public static TestSuite suite()
	{
		TestSuite suite = new TestSuite();
		suite.addTest( new DefaultConfigurationTest( "testGetPropertyKey1" ) );
		suite.addTest( new DefaultConfigurationTest( "testGetPropertyKey2" ) );
		suite.addTest( new DefaultConfigurationTest( "testGetPropertyKey3" ) );
		suite.addTest( new DefaultConfigurationTest( "testGetPropertyKey4" ) );
		return suite;
	}
	
	/**
	 * works without patch
	 */
	public void testGetPropertyKey1()
	{
		assertEquals( "Failed to get value for key1 from general category", "key1 value", config.getProperty("key1"));
		assertEquals( "Failed to get value for key1 from general category (env.general.key1)", "key1 value", config.getCategory().getProperty("key1"));
		
	}
	
	/**
	 * needs patch to work
	 */
	public void testGetPropertyKey2() {
		assertEquals( "Failed to get key2", "key2 value", config.getProperty("key2", null, "A"));
		assertEquals( "Failed to get key2", "key2 value", config.getCategory("A").getProperty("key2"));
	}

	/**
	 * works without patch
	 */
	public void testGetPropertyKey3() {
		assertEquals( "Failed to get key3", "key3 value", config.getProperty("key3", null, "B"));
		assertEquals( "Failed to get key3", "key3 value", config.getCategory("B").getProperty("key3"));
	}

	/**
	 * works without patch
	 */
	public void testGetPropertyKey4() {
		assertEquals( "Failed to get key4", "key4 value", config.getProperty("key4"));
		assertEquals( "Failed to get key4", "key4 value", config.getCategory().getProperty("key4"));
	}
	
}
