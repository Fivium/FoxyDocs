/*
 * Created on 28.06.2004
 * Created by crappy eclipse.
 */
package org.jconfig.error;

/**
 * @author Mecky
 * shoot me because I am using eclipse
 */
public class MockErrorHandler implements ErrorHandler {

	private String msg;
	private Throwable thrown;
	
	public MockErrorHandler() {
		
	}
	/* (non-Javadoc)
	 * @see org.jconfig.error.ErrorHandler#reportError(java.lang.String)
	 */
	public void reportError(String message) {
		reportError(message,null);
	}

	/* (non-Javadoc)
	 * @see org.jconfig.error.ErrorHandler#reportError(java.lang.String, java.lang.Throwable)
	 */
	public void reportError(String message, Throwable thrown) {
		msg = message;
		this.thrown = thrown;
		
	}
	
	public void reset() {
		msg = null;
		thrown = null;
	}
	/**
	 * @return Returns the msg.
	 */
	public String getMsg() {
		return msg;
	}
	/**
	 * @return Returns the thrown.
	 */
	public Throwable getThrown() {
		return thrown;
	}
}
