/*
 * Created on 28.06.2004
 * Created by crappy eclipse.
 */
package org.jconfig.error;

import junit.framework.TestCase;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManager;

/**
 * @author Mecky
 * shoot me because I am using eclipse
 */
public class ErrorHandlerTest extends TestCase {
	
	
	public ErrorHandlerTest(String arg0) {
		super(arg0);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ErrorHandlerTest.class);
	}
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testErrorHandler() {
		System.setProperty("jconfig.errorhandler","org.jconfig.error.MockErrorHandler");
		Configuration cfg = ConfigurationManager.getConfiguration("I do not exist");
		assertNotNull(cfg);
		MockErrorHandler handler = (MockErrorHandler)ErrorReporter.getErrorHandler();
		assertEquals("Problem while trying to read configuration. Returning new configuration.",handler.getMsg());		
		System.setProperty("jconfig.errorhandler","blabla");
	}
}
