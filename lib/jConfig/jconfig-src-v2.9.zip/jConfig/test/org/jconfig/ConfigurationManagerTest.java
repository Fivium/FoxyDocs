package org.jconfig;

import junit.framework.TestCase;

import org.jconfig.handler.ConfigurationHandler;
import org.jconfig.handler.PropertiesFileHandler;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 *
 */
public class ConfigurationManagerTest extends TestCase {
    
    /**
     * Constructor for ConfigurationManagerTest.
     * @param arg0
     */
    public ConfigurationManagerTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(ConfigurationManagerTest.class);
    }
    
    public void testGetInstance() {
        ConfigurationManager cm = ConfigurationManager.getInstance();
        assertNotNull(cm);
    }
    
        /*
         * Test for Configuration getConfiguration()
         */
    public void testGetConfiguration() {
        Configuration config = ConfigurationManager.getConfiguration();
        assertNotNull(config);
    }
    
        /*
         * Test for Configuration getConfiguration(String)
         */
    public void testGetConfigurationString() {
        Configuration configXyz = ConfigurationManager.getConfiguration("xyz");
        Configuration configAbc = ConfigurationManager.getConfiguration("abc");
        assertNotNull(configXyz);
        assertNotNull(configAbc);
    }
    
    
    /**
     * Method testSaveConfigurationHandlerConfiguration.
     */
        /*
         * Test for void save(ConfigurationHandler, Configuration)
         */
    public void testSaveConfigurationHandlerConfiguration() {
    }
    
    /**
     * Method testReload.
     */
    public void testReload() {
        Configuration config = ConfigurationManager.getConfiguration("default");
    }
    
    /**
     * Method testSaveString.
     */
        /*
         * Test for void save(String)
         */
    public void testSaveString() {
    }
    
    /**
     * Method testAddPropertyListener.
     */
    public void testAddPropertyListener() throws Exception {
        ConfigurationHandler ish = new PropertiesFileHandler("jconfig.properties");
        
        ConfigurationManager.getInstance().load(ish,"default");
        ConfigurationManager manager = ConfigurationManager.getInstance();
    }
    
    /**
     * Method testFileChanged.
     */
    // This is tested in the ConfigurationTest
    public void _testFileChanged() {
        Configuration config = ConfigurationManager.getConfiguration();
        WaitingHelper helper = new WaitingHelper();
        helper.run();
        config.getProperty("SOMETHING", "SOMETHING");
        // here where's you need to do something to the file
        // and verify that the changes were accepted. Perhaps it would
        // be easier to have two files, and just copy over the watched
        // file for testing.
    }
    
    /**
     * Method testInputStreamHandler.
     * @throws Exception
     */
    public void testInputStreamHandler() throws Exception {
        ConfigurationHandler ish = new PropertiesFileHandler("jconfig.properties");
        
        Configuration config = ConfigurationManager.getConfiguration("default");
        ConfigurationManager.getInstance().load(ish,"default");
        assertEquals("8080",config.getProperty("http.proxyPort"));
        assertEquals("192.168.3.1",config.getProperty("http.proxyHost"));
    }
    
    public void testGetConfigurationWithName() {
        Configuration configXyz = ConfigurationManager.getConfiguration("test");
        assertNotNull(configXyz);
        assertTrue(!configXyz.isNew());
        String special = configXyz.getProperty("special");
        assertEquals("one",special);
    }
    
    public void testGetConfigurationNames() {
        String[] names = ConfigurationManager.getInstance().getConfigurationNames();
        Map map = new HashMap();
        for (int i = 0; i < names.length; i++) {
            map.put(names[i], names[i]);
        }
        assertNotNull(names);
        assertNotNull(map.get("default"));
        assertNotNull(map.get("test"));
    }
}
/*
 * jUnit doesn't like you to put the thread on hold, 
 * and I have no idea how to get around this problem.
 * so we set things into a very long loop. hopefully
 * it is enough time to test what we want.
 * 
 */
class WaitingHelper implements Runnable {
    private boolean state = true;
    /**
     * @see java.lang.Runnable#run()
     */
    public void run() {
        int i = 0;
        while(i<999999999) {
            i++;
        }
    }
    
}