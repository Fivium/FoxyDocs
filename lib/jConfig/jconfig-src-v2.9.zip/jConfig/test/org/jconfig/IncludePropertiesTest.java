/*
 * ConfigurationTest.java
 *
 * Created on 19. November 2002, 22:37
 */
package org.jconfig;

import junit.framework.TestCase;

import org.jconfig.parser.DefaultConfigParser;
/**
 * test cases for the for the configuration
 *
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class IncludePropertiesTest extends TestCase {
    
    public IncludePropertiesTest(String name) {
        super(name);
    }
    /**
     *  The main program for the ConfigurationTest class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(IncludePropertiesTest.class);
    }
    
    protected void setUp() {
        ConfigurationManager.getInstance().removeConfiguration("default");
        System.setProperty("jconfig.parser", DefaultConfigParser.class.getName());        
    }
    
    protected void tearDown() {
    }
    
    public void testGetInclude() {
        Configuration config = ConfigurationManager.getConfiguration();
        String val = config.getProperty("varprop1",null,"includeTest");
        assertNotNull(val);
        assertEquals("value1",val);
    }
}
