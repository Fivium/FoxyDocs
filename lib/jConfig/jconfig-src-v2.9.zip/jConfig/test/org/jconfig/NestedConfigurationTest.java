/*
 * ConfigurationTest.java
 *
 * Created on 19. November 2002, 22:37
 */
package org.jconfig;

import junit.framework.TestCase;

import org.jconfig.event.PropertyChangedEvent;
import org.jconfig.event.PropertyListener;
import org.jconfig.parser.NestedConfigParser;
/**
 * test cases for the for the configuration
 *
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class NestedConfigurationTest extends TestCase implements PropertyListener {
    
    private Configuration cfg;
    public NestedConfigurationTest(String name) {
        super(name);
    }
    /**
     *  The main program for the ConfigurationTest class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(NestedConfigurationTest.class);
    }
    
    protected void setUp() {
        System.setProperty("jconfig.parser", NestedConfigParser.class.getName());
        cfg = new NestedConfiguration("ConfigurationTest");
        assertNotNull(cfg);
    }
    
    protected void tearDown() {
    }
    
    public void testGetAllCategoryNames() {
        Configuration config = ConfigurationManager.getConfiguration("nested");
        String[] names = config.getCategoryNames();        
        assertEquals(6,names.length);        
    }
    
    public void testSetCategory2() {
        cfg.setCategory("test");
        String[] names = cfg.getCategoryNames();
        assertEquals(2,names.length);
    }
    
    public void testAddMainCategory() {
        cfg.setCategory("test",true);
        String[] names = cfg.getCategoryNames();
        assertEquals(2,names.length);
        String main = cfg.getMainCategoryName();
        assertEquals("test",main);
    }
    
    public void testRemoveCategory() {
        cfg.setCategory("test");
        String[] names = cfg.getCategoryNames();
        assertEquals(2,names.length);
        cfg.removeCategory("test");
        names = cfg.getCategoryNames();
        assertEquals(1,names.length);
    }
    
    public void testGetNumberOfCategories() {
        cfg.setCategory("test");
        int count = cfg.getNumberOfCategories();
        assertEquals(2,count);
    }
    
    public void testSetAndGetExistingPropertyForMainCategory() {
        cfg.setProperty("testName","testValue");
        String prop = cfg.getProperty("testName");
        assertEquals("testValue",prop);
    }
    
    public void testGetNonExistingPropertyForMainCategory() {
        String prop = cfg.getProperty("nonExisting");
        assertEquals(null,prop);
    }
    
    public void testGetNonExistingPropertyWithDefaultForMainCategory() {
        String prop = cfg.getProperty("nonExisting","default");
        assertEquals("default",prop);
    }
    
    public void testSetAndGetExistingPropertyForNonMainCategory() {
        cfg.setCategory("test");
        cfg.setProperty("testName","testValue","test");
        String prop = cfg.getProperty("testName",null,"test");
        assertEquals("testValue",prop);
    }
    
    public void testGetNonExistingPropertyForNonMainCategory() {
        cfg.setCategory("test");
        String prop = cfg.getProperty("testName",null,"test");
        assertEquals(null,prop);
    }
    
    public void testGetNonExistingPropertyWithDefaultForNonMainCategory() {
        cfg.setCategory("test");
        String prop = cfg.getProperty("testName","default","test");
        assertEquals("default",prop);
    }
    
    public void testGetNonExistingPropertyWithInheritance() {
        cfg.setCategory("test");
        cfg.setProperty("upperTest","value");
        String prop = cfg.getProperty("upperTest",null,"test");
        assertEquals("value",prop);
    }
    
    public void testGetIntProperty() {
        cfg.setCategory("test");
        cfg.setProperty("intValue","1","test");
        int prop = cfg.getIntProperty("intValue",100,"test");
        assertEquals(1,prop);
    }
    
    public void testGetBooleanProperty() {
        cfg.setCategory("test");
        cfg.setProperty("booleanValue","true","test");
        boolean prop = cfg.getBooleanProperty("booleanValue",true,"test");
        assertEquals(true,prop);
    }
    
    public void testGetLongProperty() {
        cfg.setCategory("test");
        cfg.setProperty("longValue","327681","test");
        long prop = cfg.getLongProperty("longValue",100000,"test");
        assertEquals(327681,prop);
    }
    
    public void testGetDoubleProperty() {
        cfg.setCategory("test");
        cfg.setProperty("doubleValue","32.43","test");
        double prop = cfg.getDoubleProperty("doubleValue",1.0,"test");
        assertEquals(32.43,prop,0.0);
    }
    
    public void testGetCharProperty() {
        cfg.setCategory("test");
        cfg.setProperty("charValue","C","test");
        char prop = cfg.getCharProperty("charValue",'D',"test");
        assertEquals('C',prop);
    }
    
    public void testPropertyListener() {
        cfg.addPropertyListener(this);
        cfg.setCategory("test");
        cfg.setProperty("testName","testValue","test");
    }
    
    public void propertyChanged(PropertyChangedEvent e) {
        assertEquals("test",e.getNewValue());
        assertEquals("testName",e.getPropertyName());
        assertEquals("testValue", e.getOldValue());
    }
    
    public void testNumberOfCategories() {
        assertEquals(1, cfg.getNumberOfCategories());
    }
       
    public void testGetPropertyNamesForNECategory() {
        Configuration config = ConfigurationManager.getConfiguration("nested");
        assertNotNull(config);
        String names[] = config.getPropertyNames("I do not exist");
        assertNull(names);
    }
    
    public void testGetPropertyNames() {
        Configuration config = ConfigurationManager.getConfiguration("nested");
        assertNotNull(config);
        String names[] = config.getPropertyNames("inner/myinner/moreinner");
        assertNotNull(names);
        assertEquals(2,names.length);
    }
    
    public void testGetPropertyWithEscape() {
        Configuration config = ConfigurationManager.getConfiguration("nested");
        assertNotNull(config);
        String val = config.getProperty("getme",null,"MyApp");
        assertNotNull(val);        
    }        
    
    public void testGetIncludedProperty() {
        Configuration config = ConfigurationManager.getConfiguration("nested");
        assertNotNull(config);
        String val = config.getProperty("varprop1",null,"includeTest");
        assertNotNull(val);        
        assertEquals("value1",val);
    }        
}
