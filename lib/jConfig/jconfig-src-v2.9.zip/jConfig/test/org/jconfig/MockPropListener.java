/*
 * MockPropListener.java
 *
 * Created on 24. Juni 2004, 09:43
 */

package org.jconfig;

import org.jconfig.event.PropertyChangedEvent;
import org.jconfig.event.PropertyListener;
/**
 *
 * @author  mecky
 */
public class MockPropListener implements PropertyListener {
    
    private PropertyChangedEvent event;
    
    public MockPropListener() {
    }
    
    public void propertyChanged(PropertyChangedEvent e) {
        event = e;
    }
    
    public PropertyChangedEvent getEvent() {
        return event;
    }
    
}
