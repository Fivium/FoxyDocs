/*
 * LDAPHandlerTest.java
 * JUnit based test
 *
 * Created on 8. Dezember 2002, 23:45
 */

package org.jconfig.handler;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jconfig.Configuration;

/**
 *
 * @author Administrator
 */
public class LDAPHandlerTest extends TestCase {
    
    public LDAPHandlerTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(LDAPHandlerTest.class);
        return suite;
    }
    
    public void testLoad() {
        LDAPHandler ldapHandler = new LDAPHandler();
        try {
            Configuration config = ldapHandler.load("so what");
            assertNotNull(config);
            String[] cats = config.getCategoryNames();
            //assertEquals(2,cats.length);
            for ( int i = 0; i < cats.length;i++) {
                System.out.println("CAT["+i+"]:"+cats[i]);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unpected exception");
        }
    }
    
}
