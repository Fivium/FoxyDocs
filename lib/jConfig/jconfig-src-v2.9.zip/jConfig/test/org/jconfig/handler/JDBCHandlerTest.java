package org.jconfig.handler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import junit.framework.TestCase;

import org.jconfig.Category;
import org.jconfig.Configuration;
import org.jconfig.ConfigurationManager;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.VariableManager;
import org.jconfig.utils.ResourceLocator;
/**
 * @author Terry Dye <terry dot dye at xcom dot de>
 */
public class JDBCHandlerTest extends TestCase {
    
    /**
     * Constructor for JDBCHandlerTest.
     * @param arg0
     */
    public JDBCHandlerTest(String arg0) {
        super(arg0);
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(JDBCHandlerTest.class);
    }
    
        /*
         * @see TestCase#setUp()
         */
    protected void setUp() throws Exception {        
        prepareDB();
        
    }
    
        /*
         * @see TestCase#tearDown()
         */
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    
    public void testLoad() throws ConfigurationManagerException {
        ConfigurationHandler handler = new MockJDBCHandler();
        // first we try to load a <null> JDBCHandler
        try {
            handler.load(null);
            fail("Should have thrown an exception");
        } catch (ConfigurationManagerException e) {
            assertEquals("Configuration name cannot be <null>", e.getMessage());
            // this was expected
        }
        // next we try an empty String
        try {
            handler.load("");
            fail("Should have thrown an exception");
        } catch (ConfigurationManagerException e) {
            assertEquals("Configuration name not valid. Empty String not allowed", e.getMessage());
            // this was expected
        }
        // next we check for valid jdbc settings
        Configuration configuration = handler.load("test_ls");
        assertNotNull("JDBC Configuration could not be loaded.", configuration);
        Category news = configuration.getCategory("news");
        assertNotNull("Category was <null>. This cannot be true.", news);
        assertEquals("Expected value was wrong.", "10", news.getProperty("count"));
        Category general = configuration.getCategory("general");
        assertNotNull("Category was <null>. This cannot be true", general);
        assertEquals("Expected value was wrong.", "JDBC is cool", general.getProperty("description"));
    }
    
    public void testLoadAndSave() {        
        Configuration cfg = getConfig();        
        assertNotNull(cfg);                
        Category news = cfg.getCategory("news");
        assertNotNull("Category was <null>. This cannot be true.", news);
        assertEquals("Expected value was wrong.", "10", news.getProperty("count"));        
    }
    
    /**
     * make sure we have loaded all variables
     */
    public void testVariables() {                
        String var = VariableManager.getInstance().getVariable("test_ls","user.name");
        assertEquals("developer",var);
        var = VariableManager.getInstance().getVariable("test_ls","my.offset");
        assertEquals("100",var);
        var = VariableManager.getInstance().getVariable("test_ls","app.name");
        assertEquals("MyStuff",var);
        var = VariableManager.getInstance().getVariable("test_ls","my.path");
        assertEquals("/usr/development/mystuff/etc",var);
    }
    
    public void testReplaceVariable() {                
        Configuration cfg = getConfig();        
        String var = cfg.getProperty("workflow_file");
        assertNotNull(var);
        assertEquals(var,"/usr/development/mystuff/etc/workflow.xml");        
    }
    
    public void testRemoveAndReplaceVariable() {                
        Configuration cfg = getConfig();        
        String var = cfg.getProperty("workflow_file");
        assertNotNull(var);
        assertEquals(var,"/usr/development/mystuff/etc/workflow.xml");
        VariableManager.getInstance().removeVariable("my.path","test_ls");
        try {
            ConfigurationHandler handler = new MockJDBCHandler();        
            handler.store(cfg);            
        } catch (ConfigurationManagerException e) {            
        }        
        cfg = getConfig();
        var = cfg.getProperty("workflow_file");
        assertNotNull(var);        
        assertEquals(var,"${my.path}/workflow.xml");
    }
    
    public void testRemoveProperty() {                
        Configuration cfg = getConfig();        
        cfg.removeProperty("delete");
        try {
            ConfigurationHandler handler = new MockJDBCHandler();        
            handler.store(cfg);            
        } catch (ConfigurationManagerException e) {            
        }
        
        cfg = getConfig();
        assertNull(cfg.getProperty("delete"));
    }
    
    public void testAddProperty() {                
        Configuration cfg = getConfig();        
        cfg.setProperty("hello","world","new.one");
        try {
            ConfigurationHandler handler = new MockJDBCHandler();        
            handler.store(cfg);            
        } catch (ConfigurationManagerException e) {            
        }
        
        cfg = getConfig();
        assertNotNull(cfg.getProperty("hello",null,"new.one"));
    }
    
    private Configuration getConfig() {
        ConfigurationManager.getInstance().removeConfiguration("test_ls");
        ConfigurationHandler handler = new MockJDBCHandler();        
        Configuration cfg = null;
        try {
             cfg = handler.load("test_ls");    
        } catch (ConfigurationManagerException e) {            
            e.printStackTrace();
            fail("unexpected exception");
        }
        assertNotNull(cfg);
        return cfg;
    }
    
    private void prepareDB() {
        try {

            File src = new ResourceLocator("configDB.script.org").getFile();
            File dst = new ResourceLocator("configDB.script").getFile();
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(dst);

            // Transfer bytes from in to out
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unable to copy original database");
        }
    }
}
