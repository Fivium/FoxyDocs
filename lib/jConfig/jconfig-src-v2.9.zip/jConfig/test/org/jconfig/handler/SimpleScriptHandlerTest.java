/*
 * LDAPHandlerTest.java
 * JUnit based test
 *
 * Created on 8. Dezember 2002, 23:45
 */

package org.jconfig.handler;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jconfig.Configuration;

/**
 *
 * @author Administrator
 */
public class SimpleScriptHandlerTest extends TestCase {
    
    public SimpleScriptHandlerTest(java.lang.String testName) {
        super(testName);
    }
    
    public void setUp() {
    	//ConfigurationManager.
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(SimpleScriptHandlerTest.class);
        return suite;
    }
    
    public void testLoad() {
        SimpleScriptHandler scriptHandler = new SimpleScriptHandler();
        try {
            Configuration cfg = scriptHandler.load("simple");
            assertNotNull(cfg);
            String val = cfg.getProperty("hello");
            assertEquals("world",val);
            val = cfg.getProperty("val1","unknown","mycategory");
            assertEquals("100",val);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }
	
	public void testSave() {
        SimpleScriptHandler scriptHandler = new SimpleScriptHandler();
        try {
            Configuration cfg = scriptHandler.load("simple");
            assertNotNull(cfg);
			cfg.setProperty("save","now");
			//System.out.println(cfg);
			scriptHandler.store(cfg);
			cfg = scriptHandler.load("simple");
            assertEquals("world",cfg.getProperty("hello"));
			assertEquals("now",cfg.getProperty("save"));
            assertEquals("100",cfg.getProperty("val1","unknown","mycategory"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }
}
