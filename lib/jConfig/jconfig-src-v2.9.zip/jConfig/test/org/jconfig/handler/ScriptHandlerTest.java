/*
 * LDAPHandlerTest.java
 * JUnit based test
 *
 * Created on 8. Dezember 2002, 23:45
 */

package org.jconfig.handler;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jconfig.Configuration;

/**
 *
 * @author Administrator
 */
public class ScriptHandlerTest extends TestCase {
    
    public ScriptHandlerTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(ScriptHandlerTest.class);
        return suite;
    }
    
    public void testLoad() {
        ScriptHandler scriptHandler = new ScriptHandler();
        try {
            Configuration cfg = scriptHandler.load("test");
            assertNotNull(cfg);
            String val = cfg.getProperty("hello");
            assertEquals("world",val);
            val = cfg.getProperty("more",null,"special");
            assertEquals("override",val);
            val = cfg.getProperty("more",null,"stuff");
            assertEquals("override",val);
            val = cfg.getProperty("my crap",null,"stuff");
            assertEquals("is real crap",val);
            //assertEquals("is real crap2",val);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }

    public void testBrokenFile() {
        ScriptHandler scriptHandler = new ScriptHandler();
        try {
            scriptHandler.load("broken");
            fail("expected exception");
        }
        catch (Exception e) {            
        }
    }
    
}
