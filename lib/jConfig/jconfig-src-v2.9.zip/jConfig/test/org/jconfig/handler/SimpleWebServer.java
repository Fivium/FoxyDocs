/*
 * SimpleWebServer.java
 *
 * Created on 17. Oktober 2003, 15:43
 */

package org.jconfig.handler;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import org.jconfig.utils.ConfigurationUtils;
/**
 * This is a simple web server implementation used for URL testing.
 * The code is based on the article How a webserver works published
 * by java world.
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 */
public class SimpleWebServer extends Thread {
    
    private boolean active = false;
    private ServerSocket socket;
    
    public SimpleWebServer() {
        try {
            socket = new ServerSocket(8181);
            active = true;
            setDaemon(true);
            // FIXME: move this to a separate method 
            start();         
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void run() {
        while ( active ) {
            try {
                Socket clientSocket = socket.accept();
                clientSocket.setTcpNoDelay(true);                
                handleConnection(clientSocket);
            }
            catch (Exception ie) {
                ie.printStackTrace();
            }
        }
    }
    
    public void shutdown() {
        active = false;
    }
    
    private void handleConnection(Socket clientSocket) {
        try {
            
            OutputStream os = clientSocket.getOutputStream();
            InputStream input = clientSocket.getInputStream();
            String fileName = "config.xml";
            
            StringBuffer request = new StringBuffer(2048);
            int i;
            byte[] buffer = new byte[2048];
            try {
                i = input.read(buffer);
            }
            catch (IOException e) {
                e.printStackTrace();
                i = -1;
            }
            for (int j=0; j<i; j++) {
                request.append((char) buffer[j]);
            }            
            fileName = parseUri(request.toString());            
            sendResponse(os,fileName);
            
            os.close();
            input.close();
            clientSocket.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void sendResponse(OutputStream output,String fileName) throws IOException {
        byte[] bytes = new byte[2048];
        FileInputStream fis = null;
        try {
            File file = ConfigurationUtils.getFileFromInputStream(fileName);
            if (file.exists()) {
                fis = new FileInputStream(file);
                int ch = fis.read(bytes, 0, 2048);
                while (ch!=-1) {
                    output.write(bytes, 0, ch);
                    ch = fis.read(bytes, 0, 2048);
                }
            }
            else {
                // file not found
                String errorMessage = "HTTP/1.1 404 File Not Found\r\n" +
                "Content-Type: text/html\r\n" +
                "Content-Length: 23\r\n" +
                "\r\n" +
                "<h1>File Not Found</h1>";
                output.write(errorMessage.getBytes());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if (fis!=null)
                fis.close();
        }
    }
    
    private String parseUri(String requestString) {
        int index1, index2;
        index1 = requestString.indexOf(' ');
        if (index1 != -1) {
            index2 = requestString.indexOf(' ', index1 + 1);
            if (index2 > index1)
                return requestString.substring(index1 + 2, index2);
        }
        return null;
    }
}
