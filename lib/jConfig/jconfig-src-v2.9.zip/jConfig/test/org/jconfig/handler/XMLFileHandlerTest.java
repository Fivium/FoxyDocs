/*
 * XMLFileHandlerTest.java
 * JUnit based test
 *
 * Created on 3. Februar 2003, 22:17
 */

package org.jconfig.handler;

import java.io.File;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jconfig.Configuration;
import org.jconfig.parser.DefaultConfigParser;
import org.jconfig.utils.ConfigurationUtils;
/**
 *
 * @author andreas
 */
public class XMLFileHandlerTest extends TestCase {
    
    public XMLFileHandlerTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(XMLFileHandlerTest.class);
        return suite;
    }
    
    public void setUp() throws Exception {
        System.setProperty("jconfig.parser", DefaultConfigParser.class.getName());
    }
    
    public void testLoadAndSave() {
        File file = ConfigurationUtils.getFileFromInputStream("test.xml");
        assertNotNull(file);
        assertEquals(true, file.exists());
        try {
            XMLFileHandler handler = new XMLFileHandler();
            handler.setFile(file);
            Configuration config = handler.load("test");
            assertNotNull(config);
            String test = config.getProperty("USER",null,"JDBC");
            assertEquals("dice",test);
            assertEquals("10000",config.getProperty("maxNumber",null,"VariableTest"));
            assertEquals(10000L,config.getLongProperty("maxNumber",-1,"VariableTest"));
            String val = config.getProperty("varprop1",null,"includeTest");
            assertNotNull(val);
            assertEquals("value1",val);
            handler.setEncoding("ISO-8859-1");            
            config.setProperty("PWD","for me","JDBC");
            handler.store(config);
            config = handler.load("test");
            assertNotNull(config);
            assertEquals("developer",config.getVariable("user.name"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }    
    
    public void testGetEncoding() {
        XMLFileHandler handler = new XMLFileHandler();
        assertEquals("ISO-8859-1", handler.getEncodingType("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>"));
        assertEquals("ISO-8859-1", handler.getEncodingType("<?xml version='1.0' encoding='ISO-8859-1' ?>"));
    }
}
