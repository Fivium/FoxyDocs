/*
 * PropertiesHandlerTest.java
 * JUnit based test
 *
 * Created on 3. Februar 2003, 21:46
 */

package org.jconfig.handler;

import java.io.File;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jconfig.Configuration;
import org.jconfig.event.FileListener;
import org.jconfig.event.FileListenerEvent;
import org.jconfig.utils.ConfigurationUtils;

/**
 *
 * @author andreas
 */
public class PropertiesHandlerTest extends TestCase {
    
    public PropertiesHandlerTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(PropertiesHandlerTest.class);
        return suite;
    }
    
    public void testLoad() throws Exception {        
        File file = ConfigurationUtils.getFileFromInputStream("test.properties");
        PropertiesFileHandler handler = new PropertiesFileHandler();
        handler.setFile(file);
        Configuration config = handler.load("test");
        assertNotNull(config);
        assertEquals(1,config.getNumberOfCategories());
        assertEquals("/usr/development/mystuff/etc/new_sitemap.xml",config.getProperty("sitemap_file"));
    }
    
    public void testFileChanged() throws Exception {
		File file = ConfigurationUtils.getFile("test.properties");
		assertNotNull(file);
		PropertiesFileHandler handler = new PropertiesFileHandler(file);
		handler.addFileListener( new TestFileListener() );
    }
}
class TestFileListener implements FileListener {
	
	/**
	 * @see org.jconfig.event.FileListener#fileChanged(org.jconfig.event.FileListenerEvent)
	 */
	public void fileChanged(FileListenerEvent e) {
		System.out.println("huhu");
	}

}