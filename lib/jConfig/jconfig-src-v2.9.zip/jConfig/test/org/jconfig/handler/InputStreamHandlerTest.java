/*
 * ConfigurationXMLFileHandler.java
 * JUnit based test
 *
 * Created on 8. Dezember 2002, 23:17
 */

package org.jconfig.handler;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jconfig.Configuration;
import org.jconfig.parser.DefaultConfigParser;

/**
 *
 * @author Administrator
 */
public class InputStreamHandlerTest extends TestCase {
    
    public InputStreamHandlerTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        System.setProperty("jconfig.parser", DefaultConfigParser.class.getName());
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(InputStreamHandlerTest.class);
        return suite;
    }
    
    public void testLoad() {
        InputStreamHandler cHandler = new InputStreamHandler();
        cHandler.setFileName("test.xml");        
        try {
            Configuration config = cHandler.load("test");
            assertNotNull(config);
            String test = config.getProperty("USER",null,"JDBC");
            assertEquals("dice",test);
            cHandler.setEncoding("iso-8859-1");
            config.setProperty("PWD","for me","JDBC");
//            assertEquals("ISO-8859-1",config.getEncoding());
            String val = config.getProperty("varprop1",null,"includeTest");
            assertNotNull(val);
            assertEquals("value1",val);
            cHandler.store(config);            
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }
    
}
