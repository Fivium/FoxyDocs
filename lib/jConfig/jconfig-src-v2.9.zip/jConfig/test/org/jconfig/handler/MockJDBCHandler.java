/*
 * MockJDBCHandler.java
 *
 * Created on 15. April 2004, 09:10
 */

package org.jconfig.handler;

import org.jconfig.ConfigurationManagerException;
import org.jconfig.error.ErrorReporter;
import org.jconfig.utils.ResourceLocator;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author  mecky
 */
public class MockJDBCHandler extends JDBCHandler {
        
    public MockJDBCHandler() {
    }
    
    protected Connection JDBCLogin() throws ConfigurationManagerException {        
        try {
            Class.forName("org.hsqldb.jdbcDriver");
            String dbName = new ResourceLocator("configDB").getFile().getAbsolutePath();
            return DriverManager.getConnection("jdbc:hsqldb:"+ dbName,"sa","");
        }
        catch (Exception e) {
            ErrorReporter.getErrorHandler().reportError("Cannot load the jdbc driver", e);
            throw new ConfigurationManagerException("Cannot load the jdbc driver:"+e.getMessage());
        }    
    }
    
}
