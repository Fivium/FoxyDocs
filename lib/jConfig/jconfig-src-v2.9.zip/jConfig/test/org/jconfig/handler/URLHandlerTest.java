/*
 * XMLFileHandlerTest.java
 * JUnit based test
 *
 * Created on 3. Februar 2003, 22:17
 */

package org.jconfig.handler;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jconfig.Configuration;
/**
 *
 * @author andreas
 */
public class URLHandlerTest extends TestCase {
    
    private SimpleWebServer server;
    
    public URLHandlerTest(java.lang.String testName) {
        super(testName);
    }
    
    public static void main(java.lang.String[] args) {
        junit.textui.TestRunner.run(suite());
    }
    
    public static Test suite() {
        TestSuite suite = new TestSuite(URLHandlerTest.class);
        return suite;
    }
    
    public void setUp() throws Exception {
        server = new SimpleWebServer();
    }
    
    public void tearDown() throws Exception {
        server.shutdown();
    }
    
    public void testLoad() {        
        try {
            URLHandler handler = new URLHandler();
            handler.setURL("http://localhost:8181/test.xml");
            Configuration config = handler.load("test");
            assertNotNull(config);
            String test = config.getProperty("USER",null,"JDBC");
            assertEquals("dice",test);
            assertEquals("10000",config.getProperty("maxNumber",null,"VariableTest"));
            assertEquals(10000L,config.getLongProperty("maxNumber",-1,"VariableTest"));            
        }
        catch (Exception e) {
            e.printStackTrace();
            fail("unexpected exception");
        }
    }    
}
