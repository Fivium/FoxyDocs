#!/bin/sh 

DEMO_CP=../dist/jconfig.jar
DEMO_CP=$DEMO_CP:../lib/jaxp.jar
DEMO_CP=$DEMO_CP:../lib/crimson.jar
DEMO_CP=$DEMO_CP:.

javac -classpath $DEMO_CP $1 
