/*
 * PropertyListener.java
 *
 * Created on 22. Dezember 2002, 23:00
 */

package org.jconfig.event;

import java.util.EventListener;
/**
 * A PropertyListener is useful, if you're need to be 
 * notified whenever a property is changed. Perhaps you
 * want to log all changes to a log file. Implement the
 * propertyChanged method.
 * 
 * @author  Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public interface PropertyListener extends EventListener {
    
    /**
	 * Method propertyChanged.
	 * @param e
	 */
	public void propertyChanged( PropertyChangedEvent e );
}
