package org.jconfig.event;


/**
 * A useful Listener if you want to be notified whenever
 * the Category has changed.
 * 
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public interface CategoryListener extends PropertyListener {

	/**
	 * Called whenever the Category has changed.
	 * 
	 * @param event The Event
	 */
	public void categoryChanged( CategoryChangedEvent event );
}
