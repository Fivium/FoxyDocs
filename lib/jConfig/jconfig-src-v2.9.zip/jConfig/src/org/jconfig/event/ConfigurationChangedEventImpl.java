package org.jconfig.event;

import org.jconfig.Category;

/**
 * The all-in-one implementation of the ConfigurationChangedEvent.
 * 
 * Inside tip: the current implementation allows any PropertyChangedListener
 * or CategoryChangeListener to cast the respective Events to a 
 * ConfigurationChangedEvent.
 * 
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class ConfigurationChangedEventImpl
	implements ConfigurationChangedEvent {
	private String propertyName = null;
	private Category category = null;
	private int eventType = -1;
	private String oldValue = null;
	private String newValue = null;

	/**
	 * @param eventType
	 * @param oldValue
	 * @param newValue
	 */
	public ConfigurationChangedEventImpl(int eventType, Category category, String propertyName, String oldValue, String newValue) {
		this.eventType = eventType;
		this.oldValue = oldValue;
		this.newValue = newValue;	
		this.category = category;
		this.propertyName = propertyName;
	}
	
	/* (non-Javadoc)
	 * @see org.jconfig.event.PropertyChangeEvent#getPropertyName()
	 */
	public String getPropertyName() {
		return propertyName;
	}

	/* (non-Javadoc)
	 * @see org.jconfig.event.PropertyChangedEvent#getEventType()
	 */
	public int getEventType() {
		return eventType;
	}


	/* (non-Javadoc)
	 * @see org.jconfig.event.PropertyChangedEvent#getNewValue()
	 */
	public String getNewValue() {
		return newValue;
	}

	/* (non-Javadoc)
	 * @see org.jconfig.event.PropertyChangedEvent#getOldValue()
	 */
	public String getOldValue() {
		return oldValue;
	}

	/* (non-Javadoc)
	 * @see org.jconfig.event.CategoryChangedEvent#getCategoryName()
	 */
	public Category getCategory() {
		return category;
	}

}
