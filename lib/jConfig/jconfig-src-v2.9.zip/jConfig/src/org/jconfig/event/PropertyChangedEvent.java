package org.jconfig.event;

/**
 * Anytime a Property has changed, this event will be sent.
 * If a Property is deleted, the {@link #getNewValue getNewValue} will return
 * null. If a Property is added, the {@link #getOldValue getOldValue} will 
 * return null. What's trying to be said, is that the returned values should
 * be checked for NullPointerExceptions.
 * 
 * <pre>
 * public void propertyChanged( PropertyChangedEvent event ) { 
 * 	if( event.getEventType() == PROPERTY_ADDED ) {
 *		System.out.println("Property was added");
 *  	System.out.println("Name: " + event.getPropertyName());
 * 	}
 * }
 * </pre>
 * 
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public interface PropertyChangedEvent {
	/** constant representing an added property event */
	public static final int PROPERTY_ADDED = 1;
	/** constant representing a removed property event */
	public static final int PROPERTY_REMOVED = 2;
	/** constant representing a changed property event */
	public static final int PROPERTY_CHANGED = 3;
	/** constant representing an added category event */
	public static final int CATEGORY_ADDED = 4;
	/** constant representing a removed category event */
	public static final int CATEGORY_REMOVED = 5;
	/** constant representing a changed category event */
	public static final int CATEGORY_CHANGED = 6;
	
	/**
	 * The name of the Property that has changed.
	 * 
	 * @return The Property's name
	 */
	public String getPropertyName();
	
	/**
	 * The old value of the Property. Can be &lt;null&gt;, if a Property was added.
	 * 
	 * @return The old value
	 */
	public String getOldValue();
	
	/**
	 * The new value of the Property. Can be &lt;null&gt;, if a Property was deleted.
	 * 
	 * @return The new value
	 */
	public String getNewValue();
	
	/**
	 * Information about the event.
	 * 
	 * @see #PROPERTY_ADDED
	 * @see #PROPERTY_REMOVED
	 * @see #CATEGORY_ADDED
	 * @see #CATEGORY_REMOVED
	 * 
	 * @return The event's identifier/type
	 */
	public int getEventType();
}
