package org.jconfig.event;

/**
 * To receive notifications when a Configuration changes
 * one needs to implement this interface. The 
 * ConfigurationChangedEvent contains the information
 * about what has changed within the Configuration.
 * 
 * @author  Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public interface ConfigurationListener extends CategoryListener {
	
	/**
	 * Call whenever the Configuration changes
	 * @param evt The event
	 */
	public void configurationChanged( ConfigurationChangedEvent evt );
}

/**
 * $Log: ConfigurationListener.java,v $
 * Revision 1.4  2004/01/27 10:42:04  amecky
 * *** empty log message ***
 *
 * Revision 1.2  2003/07/31 19:16:17  terrydye
 * All changes required for the EventListener. This seems to be a better
 * implementation than what we had before.
 *
 * Revision 1.1  2003/06/30 20:16:43  terrydye
 * This is the new stuff per request from Andreas. The ConfigurationListener
 * stuff works well.
 *
 */
