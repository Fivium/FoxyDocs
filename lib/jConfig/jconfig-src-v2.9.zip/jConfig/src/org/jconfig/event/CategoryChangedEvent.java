package org.jconfig.event;

import org.jconfig.Category;

/**
 * Whenever a Category changes, this Event will be delivered.
 * 
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public interface CategoryChangedEvent extends PropertyChangedEvent {
	/**
	 * The name of the Category
	 * 
	 * @return The Category's name
	 */
	public Category getCategory();
}
