package org.jconfig.event;

/**
 * If a Property or Category changes during runtime, this
 * Event will be delivered.
 * 
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public interface ConfigurationChangedEvent extends CategoryChangedEvent {

}
