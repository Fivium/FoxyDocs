/*
 * CharPropertyEditor.java
 *
 * Created on 28. September 2004, 13:10
 */

package org.jconfig.utils.editors;

/**
 * The CharConverter will convert the given text into a Character object.
 * It simply takes the first char of the text and returns this as Character.
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public class CharConverter implements TypeConverter {
    
    /**
     *
     */
    public CharConverter() {
    }
    
    public Object getObject(String value) {
        if ( value != null ) {
            return new Character(value.charAt(0));
        }
        else {
            return null;
        }
    }
    
}
