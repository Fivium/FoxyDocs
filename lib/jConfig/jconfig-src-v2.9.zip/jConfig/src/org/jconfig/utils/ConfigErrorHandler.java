/*
 * ConfigErrorHandler.java
 *
 * Created on 12. Dezember 2002, 22:18
 */

package org.jconfig.utils;

import java.io.PrintWriter;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
//import org.xml.sax.helpers.*;
//import org.w3c.dom.*;
/**
 *
 * @author  andreas
 */
public class ConfigErrorHandler implements ErrorHandler {
    
        private PrintWriter out;
        /**
         *  Constructor for the MyErrorHandler object
         *
         *@param  out  Description of the Parameter
         */
        public ConfigErrorHandler(PrintWriter out) {
            this.out = out;
        }

        /**
         *  Returns a string describing parse exception details
         *
         *@param  spe  Description of the Parameter
         *@return      The parseExceptionInfo value
         */
        private String getParseExceptionInfo(SAXParseException spe) {
            String systemId = spe.getSystemId();
            if (systemId == null) {
                systemId = "null";
            }
            String info = "URI=" + systemId +
                    " Line=" + spe.getLineNumber() +
                    ": " + spe.getMessage();
            return info;
        }

        /**
         *  Description of the Method
         *
         *@param  spe               Description of the Parameter
         *@exception  SAXException  Description of the Exception
         */
        public void warning(SAXParseException spe) throws SAXException {
            out.println("Warning: " + getParseExceptionInfo(spe));
        }

        /**
         *  Description of the Method
         *
         *@param  spe               Description of the Parameter
         *@exception  SAXException  Description of the Exception
         */
        public void error(SAXParseException spe) throws SAXException {
            String message = "Error: " + getParseExceptionInfo(spe);
            throw new SAXException(message);
        }

        /**
         *  Description of the Method
         *
         *@param  spe               Description of the Parameter
         *@exception  SAXException  Description of the Exception
         */
        public void fatalError(SAXParseException spe) throws SAXException {
            String message = "Fatal Error: " + getParseExceptionInfo(spe);
            throw new SAXException(message);
        }
    }


