/*
 * ConfigurationUtils.java
 *
 * Created on 3. Februar 2003, 21:55
 */

package org.jconfig.utils;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.io.InputStream;
import java.util.Properties;
/**
 *
 * @author Andreas Mecky
 * @author Terry Dye
 *
 * This class contains some helper methods.
 *
 */
public class ConfigurationUtils {
    
    private ConfigurationUtils() {
    }
    
    /** This method tries to get the file for a given fileName
     * by trying to find it in the classpath.
     *
     * @param fileName The name of the file
     * @deprecated use ResourceLocator instead
     * @return a file or NULL
     */
    public static File getFileFromInputStream(String fileName) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        URL url = cl.getResource(fileName);
        if (url != null) {            
            String filename;
            try {
                filename = URLDecoder.decode(url.getFile(), "UTF8");
                File file = new File(filename);
                //File file = new File(url.getFile());
                return file;
            } 
            catch (UnsupportedEncodingException e) {
            }
            return null;
        }
        else {
            return null;
        }
    }
    
    /**
     * Method getFile.
     * @param filename
     * @return File
     * @throws IOException
     */
    public static File getFile( String filename ) throws IOException {
        ResourceLocator locator = new ResourceLocator( filename );
        return locator.getFile();
    }
    
    public static String getConfigProperty(String name) {
        return getConfigProperty(name,null);
    }
    
    public static String getConfigProperty(String name,String defaultValue) {
        String val = System.getProperty(name);
        if ( val == null ) {            
            try {
                ResourceLocator locator = new ResourceLocator("jconfig.properties");
                InputStream is = locator.getInputStream();
                // it is possible that the jconfig.properties does not exist, we get null
                if ( is != null ) {
                    Properties jcfProperties = new Properties();
                    jcfProperties.load( is );
                    val = jcfProperties.getProperty(name);
                }
            } catch (IOException e) {
            }
        }
        if ( val == null ) {
            val = defaultValue;
        }
        return val;
    }
}
