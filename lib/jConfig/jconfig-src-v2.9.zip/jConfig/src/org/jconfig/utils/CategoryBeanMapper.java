/*
 * CategoryBeanMapper.java
 *
 * Created on 28. September 2004, 12:32
 */

package org.jconfig.utils;

import java.util.Properties;
import java.util.HashMap;
import java.beans.*;
import java.lang.reflect.*;
import org.jconfig.*;
import org.jconfig.error.ErrorReporter;
import org.jconfig.utils.editors.*;
/**
 * This class is a little helper utility that will configure a simple java bean with
 * the properties inside a category. The set methods of the java bean will used to
 * configure the bean and the names of the set methods must match the names of the
 * properties in the category.
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public class CategoryBeanMapper {
    
    // a list of primitives that we will take care of
    private static HashMap primitives = new HashMap();
    static {
        primitives.put("int", Integer.class);        
        primitives.put("boolean", Boolean.class);
        primitives.put("double", Double.class);
        primitives.put("float", Float.class);
        primitives.put("long", Long.class);
    }
    
    // the char is special and we need a TypeConverter here
    private static HashMap converters = new HashMap();
    static {
        converters.put("char", new CharConverter());                
    }
    
    // noone should instantiate this one
    private CategoryBeanMapper() {
    }
    
    /**
     * This method will configure a java bean with the properties inside 
     * the defined category of the defined configuration (usually loaded
     * from the config.xml file)
     *
     * @param obj the java bean that will be configured
     * @param categoryName the name of the category    
     * @param configName the name of the configuration
     */    
    public static void mapBean(Object obj,String categoryName,String configName) {
        Configuration cfg = ConfigurationManager.getConfiguration(configName);
        Properties props = cfg.getProperties(categoryName);
        mapBean(obj,props);
    }
    
    /**
     * This method will configure a java bean with the properties inside 
     * the defined category of the default configuration (usually loaded
     * from the config.xml file)
     *
     * @param obj the java bean that will be configured
     * @param categoryName the name of the category     
     */    
    public static void mapBean(Object obj,String categoryName) {
        Configuration cfg = ConfigurationManager.getConfiguration();
        Properties props = cfg.getProperties(categoryName);
        mapBean(obj,props);
    }
    
    private static void mapBean(Object obj,Properties fieldMappings) {        
        try {                           
            BeanInfo binfo = Introspector.getBeanInfo (obj.getClass());
            PropertyDescriptor[] pds = binfo.getPropertyDescriptors();            
            for (int i = 0; i < pds.length; i++) {                
                PropertyDescriptor pd = pds[i];	
                String propName = pd.getName();                
                String dbValue = (String)fieldMappings.get(propName);                                
                if (dbValue != null ) {                    
                    Class typeClass;
                    String typeName = pd.getPropertyType().getName();                    
                    Object curObject = null;
                    if ( converters.containsKey(typeName) ) {
                        TypeConverter tc = (TypeConverter)converters.get(typeName);
                        curObject = tc.getObject(dbValue);
                    }
                    else if ( primitives.containsKey(typeName) ) {                        
                        typeClass = (Class)primitives.get(typeName);
                        curObject = getParameter(typeClass, dbValue);
                    }
                    else {
                        typeClass = Class.forName(typeName);
                        curObject = getParameter(typeClass, dbValue);
                    }
                    
                    Method setter = pd.getWriteMethod();
                    if (setter != null) {
                        if (curObject == null && pd.getPropertyType().isPrimitive()) {
                            throw new IllegalArgumentException ("Null property value for primitive property " + propName);
                        }
                        setter.invoke (obj, new Object[] { curObject });
                    }              
                    else {
                        ErrorReporter.getErrorHandler().reportError("CategoryBeanMapper: No setter method found for:"+propName);
                    }
                }
            }            
        }
        catch (Exception e) {
            ErrorReporter.getErrorHandler().reportError("CategoryBeanMapper: Exception while trying to configure bean:"+e.getMessage());
        }
    }
    
    private static Object getParameter(Class clazz,String value) {
        Object obj = null;
        try {
            PropertyEditor editor = PropertyEditorManager.findEditor(clazz);
            if( editor != null ) {            	
                editor.setAsText(value);
                obj = editor.getValue();
            }
            else {                
                Constructor constr = clazz.getDeclaredConstructor(new Class[]{String.class});
                obj = constr.newInstance(new Object[]{value});                
            }
        }
        catch (Exception e) {        
            ErrorReporter.getErrorHandler().reportError("CategoryBeanMapper: Exception while trying to define parameter:"+e.getMessage());
        }
        return obj;
    }
}
