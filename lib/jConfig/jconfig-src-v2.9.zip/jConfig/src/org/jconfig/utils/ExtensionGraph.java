/*
 * ExtensionGraph.java
 *
 * Created on 9. August 2004, 13:42
 */

package org.jconfig.utils;

import java.util.HashMap;
import java.util.Vector;
/**
 *
 * @author  mecky
 */
public class ExtensionGraph {
    
    private HashMap extensions = new HashMap();
    
    public ExtensionGraph() {
    }
    
    public void addExtension(String current,String extension) {
        extensions.put(current,extension);
    }
    
    /**
     * @return returns true if there is a circular dependency
     */
    public boolean checkDependencies(String current) {        
        Vector all = new Vector();
        return check(current,all);
    }
    
    private boolean check(String current,Vector all) {
        if ( extensions.containsKey(current)) {
            String ext = (String)extensions.get(current);
            if ( all.indexOf(ext) != - 1 ) {
                return true;
            }
            all.add(ext);
            return check(ext,all);
        }
        return false;
    }
    
}
