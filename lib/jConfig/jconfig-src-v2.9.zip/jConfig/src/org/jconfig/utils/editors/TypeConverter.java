/*
 * TypeConverter.java
 *
 * Created on 28. September 2004, 13:12
 */

package org.jconfig.utils.editors;

/**
 * This interface defines the methods that must be implemented by every
 * type converter. These converters are used by the CategoryBeanMapper.
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public interface TypeConverter {
 
    /**
     * Converts the given String value to an object that can be passed
     * to a set method using reflection
     *
     * @param value the value as String
     * @return the object 
     */
    public Object getObject(String value);
}
