/*
 * IncludeEntry.java
 *
 * Created on 2. August 2004, 18:33
 */

package org.jconfig.utils;

/**
 *
 * @author  mecky
 */
public class IncludeEntry {
    
    public static final int PROPERTIES = 1;
    
    private String name;
    private int type;
    
    public IncludeEntry(String name,int type) {
        this.name = name;
        this.type = type;
    }
    
    public String getName() {
        return name;
    }
    
    public int getType() {
        return type;
    }
    
}
