package org.jconfig;

public class Info {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Package[] allPackages = Package.getPackages();
        for(int i=0; i < allPackages.length; i++) {
        	if ( allPackages[i].getName().equals("org.jconfig") ) {
	              System.out.println("Version : "+allPackages[i].getImplementationVersion());
	              System.out.println("Title   : "+allPackages[i].getImplementationTitle());
	              System.out.println("Vencor  : "+allPackages[i].getImplementationVendor());
        	}
        }
	}

}
