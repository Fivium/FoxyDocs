/*
 * LoadedItem.java
 *
 * Created on 23. August 2004, 21:45
 */

package org.jconfig.bootstrap;

import org.jconfig.*;
import org.jconfig.handler.*;
/**
 *
 * @author  Administrator
 */
public class LoadedItem {
    
    private String name;
    private Configuration config;
    private ConfigurationHandler handler;
    /**
     *
     */
    public LoadedItem(String name,Configuration config,ConfigurationHandler handler) {
        this.name = name;
        this.config = config;
        this.handler = handler;
    }
    
    /**
     * Getter for property name.
     * @return Value of property name.
     */
    public java.lang.String getName() {
        return name;
    }    
        
    /**
     * Getter for property config.
     * @return Value of property config.
     */
    public org.jconfig.Configuration getConfig() {
        return config;
    }
    
    /**
     * Getter for property handler.
     * @return Value of property handler.
     */
    public org.jconfig.handler.ConfigurationHandler getHandler() {
        return handler;
    }
    
}
