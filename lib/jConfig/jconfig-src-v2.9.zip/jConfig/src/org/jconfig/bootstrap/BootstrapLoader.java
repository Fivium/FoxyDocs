/*
 * BootstrapLoader.java
 *
 * Created on 23. August 2004, 21:30
 */

package org.jconfig.bootstrap;

import org.jconfig.*;
/**
 * This interface defines the method that every BootstrapLoader
 * must implement
 * 
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public interface BootstrapLoader {
    
    /**
     * This method is supposed to return a list of configurations.
     * The specific BootstrapLoader is used by the ConfigurationManager
     * when instantiated. All configurations will be added to the 
     * ConfigurationManager.
     */
    public LoadedItem[] load() throws ConfigurationManagerException;
}
