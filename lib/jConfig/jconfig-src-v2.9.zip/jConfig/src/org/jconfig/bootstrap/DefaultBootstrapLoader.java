/*
 * DefaultBootstrapLoader.java
 *
 * Created on 23. August 2004, 21:32
 */

package org.jconfig.bootstrap;

import org.jconfig.*;
import org.jconfig.handler.*;
import java.util.Vector;
/**
 * The DefaultBootstrapLoader implements the same functionality as the old
 * implementation inside the ConfigurationManager. It will try to find a
 * file called "config.xml" in the classpath and if found will parse it
 * and this configuration will be stored as "default" configuration.
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public class DefaultBootstrapLoader implements BootstrapLoader {
        
    public DefaultBootstrapLoader() {
    }
    
    public LoadedItem[] load() throws ConfigurationManagerException {
        Vector configs = new Vector();
        String fileName = "config.xml";            
        InputStreamHandler ish = new InputStreamHandler(fileName);            
        Configuration config = ish.load("default");        
        if ( config != null ) {
            LoadedItem li = new LoadedItem(config.getConfigName(),config,ish);
            configs.add(li);
        }                    
        return (LoadedItem[])configs.toArray(new LoadedItem[0]);
    }
    
}
