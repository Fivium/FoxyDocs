/*
 * BootstrapLoaderFactory.java
 *
 * Created on 23. August 2004, 21:32
 */

package org.jconfig.bootstrap;

import org.jconfig.utils.*;
import org.jconfig.error.*;
/**
 * The BootstrapLoaderFactory will instantiate the
 * defined BootstrapLoader and return it. In order to determine
 * which loader should be used it will look for a system.property called
 * jconfig.bootstraploader. If not set then it will look for the same property
 * in a file called jconfig.properties. This
 * properties file must be in the classpath. The value for this property
 * must be the full qualified class name. 
 * 
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public class BootstrapLoaderFactory {
    
    /**
     *
     */
    public BootstrapLoaderFactory() {
    }
    
    /**
     * This method will return the implementation
     * of the BootstrapLoader that will be used
     * by the ConfigurationManager at startup to
     * load some configurations.
     */
    public static BootstrapLoader getLoader() {
        String val = ConfigurationUtils.getConfigProperty("jconfig.bootstraploader");    
        if ( val == null ) {
            return new DefaultBootstrapLoader();
        }
        else {
            try {
                BootstrapLoader bl = (BootstrapLoader)Class.forName(val).newInstance();
                return bl;
            }
            catch (Exception e) {
                ErrorReporter.getErrorHandler().reportError("Exception while trying to set the bootstrap loader:"+val,e);
                return new DefaultBootstrapLoader();
            }
        }
        
    }
    
}
