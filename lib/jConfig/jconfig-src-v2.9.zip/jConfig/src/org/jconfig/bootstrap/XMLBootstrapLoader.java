/*
 * DefaultBootstrapLoader.java
 *
 * Created on 23. August 2004, 21:32
 */

package org.jconfig.bootstrap;

import org.jconfig.*;
import org.jconfig.handler.*;
import java.util.Vector;
/**
 * This BootstrapLoader will read in an XML file called "bootstrap.xml"
 * and parse the content. Then it will load every configuration  with the
 * defined handler and (optional) parser.<br/>
 * <B>Note:</B> This is currently not implemented and this loader works
 * exactly like the DefaultBootstrapLoader!!!
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public class XMLBootstrapLoader implements BootstrapLoader {
    
    /**
     *
     */
    public XMLBootstrapLoader() {
    } 
    
    public LoadedItem[] load() throws ConfigurationManagerException {
        Vector configs = new Vector();
        String fileName = "config.xml";
        InputStreamHandler ish = new InputStreamHandler(fileName);
        Configuration config = ish.load("default");
        if ( config != null ) {
            LoadedItem li = new LoadedItem(config.getConfigName(),config,ish);
            configs.add(li);
        }
        return (LoadedItem[])configs.toArray(new LoadedItem[0]);
    }
    
}
