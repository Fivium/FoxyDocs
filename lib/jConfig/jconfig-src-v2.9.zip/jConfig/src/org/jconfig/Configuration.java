package org.jconfig;

import java.util.HashMap;
import java.util.Vector;
import java.util.Properties;
import org.jconfig.event.CategoryListener;
import org.jconfig.event.ConfigurationChangedEvent;
import org.jconfig.event.ConfigurationListener;
import org.jconfig.event.PropertyListener;
/**
 * A Configuraton provides access to all Category and Properties.
 * The Configuration was converted into an Interface after the
 * need for other Configuration implementations existed.
 *
 * @see org.jconfig.DefaultConfiguration
 * @see org.jconfig.ExtensibleConfiguration
 * @since 2.3
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public interface Configuration {
    
    /**
     * Adds a category to the current configuration.
     *
     * @param name Name of the category to be added.
     */
    public void setCategory(String name);
    
    public void setCategory(Category category);
    /**
     * Besides setting the category, it will also set this
     * category as default category if main is true. It will
     * only set (ie create) the category if it does not exist. If you
     * want delete a category then use @see #removeCategory(String)
     *
     * @param name the name of the category
     * @param main if true then this category is the default category
     */
    public void setCategory(String name, boolean main);
    
    /**
     * This method returns the name of the
     * default category
     *
     * @return name of the default category
     */
    public String getMainCategoryName();
    
    /**
     * This method returns a string array with all
     * category names.
     *
     * @return a string array with all category names
     */
    public String[] getCategoryNames();
    
    /**
     * This method returns the String value based on the given key.
     *
     * Implementation details: It calls getProperty(name,null,null).
     * It searches inside the default category for the property.
     *
     * @param key the name of the property
     * @return the value as String if it is found or null
     */
    public String getProperty(String key);
    
    /**
     * This method is the same as getProperty(key) but it
     * returns the defaultValue if the property cannot be found.
     *
     * Implementation details: It calls getProperty(key,defaultValue,null).
     *
     * @param key the name of the property
     * @param defaultValue the defaultValue that will be returned if the property cannot be found
     * @return the value as String
     */
    public String getProperty(String key, String defaultValue);
    
    /**
     * This is the real implementation. It will return the value of the property
     * with the specific name. First of all, it checks if the name of the category
     * exists. If not, then it will use the name of the default category.
     * The next step is that it will look for the property. If it is not found in
     * the category, it will look inside the default category (inheritance). If
     * it still cannot find the property, it will return the defaultValue
     *
     * @param key the name of the property
     * @param defaultValue the default value
     * @param categoryName the name of the category
     * @return the value as String
     */
    public String getProperty(String key,String defaultValue,String categoryName);
    
    /**
     * This method sets a property with the name and the value
     * in the default category. It calls setProperty(name.value,null).
     *
     * @param name the name of the property
     * @param value the value as String
     */
    public void setProperty(String name, String value);
    
    /**
     * This method sets the value for a property for the given
     * category. It also raises a PropertyEvent. If the category
     * is null then it uses the default category.
     *
     * @param name the name of the property
     * @param value the value as String
     * @param categoryName the name of the category
     */
    public void setProperty(String name, String value, String categoryName);
    
    /**
     * This method deletes a property from the default category.
     * It calls removeProperty(name,null).
     *
     * @param name the name of the property
     */
    public void removeProperty(String name);
    
    /**
     * This method deletes a property with the given name
     * from the specific category. If the category is null
     * then it will delete the property from the default category.
     *
     * @param name the name of the property
     * @param category the name of the category
     */
    public void removeProperty(String name, String category);
    
    /**
     * The method returns the number of categories inside this configuration.
     *
     * @return the number of categories
     */
    public int getNumberOfCategories();
    
    /**
     * This method deletes a category with all its properties
     *
     * @param category the name of the category
     */
    public void removeCategory(String category);
    
    /**
     * This method returns all properties for the default category
     * 
     * @return all properties for the default category
     */
    public Properties getProperties();
    
    /**
     * This method returns all properties for the category
     * with the given name
     * 
     * @param name the name of the category
     * @return all properties for the default category
     */
    public Properties getProperties(String name);
    
    /**
     * This method returns all the names of the properties
     * for the specific category
     *
     * @param category the name of the category
     * @return the names as string array
     */
    public String[] getPropertyNames(String category);
    
    /**
     * This method sets a variable inside the configuration.
     *
     * @param name the name of the variable
     * @param value the value of the variable
     */
    public void setVariable(String name, String value);
    
    /**
     * It returns a HashMap with all variables with the
     * variable name as key
     *
     * @return a HashMap with all variables
     */
    public HashMap getVariables();
    
    public String getVariable(String name);
    /**
     * @param name
     * @param defaultValue
     * @return
     */
    public int getIntProperty(String name, int defaultValue);
    
    /**
     * @param name
     * @param defaultValue
     * @param category
     * @return
     */
    public int getIntProperty(String name, int defaultValue, String category);
    
    /**
     * Wrapper method to keep API simple
     *
     * @see Category#getBooleanProperty(String, boolean)
     * @param name
     * @param defaultValue
     * @return
     */
    public boolean getBooleanProperty(String name, boolean defaultValue);
    
    /**
     * Wrapper method to Category method
     *
     * @see Category#getBooleanProperty(String, boolean, String)
     * @param defaultValue
     * @param categoryName
     * @return
     */
    public boolean getBooleanProperty(String name,boolean defaultValue,String categoryName);
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     */
    public void setBooleanProperty(String key, boolean value);
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     * @param category
     */
    public void setBooleanProperty(String key, boolean value, String category);
    
    /**
     * Wrapper method to Category method
     *
     * @param name
     * @param defaultValue
     * @return
     */
    public long getLongProperty(String name, long defaultValue);
    
    /**
     * Wrapper method to Category method
     *
     * @param name
     * @param defaultValue
     * @param category
     * @return
     */
    public long getLongProperty(String name,long defaultValue,String categoryName);
    
    /**
     * Wrapper method to Category method
     *
     * @param name
     * @param defaultValue
     * @return
     */
    public double getDoubleProperty(String name, double defaultValue);
    
    /**
     * Wrapper method to Category method
     *
     * @param name
     * @param defaultValue
     * @param category
     * @return
     */
    public double getDoubleProperty(String name,double defaultValue,String category);
    
    /**
     * Wrapper method to Category method
     *
     * @param name
     * @param defaultValue
     * @return
     */
    public char getCharProperty(String name, char defaultValue);
    
    /**
     * Wrapper method to Category method
     *
     * @param name
     * @param defaultValue
     * @param category
     * @return
     */
    public char getCharProperty(String name,char defaultValue,String category);
    
    /**
     * This method creates a string representation of the configuration.
     *
     * @return a string with the configuration
     */
    public String toString();
    /**
     * This method converts the Configuration into a String
     * which looks like XML.
     *
     * @return the Configuration as String in XML format
     */
    public String getXMLAsString();
    /**
     * Adds the PropertyListener to the main category.
     *
     * If the main category changes after the listener has
     * already been added, the listener is still registered,
     * but not to the main category any longer. One way to
     * handle this behavior is to remove the listener from
     * the old main category and add it to the new main
     * category.
     *
     * @param listener
     */
    public void addPropertyListener(PropertyListener listener);
    
    /**
     * Adds the PropertyListener to the given category.
     */
    public void addPropertyListener(PropertyListener listener, String categoryName);
    
    /**
     * Return the name of the current configuration.
     * @return
     */
    public String getConfigName();
    
    /**
     * Sets the name of the configuration. 
     * 
     * @param configName
     */
    public void setConfigName(String configName);
    
    /**
     * Adds the specified configuration listener to receive configuration
     * changed events from this configuration.
     *
     * @param listener The ConfigurationListener
     */
    public void addConfigurationListener(ConfigurationListener listener);
    
    /**
     * Removes the specified configuration listener from the configuration
     * change events from this configuration.
     *
     * @param listener The ConfigurationListener
     */
    public void removeConfigurationListener(ConfigurationListener listener);
    
    /**
     * Deliver configuration changed event to all listeners that are registered
     * with our listener list.
     *
     * @param event The ConfigurationChangedEvent
     */
    public void fireConfigurationChangedEvent(ConfigurationChangedEvent event);
    
    /**
     * Returns the main category for this configuration
     *
     * @return The main category
     */
    public Category getCategory();
    
    /**
     * Returns a category based on the name provided.
     * @param name The name of the category (if null, main category will be used)
     * @return The category object (new instance if necessary)
     */
    public Category getCategory(String name);
    
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     */
    public void setLongProperty(String key, long value);
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     */
    public void setIntProperty(String key, int value);
    
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     */
    public void setCharProperty(String key, char value);
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     * @param category
     */
    public void setCharProperty(String key, char value, String category);
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     */
    public void setDoubleProperty(String key, double value);
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     * @param category
     */
    public void setLongProperty(String key, long value, String category);
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     * @param category
     */
    public void setIntProperty(String key, int value, String category);
    
    /**
     * Wrapper method to Category method
     *
     * @param key
     * @param value
     * @param category
     */
    public void setDoubleProperty(String key, double value, String category);
    
    /**
     * This methods returns a flag which indicates if the configuration
     * has changed since it was loaded.
     *
     * @return true if the configuration has changed
     */
    public boolean hasChanged();
    
    /**
     * @param key
     * @return
     */
    public String[] getArray(String key);
    
    /**
     * @param key
     * @param defaultValue
     * @return
     */
    public String[] getArray(String key,String[] defaultValue);
    
    /**
     * @param key
     * @param defaultValue
     * @param category
     * @return
     */
    public String[] getArray(String key,String[] defaultValue,String category);
    
    /**
     * This method determines if the configuration was loaded successfully (returns false)
     * or if the configuration was created by the ConfigurationManager.
     *
     * @return true if created by the ConfigurationManager
     */
    public boolean isNew();
    
    /**
     * This method is used by the handlers to reset the isNew flag to false. This
     * indicates that the configuration was loaded and not created.
     */
    public void resetCreated();
    
    public void setEncoding(String encoding);
    
    public String getEncoding();
    
    public void addCategoryListener(CategoryListener listener);
    
    public void addCategoryListener(CategoryListener listener,String categoryName);
    
    /**
     * Use this method to determine if a category exists. The getCategory method
     * will return the default category if the requested category was not found.
     * So if you need to know if a category already exists then call this method.
     */
    public boolean containsCategory(String categoryName);
        
    public void addInclude(int type,String name);
    
    public Vector getIncludes();
    
    /**
     * This method is used to define the base configuration of a configuration.
     * This means if config A extends config B then this method will be called
     * in config A with the name of config B.
     */
    public void setBaseConfiguration(String name);
	
	public String getBaseConfiguration();
    
    public void renameCategory(String newName,String oldName);
}
