package org.jconfig.error;

/**
 * This class implements the so called NullDevice ErrorHandler. It just
 * swallows the error messages. This ErrorHandler is used as default to
 * be backward compatible since jConfig has never reported any errors before.
 * 
 * @author Andreas Mecky andreasmecky@yahoo.de
 * @author Terry Dye terrydye@yahoo.com
 */
public class NullDeviceErrorHandler implements ErrorHandler {
	
	public void reportError(String message) {
	}

	public void reportError(String message, Throwable thrown) {
	}
	
}
