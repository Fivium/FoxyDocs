/*
 * Created on 28.06.2004
 * Created by crappy eclipse.
 */
package org.jconfig.error;

/**
 * @author Mecky
 * shoot me because I am using eclipse
 */
public interface ErrorHandler {
	
	public void reportError(String message);
	
	public void reportError(String message,Throwable thrown);
}
