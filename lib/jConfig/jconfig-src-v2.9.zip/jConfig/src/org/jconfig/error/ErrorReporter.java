package org.jconfig.error;

import org.jconfig.utils.*;
/**
 * This class will return the specified ErrorHandler.
 * You can define the ErrorHandler by setting the property<br/>
 * jconfig.errorhandler=org.jconfig.DefaultErrorHandler<br/>
 * You can also define your own ErrorHandler here. <br/>
 * If no ErrorHandler is defined then jConfig will use the so
 * called SimpleErrorHandler which will simply report
 * any error to the console.
 *
 * @author Andreas Mecky andreasmecky@yahoo.de
 * @author Terry Dye terrydye@yahoo.com
 */
public class ErrorReporter {
    
    private static ErrorHandler eh = null;
    /**
     * This method will return the defined ErrorHandler. If
     * no ErrorHandler is defined it will return the SimpleErrorHandler.
     *
     * @return the ErrorHandler
     */
    public static ErrorHandler getErrorHandler() {
        if ( eh == null ) {
            String name = findHandler();
            if ( name == null ) {
                eh = getDefaultHandler();
            }
            else {
                try {
                    eh = (ErrorHandler)Class.forName(name).newInstance();
                }
                catch (Exception e) {                    
                    eh = getDefaultHandler();
                }
            }
        }
        return eh;
    }
    
    private static ErrorHandler getDefaultHandler() {
        //return new SimpleErrorHandler();
        return new NullDeviceErrorHandler();
    }
    
    private static String findHandler() {
        return ConfigurationUtils.getConfigProperty("jconfig.errorhandler");        
    }
}
