/*
 * Created on 28.06.2004
 * Created by crappy eclipse.
 */
package org.jconfig.error;

/**
 * @author Mecky
 * shoot me because I am using eclipse
 */
public class SimpleErrorHandler implements ErrorHandler {

	public SimpleErrorHandler() {		
	}
	
	public void reportError(String message) {
		System.out.println(message);
	}

	
	public void reportError(String message, Throwable thrown) {
		System.out.println(message);
		thrown.printStackTrace();
	}
	
	
}
