/*
 * ThreadPool.java
 *
 * Created on 17. Oktober 2003, 16:22
 */

package org.jconfig.server;

import java.util.Vector;
/**
 *
 * @author  Administrator
 */
public class ThreadPool {
    
    private Vector threadPool;
    private int maxSize = 50;
    private int counter = 0;
    private ThreadGroup tg;
    private String threadName;
    
    public ThreadPool() {
        threadPool = new Vector();
        tg = new ThreadGroup("SERVER THREAD POOL");
        threadName = "TP-ANON";
        for ( int i = 0; i < maxSize; i++) {
            try {
                //ProtocolHandler myHandler = (ProtocolHandler)clazz.newInstance();
                //threadPool.push(myHandler);
                WorkerThread wt = new WorkerThread(tg,threadName);
                threadPool.add(wt);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public WorkerThread getWorker() {
        // TODO: check if there are threads available        
        WorkerThread wt = (WorkerThread)threadPool.get(0);
        threadPool.remove(0);        
        return wt;        
    }
    
    public void releaseWorkerThread(WorkerThread wt) {
        counter --;
        threadPool.insertElementAt(wt, threadPool.size());
    }
    
    
}
