/*
 * WorkerThread.java
 *
 * Created on 17. Oktober 2003, 20:05
 */

package org.jconfig.server;

import java.net.Socket;
/**
 *
 * @author  Administrator
 */
public class WorkerThread extends Thread {
    
    private ProtocolHandler handler = null;
    private boolean active = false;
    private Socket socket = null;
    private ServerContext serverContext;
    
    public WorkerThread(ThreadGroup tg,String threadName) {
        super(tg,(Runnable)null,threadName);
    }
    
    public synchronized void execute(Socket socket,ProtocolHandler handler,ServerContext serverContext) {        
        if ( this.handler != null ) {
            throw new IllegalStateException("Already running");
        }
        this.socket = socket;
        this.handler = handler;
        this.serverContext = serverContext;
        this.notifyAll();
        if ( !active ) {            
            active = true;
            start();
        }
    }
    
    public void run() {
        while (active) {                        
            if (handler != null) {
                try {                    
                    handler.execute(socket,serverContext);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }                
            this.handler = null;  
            this.socket = null;
            synchronized (this) {
                while (active && handler == null) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                    }
                }
            }
            
        }
    }
    
}
