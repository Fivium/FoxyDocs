/*
 * ConfigurationServer.java
 *
 * Created on 25. Januar 2004, 18:09
 */

package org.jconfig.server;

/**
 * This is the configuration server itself. It can either be started from the
 * command line like:
 * java -classpath jconfig.jar org.jconfig.server.ConfigurationServer -port {port} -docroot {directory}
 * or integrated into a JMX capable server. 
 * If the port is not set then default port is 8234. The documentroot will be set to
 * the tmp-directory if not provided.
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public class ConfigurationServer implements ConfigurationServerMBean {
    
    private BaseServer server;
    private int port = 8234;
    private String documentRoot;
    private boolean daemon = false;
    
    public ConfigurationServer(int port,String documentRoot) {
        this.port = port;
        this.documentRoot = documentRoot;
        start();
    }
    
    public ConfigurationServer() {        
    }
    
    public void shutdown() {
        if ( server != null ) {
            server.shutdown();
        }
    }
    
    public void start() {
        ServerContext serverContext = new ServerContext();
        serverContext.setDocumentRoot(documentRoot);
        server = new BaseServer(port, ConfigProtocolHandler.class,serverContext);
        server.setAsDaemon(daemon);
        server.start();
        System.out.println("Server started");
        System.out.println("Port:"+port);
        System.out.println("Documentroot:"+documentRoot);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        ConfigurationServer cs = new ConfigurationServer();
        cs.setDocRootFromArgs(args);
        cs.setPortFromArgs(args);        
        cs.startServer();        
    }
    
    public String getDocumentRoot() {
        return documentRoot;
    }
    
    public int getPort() {
        return port;
    }
    
    public void setDocumentRoot(String docRoot) {
        this.documentRoot = docRoot;
    }
    
    public void setPort(int port) {
        this.port = port;
    }
    
    private void setDocRootFromArgs(String[] args) {
        String dr = getArgument(args,"-docroot");
        if ( dr != null ) {
            documentRoot = dr;
        }
        else {
            documentRoot = System.getProperty("java.io.tmpdir");
        }
    }
    
    private void setPortFromArgs(String[] args) {
        String myPort = getArgument(args,"-port");
        if ( myPort != null ) {
            try {
                port = Integer.parseInt(myPort);
            }
            catch (Exception e) {
                
            }
        }
    }
    
    private String getArgument(String[] args,String param) {
        String ret = null;
        for ( int i = 0; i < args.length;i++) {
            if ( args[i].equals(param)) {
                if ( (i+1) <= args.length ) {
                    ret = args[i+1];
                }
            }
        }
        return ret;
    }
    
    public void startServer() {
        start();
    }
    
    public void stopServer() {
        shutdown();
    }
    
    public void setDaemon(boolean isDaemon) {
        daemon = isDaemon;
    }
    
    public void setStarted(boolean shouldStart) {
        if ( shouldStart ) {
            startServer();
        }
    }
    
}
