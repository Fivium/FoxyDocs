/*
 * BaseServer.java
 *
 * Created on 17. Oktober 2003, 16:29
 */
package org.jconfig.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/**
 * This class implements a simple server. Every request to this server
 * will be handled by the defined ProtocolHandler.
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public class BaseServer extends Thread {
    
    private boolean active = false;
    private ServerSocket socket;
    private ThreadPool pool;
    private Class clazz;
    private ServerContext serverContext;
   
    public BaseServer(int port,Class handler,ServerContext serverContext) {
        this.serverContext = serverContext;
        try {
            socket = new ServerSocket(port);
            pool = new ThreadPool();
            active = true;
            //setDaemon(true);
            //start();
            clazz = handler;
        }
        catch (IOException ie) {
            ie.printStackTrace();
        }
    }
    
    public void run() {
        while (active) {
            try {
                Socket clientSocket = socket.accept();
                clientSocket.setTcpNoDelay(true);
                handleConnection(clientSocket);                
            } catch (IOException ie) {
                ie.printStackTrace();
            }
        }
    }
    
    private void handleConnection(Socket clientSocket) throws IOException {
        // 1. get worker thread from pool
        WorkerThread wt = pool.getWorker();
        // 2. call the execute
        try {        	
            ProtocolHandler handler = (ProtocolHandler)clazz.newInstance();
            wt.execute(clientSocket,handler,serverContext);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        // 3. return to pool
        pool.releaseWorkerThread(wt);
    }
    
    public void shutdown() {
        active = false;
    }
    
    public void setAsDaemon(boolean isDaemon) {
        super.setDaemon(isDaemon);
    }
    
}
