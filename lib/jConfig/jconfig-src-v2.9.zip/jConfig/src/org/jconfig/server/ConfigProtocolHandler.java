/*
 * ConfigProtocolHandler.java
 *
 * Created on 25. Januar 2004, 18:16
 */

package org.jconfig.server;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
/**
 *
 * @author  Administrator
 */
public class ConfigProtocolHandler implements ProtocolHandler {
            
    public ConfigProtocolHandler() {
    }
    
    public void execute(Socket socket) {        
        try {
            InputStream input = null;
            OutputStream output = null;
            input = socket.getInputStream();
            output = socket.getOutputStream();
            
            // create Request object and parse
            Request request = new Request(input);
            request.parse(socket);            
            // create Response object
            Response response = new Response(output);
            response.setRequest(request);
            response.sendStaticResource();
            
            // Close the socket
            socket.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * This method will try to find a configuration based on the name
     * and on the ip-address of the client. The strategy is that it
     * will first try to find {ip_adr}_{configname}.xml. If the file
     * is not found then it will delete the last part of the ip-address
     * and try again. If no file is found the it will at last search
     * for the {configname}.xml. If no success then return an empty
     * configuration.
     */
    private String getFileName(Request request,ServerContext serverContext) {
        String uri = request.getUri();
        String ip_adr = request.getHostAddress();
        if ( uri.startsWith("/") ) {
            uri = uri.substring(1);        
        }
        uri += ".xml";    
        String tmp = serverContext.getDocumentRoot()+ip_adr+"_"+uri;
        if ( checkFile(tmp)) {
            return tmp;
        }
        ip_adr = ip_adr.substring(0,ip_adr.lastIndexOf("."));
        tmp = serverContext.getDocumentRoot()+ip_adr+"_"+uri;
        if ( checkFile(tmp)) {
            return tmp;
        }
        ip_adr = ip_adr.substring(0,ip_adr.lastIndexOf("."));
        tmp = serverContext.getDocumentRoot()+ip_adr+"_"+uri;
        if ( checkFile(tmp)) {
            return tmp;
        }
        ip_adr = ip_adr.substring(0,ip_adr.lastIndexOf("."));
        tmp = serverContext.getDocumentRoot()+ip_adr+"_"+uri;
        if ( checkFile(tmp)) {
            return tmp;
        }
        tmp = serverContext.getDocumentRoot()+uri;
        if ( checkFile(tmp)) {
            return tmp;
        }
        uri = serverContext.getDocumentRoot()+uri;        
        return uri;
    }
    
    private boolean checkFile(String name) {
        File file = new File(name);
        return file.exists();
    }
    
    public void execute(Socket socket, ServerContext serverContext) {
    	try {
    		InputStream input = null;
    		OutputStream output = null;
    		input = socket.getInputStream();
    		output = socket.getOutputStream();
    		
    		// create Request object and parse
    		Request request = new Request(input);
    		request.parse(socket);            
    		// create Response object
    		Response response = new Response(output);
    		response.setRequest(request);
                String filename = getFileName(request,serverContext);                
    		response.sendStaticResource(filename);
    		
    		// Close the socket
    		socket.close();
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    }
    
}
