/*
 * ConfigurationServerMBean.java
 *
 * Created on 2. Februar 2004, 21:00
 */

package org.jconfig.server;

/**
 *
 * @author  Andreas Mecky andreasmecky@yahoo.de
 * @author  Terry Dye terrydye@yahoo.com
 */
public interface ConfigurationServerMBean {
    
    public void setPort(int port);
    public int getPort();
    public void setDocumentRoot(String docRoot);
    public String getDocumentRoot();
    public void startServer();
    public void stopServer();
    public void setDaemon(boolean isDaemon);
    public void setStarted(boolean shouldStart);
}
