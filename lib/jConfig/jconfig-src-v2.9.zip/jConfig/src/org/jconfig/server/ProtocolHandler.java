/*
 * ProtocolHandler.java
 *
 * Created on 17. Oktober 2003, 16:24
 */

package org.jconfig.server;

import java.net.Socket;
/**
 *
 * @author  Administrator
 */
public interface ProtocolHandler {
    
    public void execute(Socket clientSocket,ServerContext serverContext);
}
