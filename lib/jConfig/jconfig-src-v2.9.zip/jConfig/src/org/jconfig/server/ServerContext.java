/*
 * ServerContext.java
 *
 * Created on 26. Januar 2004, 11:34
 */

package org.jconfig.server;

import java.io.File;
/**
 *
 * @author  mecky
 */
public class ServerContext {
    
    private String documentRoot;
    
    public ServerContext() {
    }
    
    /** Getter for property documentRoot.
     * @return Value of property documentRoot.
     *
     */
    public String getDocumentRoot() {
        return documentRoot;
    }
    
    /** Setter for property documentRoot.
     * @param documentRoot New value of property documentRoot.
     *
     */
    public void setDocumentRoot(String documentRoot) {
        if ( !documentRoot.endsWith(File.separator) ) {
            documentRoot += File.separator;
        }
        this.documentRoot = documentRoot;
    }
    
}
