package org.jconfig;

import java.util.Collection;
import java.util.HashMap;

/**
 * This class is the result of countless discussions of what
 * a Category should be. After determing that it should be
 * another class, and that we can do something useful, we
 * created this Category.
 *
 * A Category is a logical extension of the Configuration
 * has Categories has Properties has Value frame-of-mind.
 * The primary goal is to reduce redundancy in source code
 * when using setter and getters that include Category
 * information.
 *
 * @since 2.2
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class NestedCategory extends DefaultCategory {
                    
    private HashMap children;
    /**
     * @since 2.2
     * @param categoryName
     */
    public NestedCategory(String categoryName) {
        super(categoryName);
        children = new HashMap();        
    }
    
    public void addCategory(Category cat) {        
        children.put(cat.getCategoryName(),cat);
    }
    
    public NestedCategory getCategory(String name) {        
        return (NestedCategory)children.get(name);
    }
    
    public Collection getChildCategories() {
        return children.values();
    }
    
}
