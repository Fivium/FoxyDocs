package org.jconfig.parser;

import org.jconfig.Configuration;
import org.w3c.dom.Document;
/**
 *
 * @author  Andreas Mecky andreas.mecky@xcom.de
 * @author  Terry Dye terry.dye@xcom.de
 */
public interface ConfigurationParser {
 
    public Configuration parse(Document doc,String configName);
}
