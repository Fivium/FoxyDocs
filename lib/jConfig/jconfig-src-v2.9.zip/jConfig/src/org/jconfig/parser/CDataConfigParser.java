package org.jconfig.parser;

import org.jconfig.Category;
import org.jconfig.Configuration;
import org.jconfig.DefaultCategory;
import org.jconfig.ExtensibleConfiguration;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 * The CDataConfigParser supports the following XML structure:<br>
 * <category name="hello"><br>
 *  <mytag>my value</mytag><br>
 *  <nextone>more goes here</nextone><br>
 *  <server_port>8080</server_port><br>
 * </category><br>
 * It also supports "inheritance" that means one category can
 * extend another category and will also have all properties.
 * Properties will be overwritten.<br>
 * Syntax:<br>
 * <category name="first"><br>
 *  <hello>world/<hello><br>
 * </category><br>
 * <category name="second" extends="first"><br>
 * </category><br>
 * This means that category "second" now also has the property called "hello"
 *
 * @author  Andreas Mecky andreas.mecky@xcom.de
 * @author  Terry Dye terry.dye@xcom.de
 */
public class CDataConfigParser extends AbstractConfigParser {
                    
    public CDataConfigParser() {        
    }
        
    /**
     *  Description of the Method
     *
     *@param  doc  Description of the Parameter
     */
    public Configuration parse(Document doc,String configName) {        
        ExtensibleConfiguration configuration = new ExtensibleConfiguration(configName);
        String currentCategory;
        getVariables(doc,configuration);   
        getIncludeProperties(doc, configuration);
        getBaseConfigName(doc, configuration);
        // first we get all nodes where the element is category
        NodeList nl = doc.getElementsByTagName("category");
        for (int i = 0; i < nl.getLength(); i++) {
            // now we get every node from the list
            Node n = nl.item(i);
            // and get the name attribute for this category
            NamedNodeMap curAtt = n.getAttributes();
            Node curNode = curAtt.getNamedItem("name");
            currentCategory = curNode.getNodeValue();                        
            Category ec = new DefaultCategory(currentCategory);
            configuration.setCategory(ec);
            curNode = curAtt.getNamedItem("extends");
            if ( curNode != null ) {
                ec.setExtendsCategory(curNode.getNodeValue());
            }
            // now we process all children for this category
            for (Node child = n.getFirstChild(); child != null; child = child.getNextSibling()) {
                // we take the tag name as property name                
                if ( child.getNodeType() == 1 && child.getFirstChild() != null ) {
                    String name = child.getNodeName();                                  
                    String value = child.getFirstChild().getNodeValue();                     
                    if (name != null && value != null) {
                        // the key is always category/name
                        // e.g. general/congig_file                                                
                        configuration.setProperty(name,value,currentCategory);
                    }                
                }
            }
        } 
        return configuration;
    }
    
}
