package org.jconfig.parser;

import org.jconfig.Configuration;
import org.jconfig.NestedCategory;
import org.jconfig.NestedConfiguration;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * 
 * @author Andreas Mecky andreas.mecky@xcom.de
 * @author Terry Dye terry.dye@xcom.de
 */
public class NestedConfigParser extends AbstractConfigParser {

    private boolean doTrimValue = false;

    public NestedConfigParser() {
        String trimStr = System.getProperty("jconfig.trimValue");
        if (trimStr != null && trimStr.length() > 0) {
            if (trimStr.equalsIgnoreCase("yes")
                    || trimStr.equalsIgnoreCase("true")) {
                doTrimValue = true;
            }
        }
    }

    /**
     * Description of the Method
     * 
     * @param doc
     *            Description of the Parameter
     */
    public Configuration parse(Document doc, String configName) {
        Configuration configuration = new NestedConfiguration(configName);
        String currentCategory;
        getBaseConfigName(doc, configuration);
        getVariables(doc, configuration);
        getIncludeProperties(doc, configuration);
        Element root = doc.getDocumentElement();
        // first we get all nodes where the element is category
        for (Node child = root.getFirstChild(); child != null; child = child
                .getNextSibling()) {
            if (child.getNodeName().equals("category")) {
                NamedNodeMap curAtt = child.getAttributes();
                Node curNode = curAtt.getNamedItem("name");
                currentCategory = curNode.getNodeValue();
                NestedCategory category = new NestedCategory(currentCategory);
                getCategory(child, category, configName);
                configuration.setCategory(category);
            }
        }
        return configuration;
    }

    private void getCategory(Node n, NestedCategory cat, String configName) {
        // now we process all children for this category
        for (Node child = n.getFirstChild(); child != null; child = child
                .getNextSibling()) {
            // we take the tag name as property name
            if (child.getNodeType() == 1) {
                String name = child.getNodeName();
                if (name.equals("category")) {
                    NamedNodeMap curAtt = child.getAttributes();
                    Node nNode = curAtt.getNamedItem("name");
                    String categoryName = nNode.getNodeValue();
                    NestedCategory category = new NestedCategory(categoryName);
                    category.setConfigurationName(configName);
                    cat.addCategory(category);
                    getCategory(child, category, configName);
                } else {
                    if (child.getFirstChild() != null) {
                        String value = child.getFirstChild().getNodeValue();
                        if (name != null && value != null) {
                            cat.setProperty(name, (this.doTrimValue) ? value
                                    .trim() : value);
                        }
                    }
                }

            }
        }
    }

}