package org.jconfig.parser;

import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;

import org.jconfig.Configuration;
import org.jconfig.VariableManager;
import org.jconfig.error.ErrorReporter;
import org.jconfig.utils.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 * @author  Andreas Mecky andreas.mecky@xcom.de
 * @author  Terry Dye terry.dye@xcom.de
 */
public abstract class AbstractConfigParser implements ConfigurationParser {
    
    private static ExtensionGraph eg = new ExtensionGraph();
    
    public AbstractConfigParser() {
    }
    
    /**
     *  Gets the variables attribute of the ConfigurationManager object
     *
     *@param  doc  Description of the Parameter
     *@return      The variables value
     */
    protected void getVariables(Document doc,Configuration config) {
        NodeList nl = doc.getElementsByTagName("variables");
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            for (Node child = n.getFirstChild(); child != null; child = child.getNextSibling()) {
                // get all vraibles
                if (child.getNodeName().equals("variable")) {
                    NamedNodeMap myAtt = child.getAttributes();
                    Node myNode = myAtt.getNamedItem("name");
                    String name = myNode.getNodeValue();
                    myNode = myAtt.getNamedItem("value");
                    String value = myNode.getNodeValue();
                    if (name != null && value != null) {   
                        config.setVariable(name, value);
                    }
                }
            }
        }
    }
    
    /**
     * check if this configuration extends another configuration defined
     * in the top level tag like this: <br/>
     * <properties extends="base">
     */
    protected void getBaseConfigName(Document doc,Configuration config) {
        Element nl = doc.getDocumentElement();
        NamedNodeMap myAtt = nl.getAttributes();
        Node myNode = myAtt.getNamedItem("extends");
        if ( myNode != null ) {
            String name = myNode.getNodeValue();
            eg.addExtension(config.getConfigName(),name);
            if ( !eg.checkDependencies(config.getConfigName())) {
                config.setBaseConfiguration(name);
            }
            else {                
                ErrorReporter.getErrorHandler().reportError("The base configuration is invalid since there will be a circular dependency. Found dependency:"+config.getConfigName()+"/"+name);
            }
        }
    }
    
    protected void getIncludeProperties(Document doc,Configuration config) {        
        NodeList nl = doc.getElementsByTagName("include");        
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            NamedNodeMap myAtt = n.getAttributes();
            Node myNode = myAtt.getNamedItem("properties");
            if ( myNode != null ) {
                loadProperties(myNode.getNodeValue(),config.getConfigName());
                config.addInclude(IncludeEntry.PROPERTIES, myNode.getNodeValue());
            }            
        }
    }
    
    private void loadProperties(String propName,String configName) {            
        try {
            InputStream inputStream = null;
            ResourceLocator locator = new ResourceLocator(propName);
            inputStream = locator.getInputStream();
            if ( inputStream == null ) {
                ErrorReporter.getErrorHandler().reportError("Cannot find the properties file");                
            }
            else {
                VariableManager varman = VariableManager.getInstance();
                Properties myProperties = new Properties();
                myProperties.load(inputStream);
                Enumeration propertyNames = myProperties.propertyNames();
                while (propertyNames.hasMoreElements()) {
                    String name = (String) propertyNames.nextElement();
                    String value = myProperties.getProperty(name);                    
                    varman.addIncludedVariable(name,value, configName);
                }
            }
        } catch (Exception e) {            
            ErrorReporter.getErrorHandler().reportError("The file cannot be loaded",e);        
        }
    }
    
    public abstract Configuration parse(Document doc,String configName);
}
