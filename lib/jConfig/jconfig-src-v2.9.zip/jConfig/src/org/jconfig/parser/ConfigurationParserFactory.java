/*
 * ConfigurationParserFactory.java
 *
 * Created on 3. September 2003, 12:39
 */

package org.jconfig.parser;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
/**
 * The ConfigurationParserFactory determines which configuration parser
 * for the specified configuration should be used. This can be defined
 * in the jconfig.properties or as system property. <br>
 * The jconfig.properties must contain a property called "parser.{configname}"
 * (to define the parser for a specific configuration) or a property "parser".
 * This property must contain the fully qualified class name of the parser
 * <br>
 * If no jconfig.properties are found it will look for a system property
 * called "jconfig.parser". <br>
 * If nothing is found then it will use the DefaultConfigParser
 *
 * @author  Andreas Mecky andreas.mecky@xcom.de
 * @author  Terry Dye terry.dye@xcom.de
 */
public class ConfigurationParserFactory {
    
    /** Creates a new instance of ConfigurationParserFactory */
    private ConfigurationParserFactory() {
    }
    
    public static ConfigurationParser getParser(String configName) {        
        String configParser = getParserClassName(configName);        
        if ( configParser == null ) {
            return getDefaultParser();
        }
        else {
            try {
                Class clazz = Class.forName(configParser);                
                return (ConfigurationParser)clazz.newInstance();
            }
            catch (Exception e) { 
                e.printStackTrace();
            }
            return getDefaultParser();
        }
    }
    
    /**
     * This method will try to find the class name of the specified configuration.
     * The first step is to check if we have jconfig.properties in the classpath
     * and a parser.{configname} entry. If not found the method looks for a parser
     * entry in the properties file. If not found or no properties are found it
     * will check for a system property called "jconfig.parser". At the end it
     * will return "org.jconfig.parser.DefaultConfigParser" is nothing is found.
     */
    private static String getParserClassName(String configName) {
        InputStream is = ConfigurationParserFactory.class.getClassLoader().getResourceAsStream("jconfig.properties");
        if ( is != null ) {
            try {
                Properties props = new Properties();
                props.load(is);
                String testName = "parser."+configName;
                String value = props.getProperty(testName);
                if ( value != null ) {
                    return value;
                }
                else {
                    value = props.getProperty("parser");
                    if ( value != null ) {
                        return value;
                    }
                }
            }
            catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }        
        String configParser = System.getProperty("jconfig.parser"); 
        if ( configParser != null ) {                
            return configParser;
        }        
        return null;
    }
    
    /**
     * This method will return the desired default configuration parser.
     * Currently this is the DefaultConfigParser. If you wish to use
     * a different default parser then change the return value.
     * 
     * @return the default configuration parser
     */
    private static ConfigurationParser getDefaultParser() {
        return new DefaultConfigParser();
        // return new NestedConfigParser();        
    }
    
}
