package org.jconfig.parser;

import org.jconfig.Configuration;
import org.jconfig.DefaultConfiguration;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 *
 * @author  Andreas Mecky andreas.mecky@xcom.de
 * @author  Terry Dye terry.dye@xcom.de
 */
public class AdvancedConfigParser implements ConfigurationParser {
                    
    public AdvancedConfigParser() {        
    }
        
    /**
     *  Gets the variables attribute of the ConfigurationManager object
     *
     *@param  doc  Description of the Parameter
     *@return      The variables value
     */
    private static void getVariables(Document doc,Configuration config) {        
        NodeList nl = doc.getElementsByTagName("variables");
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);            
            for (Node child = n.getFirstChild(); child != null; child = child.getNextSibling()) {
                // get all vraibles
                if (child.getNodeName().equals("variable")) {
                    NamedNodeMap myAtt = child.getAttributes();
                    Node myNode = myAtt.getNamedItem("name");
                    String name = myNode.getNodeValue();
                    myNode = myAtt.getNamedItem("value");
                    String value = myNode.getNodeValue();
                    if (name != null && value != null) {
                        // we store the name as ${name} so we have
                        // it directly the way it is used
                        //String rname = "${" + name + "}";
                        //config.setVariable(rname, value);
                        config.setVariable(name, value);
                    }
                }
            }
        }        
    }

    /**
     *  Description of the Method
     *
     *@param  doc  Description of the Parameter
     */
    public Configuration parse(Document doc,String configName) {        
        Configuration configuration = new DefaultConfiguration(configName);
        String currentCategory;
        getVariables(doc,configuration);
        // first we get all nodes where the element is category
        NodeList nl = doc.getElementsByTagName("category");
        for (int i = 0; i < nl.getLength(); i++) {
            // now we get every node from the list
            Node n = nl.item(i);
            // and get the name attribute for this category
            NamedNodeMap curAtt = n.getAttributes();
            Node curNode = curAtt.getNamedItem("name");
            currentCategory = curNode.getNodeValue();            
            configuration.setCategory(currentCategory);
            // now we process all children for this category
            for (Node child = n.getFirstChild(); child != null; child = child.getNextSibling()) {
                // we take the tag name as property name                
                if ( child.getNodeType() == 1 && child.getFirstChild() != null ) {
                    String name = child.getNodeName();                                  
                    String value = child.getFirstChild().getNodeValue();                    
                    if (name != null && value != null) {
                        // the key is always category/name
                        // e.g. general/congig_file                                                
                        configuration.setProperty(name,value,currentCategory);
                    }                
                }
            }
        } 
        return configuration;
    }
    
}
