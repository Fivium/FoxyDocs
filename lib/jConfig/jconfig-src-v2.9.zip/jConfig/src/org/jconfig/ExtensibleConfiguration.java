/*
 * Configuration.java
 *
 * Created on 19. November 2002, 22:27
 */

package org.jconfig;

import java.io.Serializable;
import java.util.Iterator;
import java.util.SortedMap;

/**
 * This class is the configuration itself. The Configuration is
 * useful if one wants to manage multiple configurations. A single
 * instance of the Configuration may contain, for example, information
 * for one application or user.
 *
 * @author Andreas Mecky andreas.mecky@xcom.de
 * @author Terry Dye terry.dye@xcom.de
 */
public class ExtensibleConfiguration extends DefaultConfiguration implements Serializable {
    
    /**
     * The constructor that creates a new configuration
     * with one empty category called "general". This
     * category is also the default category.
     *
     * @param configName the name of the configuration
     */
    public ExtensibleConfiguration(String configName) {
        super(configName);
    }
    
    
    public String getProperty(String key,String defaultValue,String categoryName) {
        if (key == null) {
            return defaultValue;
        }
        Category category = (Category)getCategory(categoryName);
        String tmp = category.getProperty(key);
        if ( tmp == null && category.getExtendsCategory() != null ) {
            return getProperty(key,defaultValue,category.getExtendsCategory());
        }
        // property not found so look in mainCategory
        // if it is not already the mainCategory
        // currently not supported
        /*
        if ( tmp == null && !isMainCat) {
            category = getCategory(mainCategory);
            tmp = category.getProperty(key);
        }
         */
        if ( tmp == null ) {
            if ( baseConfigName != null ) {
                Configuration cfg = ConfigurationManager.getConfiguration(baseConfigName);
                tmp = cfg.getProperty(key,defaultValue,categoryName);            
            }
            else {
                tmp = defaultValue;
            }      
        }
        return tmp;
    }
    
    /**
     * This method converts the Configuration into a String
     * which looks like XML.
     *
     * @return the Configuration as String in XML format
     */
    public String getXMLAsString() {
        StringBuffer buffer = new StringBuffer();        
        // first we will write out the variable block
        // if we have some
        buffer.append("<?xml version=\"1.0\"");
        if ( getEncoding() != null ) {
            buffer.append(" encoding=\""+getEncoding()+"\"");
        }
        buffer.append(" ?>\n");
        buffer.append("<properties");
        if ( baseConfigName != null ) {
            buffer.append(" extends=\"");
            buffer.append(baseConfigName);
            buffer.append("\"");
        }
        buffer.append(">\n");
        addIncludeBlock(buffer);
        addVariableBlock(buffer);
        // now we are writing out all categories with
        // their properties
        String[] cats = getCategoryNames(false);
        for (int i = 0; i < cats.length; i++) {
            Category ec = (Category)getCategory(cats[i]);
            buffer.append("  <category name=\"");
            buffer.append(escapeForXML(ec.getCategoryName()));
            buffer.append("\"");
            if ( ec.getExtendsCategory() != null ) {
                buffer.append(" extends=\"");
                buffer.append(escapeForXML(ec.getExtendsCategory()));
                buffer.append("\"");
            }
            buffer.append(">\n");
            SortedMap sm = getSortedProperties(ec.getCategoryName(),false);
            if (sm != null) {
                Iterator nit = sm.keySet().iterator();
                while (nit.hasNext()) {
                    String name = (String) nit.next();
                    String value = (String)sm.get(name);                 
                    buffer.append("    <");
                    buffer.append(escapeForXML(name));
                    buffer.append(">");
                    // do not convert the value
                    buffer.append(escapeForXML(value));
                    buffer.append("</");
                    buffer.append(escapeForXML(name));
                    buffer.append(">\n");
                }                
                buffer.append("  </category>\n");
            }
        }
        buffer.append("</properties>\n");
        return buffer.toString();
    }
    
}
