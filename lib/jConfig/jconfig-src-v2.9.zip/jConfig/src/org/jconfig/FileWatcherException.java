package org.jconfig;

/**
 * This exception indicates that an exception occurs during the life-cycle of a FileWatcher.
 * @author Steve Braun <steve.braun@cogeco.ca>
 */
 
public class FileWatcherException extends Exception
{
  public FileWatcherException( String msg )
  {
    super( msg );
  }
}