/*
 * ConfigurationFileLoader.java
 *
 * Created on 28. April 2002, 14:45
 */

package org.jconfig.handler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.DefaultConfiguration;
import org.jconfig.error.ErrorReporter;
import org.jconfig.parser.ConfigurationParser;
import org.jconfig.utils.ResourceLocator;
/**
 * The PropertiesFileHandler can read a java-properties file
 * and store all entries inside the default category (general)
 * with the given property name and value. It is meant to be
 * a helper to convert property files into the structure of jConfig.
 * After you have read a property you can use for example the XMLFileHandler
 * to save it in XML form.
 *
 * @author  Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public class PropertiesFileHandler extends AbstractHandler {
    
    private File file;
    
    /**
     * Default constructor
     */
    public PropertiesFileHandler() {
    }
    
    /**
     * Constructor with filename
     * @param filename
     */
    public PropertiesFileHandler(String filename) {
        this(new File(filename));        
    }
    
    /**
     * Constructor with File
     * @param file
     */
    public PropertiesFileHandler(File file) {
        this.file = file;
        addFileListener(this);
    }
    
    /**
     * This method sets the file that will be processed
     *
     * @param file the file
     */
    public void setFile(File file) {
        this.file = file;
    }
    
    /**
     * @throws ConfigurationManagerException  */
    public synchronized Configuration load(String configName) throws ConfigurationManagerException {
        return loadPropertiesFile(file,configName);
    }
    
    private Configuration loadPropertiesFile(File file,String configName) throws ConfigurationManagerException {
        Configuration config = new DefaultConfiguration(configName);
        if ( file == null ) {
        	ErrorReporter.getErrorHandler().reportError("The file is NULL");
            throw new ConfigurationManagerException("The file is NULL");
        }
        try {
            InputStream inputStream = null;
            if(file.exists()) {
                inputStream = new FileInputStream(file);
            } else {
                ResourceLocator locator = new ResourceLocator(file.getName());
                inputStream = locator.getInputStream();
            }
            if ( inputStream == null ) {
            	ErrorReporter.getErrorHandler().reportError("Cannot find the properties file");
                throw new ConfigurationManagerException("Cannot find the properties file");
            }
            Properties myProperties = new Properties();
            myProperties.load(inputStream);
            Enumeration propertyNames = myProperties.propertyNames();
            while (propertyNames.hasMoreElements()) {
                String name = (String) propertyNames.nextElement();
                String value = myProperties.getProperty(name);
                config.setProperty(name, value);
            }
        } catch (Exception e) {
        	ErrorReporter.getErrorHandler().reportError("The file cannot be loaded",e);
            throw new ConfigurationManagerException("The file cannot be loaded:"+e.getMessage());
        }
        config.resetCreated();
        return config;
    }
    
    /** This method should store all categories and properties.
     * @throws ConfigurationManagerException
     */
    public void store(Configuration configuration) throws ConfigurationManagerException {
        // this will store the properties for a certain category
        String[] categories = configuration.getCategoryNames();
        try {
            // let's open the file
            FileWriter fw = new FileWriter(file);
            // and write the header
            fw.write("#\n");
            fw.write("# automatically generated properties file\n");
            fw.write("#\n");
            // now we walk through all categories
            for ( int i = 0; i < categories.length;i++) {
                // write the category as comment
                fw.write("#\n");
                fw.write("# category: " + categories[i] + "\n");
                fw.write("#\n");
                // now we get all properties for this category
                String[] propNames = configuration.getPropertyNames(categories[i]);
                // here we walk through the properties
                for ( int j = 0; j < propNames.length;j++) {
                    // and write it to the file
                    // form category.property=value
                    fw.write(categories[i] + "." + propNames[j] + "=" + configuration.getProperty(propNames[j],"",categories[i]) + "\n");
                }
            }
            // close the file because we are done
            fw.close();
        } catch (Exception e) {
        	ErrorReporter.getErrorHandler().reportError("The file cannot be saved",e);
            throw new ConfigurationManagerException("The file cannot be saved");
        }
    }
    
    /**
     * @see org.jconfig.handler.AbstractHandler#getFile()
     */
    public File getFile() {
        return file;
    }
	
	public Configuration load(String configurationName, ConfigurationParser parser) throws ConfigurationManagerException {
		throw new ConfigurationManagerException("Using a specific parser with this handler is not supported");
	}
}
