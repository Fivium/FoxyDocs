/*
 * ConfigServerHandler.java
 *
 * Created on 25. Januar 2004, 18:58
 */

package org.jconfig.handler;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.error.ErrorReporter;
/**
 *
 * @author  Administrator
 */
public class ConfigServerHandler extends URLHandler {
    
    /** Creates a new instance of ConfigServerHandler */
    public ConfigServerHandler() {
    }
    
    public synchronized Configuration load() throws ConfigurationManagerException {
        String myURL = getURL();
        if ( !myURL.startsWith("jconfig://" ) ) {
        	ErrorReporter.getErrorHandler().reportError("Wrong URL. Must start with jconfig://. Syntax: jconfig://server:port/configname");
            throw new ConfigurationManagerException("Wrong URL. Must start with jconfig://. Syntax: jconfig://server:port/configname");
        }
        myURL = myURL.substring(10);
        if ( myURL.indexOf("/") == -1 ) {
        	ErrorReporter.getErrorHandler().reportError("Wrong URL. The configname is missing. Syntax: jconfig://server:port/configname");
            throw new ConfigurationManagerException("Wrong URL. The configname is missing. Syntax: jconfig://server:port/configname");
        }
        // TODO: check if this is correct
        int pos = myURL.indexOf("/");
        if ( (pos +1 ) > myURL.length() ) {
        	ErrorReporter.getErrorHandler().reportError("Wrong URL. The configname is missing. Syntax: jconfig://server:port/configname");
            throw new ConfigurationManagerException("Wrong URL. The configname is missing. Syntax: jconfig://server:port/configname");
        }
        String name = myURL.substring(pos+1);                
        myURL = "http://"+myURL;        
        return load( myURL,name );        
    }
    
    public synchronized Configuration load(String configName) throws ConfigurationManagerException {
        String myURL = getURL();
        if ( !myURL.startsWith("jconfig://" ) ) {
        	ErrorReporter.getErrorHandler().reportError("Wrong URL. Must start with jconfig://. Syntax: jconfig://server:port/configname");
            throw new ConfigurationManagerException("Wrong URL. Must start with jconfig://. Syntax: jconfig://server:port/configname");
        }
        myURL = myURL.substring(10);
        if ( myURL.indexOf("/") == -1 ) {
        	ErrorReporter.getErrorHandler().reportError("Wrong URL. The configname is missing. Syntax: jconfig://server:port/configname");
            throw new ConfigurationManagerException("Wrong URL. The configname is missing. Syntax: jconfig://server:port/configname");
        }
        // TODO: check if this is correct
        int pos = myURL.indexOf("/");
        if ( (pos +1 ) > myURL.length() ) {
        	ErrorReporter.getErrorHandler().reportError("Wrong URL. The configname is missing. Syntax: jconfig://server:port/configname");
            throw new ConfigurationManagerException("Wrong URL. The configname is missing. Syntax: jconfig://server:port/configname");
        }
        String name = myURL.substring(pos+1);                
        myURL = "http://"+myURL;        
        return load( myURL,name );        
    }
    
}
