/*
 * ScriptHandler.java
 *
 * Created on 17. Dezember 2003, 21:52
 */

package org.jconfig.handler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Vector;

import org.jconfig.Category;
import org.jconfig.Configuration;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.DefaultCategory;
import org.jconfig.ExtensibleConfiguration;
import org.jconfig.error.ErrorReporter;
import org.jconfig.parser.ConfigurationParser;
import org.jconfig.utils.ResourceLocator;
/**
 * Configurations can be loaded from many types of files. The ScriptHandler
 * is just another implementation of this. The text file is expected to be
 * called [your_file_name]_config.script. Example "my_config.script".
 *
 * A my_config.script could look like this:
 *
 * variables {
 *   basepath = /tmp
 * }
 *
 * category general {
 *   hello = world
 * more = words
 * }
 *
 * category special extends general {
 *   hello = me
 *   more = override
 * }
 *
 * category stuff extends special {
 *   my crap = is real crap
 * }
 *
 * You can use the ConfigurationHandler directly:
 *
 * ScriptHandler scriptHandler = new ScriptHandler();
 * try {
 *   Configuration cfg = scriptHandler.load("my");
 *   cfg.getCategory("general").getProperty("hello"); // equals world
 * } catch ( Exception e ) {
 *   e.printStackTrace();
 * }
 *
 * @author Andreas Mecky
 * @author Terry Dye
 */
public class ScriptHandler implements ConfigurationHandler {

    /**
     * Constructs a ScriptHandler. Nothing special happens during construction.
     */
    public ScriptHandler() {
    }

    /**
     * This method loads all files that are found ending with "_config.script".
     *
     * Example: my_config.script
     *
     * @param configurationName The name of the file to be found.
     * @return The configured/loaded Configuration
     * @throws ConfigurationManagerException thrown if the "_config.script" isn't found
     */
    public Configuration load(String configurationName) throws ConfigurationManagerException {
        String fileName = configurationName+"_config.script";
        try {
            ResourceLocator locator = new ResourceLocator(fileName);
            InputStream is = locator.findResource(fileName);
            BufferedReader nis = new BufferedReader(new InputStreamReader(is));            
            String line;
            Vector content = new Vector();
            while ((line=nis.readLine()) != null ) {
                content.add(line);
            }
            nis.close();
            int braces = 0;            
            for ( int i = 0; i < content.size();i++) {
                String tmp = (String)content.get(i);                
                if ( tmp.indexOf("{") != -1 ) {
                    braces++;
                }
                else if ( tmp.indexOf("}") != -1 ) {
                    braces--;
                }
            }
            if ( braces != 0 ) {
            	ErrorReporter.getErrorHandler().reportError("Unmatched brackets in script file");
                throw new ConfigurationManagerException("Unmatched brackets in script file");
            }
            Configuration cfg = new ExtensibleConfiguration(configurationName);
            boolean process = false;
            String currentCategoryName = null;
            for ( int i = 0; i < content.size();i++) {
                String tmp = (String)content.get(i);
                tmp = tmp.trim();
                if ( process ) {
                    if ( tmp.startsWith("}") ) {
                        process = false;                     
                    }
                    else {                                                
                        String left = tmp.substring(0,tmp.indexOf("=")-1);
                        left = left.trim();
                        String right = tmp.substring(tmp.indexOf("=")+1);
                        right = right.trim();                                                
                        cfg.setProperty(left,right,currentCategoryName);                        
                    }
                }
                if ( tmp.startsWith("category") && tmp.indexOf("{") != -1 ) {
                    process = true;
                    String name = tmp.substring(9);
                    name = name.substring(0,name.indexOf("{"));
                    name = name.trim();                    
                    String extend = null;
                    if ( tmp.indexOf(" extends ") != -1 ) {
                        extend = name.substring(name.indexOf(" extends ")+9);
                        extend = extend.trim();
                        name = name.substring(0,name.indexOf(" extends "));                            
                    }
                    Category ec = new DefaultCategory(name);
                    if ( extend != null ) {
                        ec.setExtendsCategory(extend);
                    }
                    cfg.setCategory(ec);
                    currentCategoryName = name;
                }
            }
            return cfg;
        }
        catch (IOException e) {
        	ErrorReporter.getErrorHandler().reportError("Error while trying to read file",e);
            throw new ConfigurationManagerException("Error while trying to read file");
        }        
    }

    /**
     * This method is not yet implemented!
     * @param configuration
     * @throws ConfigurationManagerException
     */
    public void store(Configuration configuration) throws ConfigurationManagerException {
        throw new RuntimeException("not yet implemented");
    }
    
	public Configuration load(String configurationName, ConfigurationParser parser) throws ConfigurationManagerException {
		throw new ConfigurationManagerException("Using a specific parser with this handler is not supported");
	}
}
