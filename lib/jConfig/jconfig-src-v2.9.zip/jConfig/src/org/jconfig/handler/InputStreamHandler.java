/*
 * ConfigurationFileLoader.java
 *
 * Created on 28. April 2002, 14:45
 */

package org.jconfig.handler;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.error.ErrorReporter;
import org.jconfig.parser.ConfigurationParser;
import org.jconfig.parser.ConfigurationParserFactory;
import org.jconfig.utils.ConfigErrorHandler;
import org.jconfig.utils.ResourceLocator;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
/**
 * This class is an implementation of the ConfigurationHandler interface.
 * It tries to find the file with the given name inside the classpath with
 * getClassLoader().getResourceAsStream(fileName). This handler is used
 * as default by the ConfigurationManager.
 *
 * @author  Andreas Mecky andreas.mecky@xcom.de
 * @author Terry Dye terry.dye@xcom.de
 */
public class InputStreamHandler extends BaseXMLHandler implements ConfigurationHandler {
    
    private boolean validate = false;
    private String filename;
    
    /**
     * Default constructor
     */
    public InputStreamHandler() {
    }
    
    /**
     * Constructor with filename
     * @param filename
     */
    public InputStreamHandler(String filename) {
        this.filename = filename;
    }
    
    /**
     * Sets the filename
     *
     * @param the name of the file that the InputStreamHandler will search in the classpath
     */
    public void setFileName(String fileName) {
        this.filename = fileName;
    }
    
    /**
     * Defines if the xml file should be validated using a DTD or not.
     * The default setting is false.
     *
     * @param if true then it will validate the xml file.
     */
    public void setValidation(boolean validate) {
        this.validate = validate;
    }
    
    /**
     * Loads the configuration from a xml file.
     * @throws ConfigurationManagerException
     */
    public synchronized Configuration load(String configurationName) throws ConfigurationManagerException {
		ConfigurationParser parser = ConfigurationParserFactory.getParser(configurationName); 
		return load(configurationName,parser);
    }
    
    /**
     *  This method will read in a file and generate the properties
     *
     *@param  is                              The inputstream
     *@throws  ConfigurationManagerException  if the file cannot be processed
     */
    public Configuration load(String configurationName,ConfigurationParser parser) throws ConfigurationManagerException {
		InputStream is = null;
        try {
            is = new ResourceLocator(filename).getInputStream();
            if ( is == null ) {
            	ErrorReporter.getErrorHandler().reportError("File not found:"+filename);
                is = new ResourceLocator("config.xml").getInputStream();
            }
        } catch (IOException e) {
        	ErrorReporter.getErrorHandler().reportError("Cannot load file:"+filename,e);
            throw new ConfigurationManagerException(e.getLocalizedMessage());
        }
        if ( is != null ) {
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        // set the validation flag (true if it should be validated)
	        dbf.setValidating(validate);
	        DocumentBuilder db = null;
	        try {
	            db = dbf.newDocumentBuilder();
	        } catch (ParserConfigurationException pce) {
	        	ErrorReporter.getErrorHandler().reportError("The parser cannot create a new document builder",pce);
	            throw new ConfigurationManagerException("The parser cannot create a new document builder: " + pce.getMessage());
	        }
	        // if we have to validate then we need to define an error handler here
	        if (validate) {
	            try {
	                // Set an ErrorHandler before parsing
	                OutputStreamWriter errorWriter =
	                new OutputStreamWriter(System.err, "UTF-8");
	                db.setErrorHandler(new ConfigErrorHandler(new PrintWriter(errorWriter, true)));
	                //new MyErrorHandler(new PrintWriter(errorWriter, true)));
	            } catch (Exception e) {
	            	ErrorReporter.getErrorHandler().reportError("The parser cannot set up the error handler",e);
	                throw new ConfigurationManagerException("The parser cannot set up the error handler");
	            }
	        }
	        Document doc = null;
	        try {
	            doc = db.parse(is);
	        } catch (SAXException se) {
	        	ErrorReporter.getErrorHandler().reportError("The parser cannot parse the file",se);
	            throw new ConfigurationManagerException("The parser cannot parse the file: " + se.getMessage());
	        } catch (IOException ioe) {
	        	ErrorReporter.getErrorHandler().reportError("The parser cannot open the file",ioe);
	            throw new ConfigurationManagerException("The parser cannot open the file: " + ioe.getMessage());
	        }     
	        Configuration config = parser.parse(doc, configurationName);                
	        config.resetCreated();
	        return config;
		}
        else {
        	ErrorReporter.getErrorHandler().reportError("The file:"+filename+" not found in classpath");
            throw new ConfigurationManagerException("The file could not be found in the classpath");
        }
    }
    
    
    /**
     * This method should store all categories and properties.
     */
    public void store(Configuration configuration) throws ConfigurationManagerException {
        try {
			store( new ResourceLocator(filename).getFile(),configuration);
		} catch (IOException e) {
			ErrorReporter.getErrorHandler().reportError("File "+filename+" could not be found",e);
			throw new ConfigurationManagerException("File "+filename+" could not be found");
		}
    }
        
    /**
     * @see org.jconfig.handler.ConfigurationHandler#getFile()
     */
    public File getFile() {
        try {
			return new ResourceLocator(filename).getFile();
		} catch (IOException e) {
			ErrorReporter.getErrorHandler().reportError("File not found",e);
			return null;
		}
    }
}
