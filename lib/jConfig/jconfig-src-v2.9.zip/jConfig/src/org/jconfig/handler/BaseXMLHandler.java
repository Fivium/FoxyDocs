/*
 * BaseXMLHandler.java
 *
 * Created on 3. Februar 2003, 22:41
 */

package org.jconfig.handler;

import java.io.File;
import java.io.FileWriter;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.error.ErrorReporter;
/**
 * This class is used internally to save a configuration to a file.
 *
 * @author Andreas Mecky andreas.mecky@xcom.de
 * @author Terry Dye terry.dye@xcom.de
 */
public abstract class BaseXMLHandler extends AbstractHandler {
    
    private String encoding;
    
    
    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }
    /**
     *  This method will save the current categories and their properties to a
     *  file
     *
     *@param  file                               the file that will be generated
     *@exception  ConfigurationManagerException  Description of the Exception
     */
    protected void store(File file,Configuration config) throws ConfigurationManagerException {
    	// check if we have a %20 in the name
    	String fileName = file.getAbsolutePath();
    	if ( fileName.indexOf("%20") != -1 ) {
    		fileName = fileName.replaceAll("%20"," ");
    	}
    	file = new File(fileName);
        // this will store the properties for all categories
        try {
            // let's open the file
            FileWriter fw = new FileWriter(file);            
            fw.write(config.getXMLAsString());
            // close the file because we are done
            fw.close();
        } catch (Exception e) {
        	ErrorReporter.getErrorHandler().reportError("The file cannot be saved",e);
            throw new ConfigurationManagerException("The file cannot be saved:"+e.getMessage());
        }
    }
    
    public String getEncodingType(String str) {        
        if (str != null) {
            final String ENCODING = "encoding";
            int start = str.indexOf(ENCODING);
            String rest = str.substring(start + ENCODING.length());
            if ( rest.indexOf("'") != -1 ) {
                int beginQuote = rest.indexOf("'");
                if(beginQuote > -1) {
                    rest = rest.substring(beginQuote + 1);
                }
                int endQuote = rest.indexOf("'");
                if(beginQuote > -1) {
                    return rest.substring(0, endQuote);
                }
            }
            else {
                int beginQuote = rest.indexOf("\"");
                if(beginQuote > -1) {
                    rest = rest.substring(beginQuote + 1);
                }
                int endQuote = rest.indexOf("\"");
                if(beginQuote > -1) {
                    return rest.substring(0, endQuote);
                }
            }
            return str.substring(start + ENCODING.length());
        }
        return null;
    }
}
