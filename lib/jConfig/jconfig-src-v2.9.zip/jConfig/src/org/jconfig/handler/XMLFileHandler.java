/*
 * ConfigurationFileLoader.java
 *
 * Created on 28. April 2002, 14:45
 */

package org.jconfig.handler;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.error.ErrorReporter;
import org.jconfig.parser.ConfigurationParser;
import org.jconfig.parser.ConfigurationParserFactory;
import org.jconfig.utils.ConfigErrorHandler;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
/**
 * This class is nearly the same as the InputStreamHandler beside
 * that it takes a file and not the filename.
 *
 * @author  Andreas Mecky andreas.mecky@xcom.de
 * @author Terry Dye terry.dye@xcom.de
 */
public class XMLFileHandler extends BaseXMLHandler implements ConfigurationHandler {
    
    private boolean validate = false;
    private File file;
    
    public XMLFileHandler() {
    }
    
    public XMLFileHandler(String filename) {
        file = new File(filename);
        addFileListener(this);
    }
    /**
     * Sets the file that will be processed
     * @param file the file
     */
    public void setFile(File file) {
        this.file = file;
    }
    /**
     * This defines if the file will be vaidated using a DTD. The default
     * is false.
     *
     * @param validate defines the validation
     */
    public void setValidation(boolean validate) {
        this.validate = validate;
    }
    
    /**
     * @throws ConfigurationManagerException  */
    public synchronized Configuration load(String configurationName) throws ConfigurationManagerException {
		ConfigurationParser parser = ConfigurationParserFactory.getParser(configurationName);
        return load(file,configurationName,parser);
    }
	
	public Configuration load(String configurationName, ConfigurationParser parser) throws ConfigurationManagerException {
		return load(file,configurationName,parser);
	}
    
	public synchronized Configuration load(File file,String configurationName) throws ConfigurationManagerException {
		ConfigurationParser parser = ConfigurationParserFactory.getParser(configurationName);
        return load(file,configurationName,parser);
	}
    /**
     * @param file
     * @throws ConfigurationManagerException  */
    public synchronized Configuration load(File file,String configName,ConfigurationParser parser) throws ConfigurationManagerException {
        if (file == null) {
        	ErrorReporter.getErrorHandler().reportError("The file is NULL");
            throw new ConfigurationManagerException("The file is NULL");
        }
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        // set the validation flag (true if it should be validated)
        dbf.setValidating(validate);
        DocumentBuilder db = null;
        try {
            db = dbf.newDocumentBuilder();
        } catch (ParserConfigurationException pce) {
        	ErrorReporter.getErrorHandler().reportError("The parser cannot create a new document builder",pce);
            throw new ConfigurationManagerException("The parser cannot create a new document builder: "
            + pce.getMessage());
        }
        // if we have to validate then we need to define an error handler here
        if (validate) {
            try {
                // Set an ErrorHandler before parsing
                OutputStreamWriter errorWriter =
                new OutputStreamWriter(System.err, "UTF-8");
                db.setErrorHandler(
                new ConfigErrorHandler(new PrintWriter(errorWriter, true)));
            } catch (Exception e) {
            	ErrorReporter.getErrorHandler().reportError("The parser cannot set up the error handler");
                throw new ConfigurationManagerException("The parser cannot set up the error handler");
            }
        }
        Document doc = null;
        try {                        
            FileInputStream fis = new FileInputStream(file);                       
            
            InputSource ins = new InputSource(fis);
            BufferedInputStream buffy = new BufferedInputStream(fis);
            ins = new InputSource(buffy);            
            doc = db.parse(file);            
        } catch (SAXException se) {
        	ErrorReporter.getErrorHandler().reportError("The parser cannot parse the file",se);
            throw new ConfigurationManagerException(
            "The parser cannot parse the file: " + se.getMessage());
        } catch (IOException ioe) {
        	ErrorReporter.getErrorHandler().reportError("The parser cannot parse the file",ioe);
            throw new ConfigurationManagerException(
            "The parser cannot open the file: " + ioe.getMessage());
        }        
        Configuration config = parser.parse(doc, configName);
        try {
            java.io.BufferedReader in = new java.io.BufferedReader(new java.io.FileReader(file));
            String str;
            while ((str = in.readLine()) != null) {
                if(str.indexOf("encoding") > -1) config.setEncoding(getEncodingType(str));
            }
            in.close();
        }
        catch (Exception e) {
            // no problem here
        }
        config.resetCreated();
        return config;
    }
            
    /** This method should store all categories and properties.
     * @throws ConfigurationManagerException
     */
    public void store(Configuration configuration)
    throws ConfigurationManagerException {
        store(file, configuration);
    }
        /* (non-Javadoc)
         * @see org.jconfig.handler.AbstractHandler#getFile()
         */
    public File getFile() {
        return file;
    }
}
