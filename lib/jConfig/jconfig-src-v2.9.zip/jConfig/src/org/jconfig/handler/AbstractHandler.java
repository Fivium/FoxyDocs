package org.jconfig.handler;

import java.io.File;

import org.jconfig.ConfigurationManagerException;
import org.jconfig.FileWatcher;
import org.jconfig.error.ErrorReporter;
import org.jconfig.event.FileListener;
import org.jconfig.event.FileListenerEvent;
import org.jconfig.utils.ConfigurationUtils;
/**
 * @author Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public abstract class AbstractHandler implements ConfigurationHandler, FileListener {
    
    private FileWatcher watcher = null;
    
    /**
     * @see org.jconfig.event.FileListener#fileChanged(org.jconfig.event.FileListenerEvent)
     */
    public void fileChanged(FileListenerEvent event) {
        try {
            // TODO: put in the configurationName
            load(null);
        } catch (ConfigurationManagerException e) {
        	// technically we shouldn't get this, if we're already registered as a listener
        	ErrorReporter.getErrorHandler().reportError(e.getLocalizedMessage(), e);
        }
    }
    
    /**
     * Method addFileListener.
     * @param fileListener
     */
    public void addFileListener( FileListener fileListener ) {
        String val = ConfigurationUtils.getConfigProperty("jconfig.filewatcher","true");
        if ( val.equalsIgnoreCase("true") ) {
            watcher = new FileWatcher( getFile() );
            watcher.addFileListener( fileListener );
            watcher.start();
        }
    }
    
    /**
     * Method fireFireChangedEvent.
     * @param event
     */
    public void fireFireChangedEvent( FileListenerEvent event ) {
        if( watcher == null ) {
            throw new IllegalStateException("FileWatcher has not been set");
        } else {
            FileListener[] listener = watcher.getFileListeners();
            int num = listener.length;
            for( int i = 0 ; i < num ; i++ ) {
                listener[i].fileChanged( event );
            }
        }
    }
    
    /**
     * The File that should be "watched" for changes.
     * @return The File object
     */
    public abstract File getFile();
}
