/*
 * LDAPHandler.java
 *
 * Created on 8. Dezember 2002, 23:44
 */

package org.jconfig.handler;

//import java.util.Vector;
//import java.util.HashMap;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.DefaultConfiguration;
import org.jconfig.error.ErrorReporter;
import org.jconfig.parser.ConfigurationParser;

/**
 *
 * @author  Administrator
 */
public class LDAPHandler implements ConfigurationHandler {
    
    private String baseDN;
    
    public LDAPHandler() {
    }
    
    /** This method should read the configuration and then
     * set the categories and properties.
     * @throws ConfigurationManagerException
     */
    public Configuration load(String configurationName) throws ConfigurationManagerException {    
        InitialDirContext ctx = getContext();
        if ( ctx == null ) {
            throw new ConfigurationManagerException("There is no connection to the LDAP server");
        }
        Configuration config = new DefaultConfiguration(null);
        getCategories(ctx,config);
        getAllProperties(ctx,config);
        return config;
    }
    
    private void getCategories(InitialDirContext ctx,Configuration config) {
        try {
            SearchControls sctrl = new SearchControls();
            String filter = "(&(objectclass=organizationalUnit)(ou=*))";                        
            NamingEnumeration enm = ctx.search(baseDN, filter, sctrl);
            while (enm.hasMore()) {
                SearchResult sr = (SearchResult) enm.next();                
                config.setCategory(sr.getName());                
            }

        } catch (Exception e) {   
        	ErrorReporter.getErrorHandler().reportError(e.getLocalizedMessage(), e);
        }
    }

    private void getAllProperties(InitialDirContext ctx,Configuration config) {
    }

    /** This method should store all categories and properties.
     * @throws ConfigurationManagerException
     */
    public void store() throws ConfigurationManagerException {
        throw new RuntimeException("not yet implemented");
    }
    
    private InitialDirContext getContext() {
        Properties props = new Properties();
        try {
            InputStream is = getClass().getClassLoader().getResourceAsStream("ldap.properties");
            if ( is == null ) {
                return null;
            }
            props.load(is);
            Hashtable env = new Hashtable();
            // alle n�tigen Parameter in die Hashtable eintragen. Die Werte kommen aus der config.xml
            env.put(Context.INITIAL_CONTEXT_FACTORY, props.getProperty("Context", ""));
            env.put(Context.PROVIDER_URL, props.getProperty("Host", ""));
            env.put(Context.SECURITY_AUTHENTICATION, "simple");
            env.put(Context.SECURITY_PRINCIPAL, props.getProperty("RootDN", ""));
            env.put(Context.SECURITY_CREDENTIALS, props.getProperty("Password", ""));
            baseDN = props.getProperty("BaseDN","");
            return new InitialDirContext(env);
        }
        catch (Exception e) {
        	ErrorReporter.getErrorHandler().reportError(e.getLocalizedMessage(), e);
            return null;
        }
    }
    
    /** This method should store all categories and properties.
     * @throws ConfigurationManagerException
     */
    public void store(Configuration configuration) throws ConfigurationManagerException {
    	throw new RuntimeException("not yet implemented");
    }
	
	public Configuration load(String configurationName, ConfigurationParser parser) throws ConfigurationManagerException {
		throw new ConfigurationManagerException("Using a specific parser with this handler is not supported");
	}
        
}
