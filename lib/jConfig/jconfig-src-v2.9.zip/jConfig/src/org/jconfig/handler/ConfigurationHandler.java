/*
 * ConfigurationLoader.java
 *
 * Created on 28. April 2002, 14:41
 */

package org.jconfig.handler;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManagerException;
import org.jconfig.parser.ConfigurationParser;
/**
 * This interface defines all methods that must be implemented
 * by all Handler classes.
 *
 * @author  Andreas Mecky <andreas.mecky@xcom.de>
 * @author Terry Dye <terry.dye@xcom.de>
 */
public interface ConfigurationHandler {
    
    /**
     * This method loads a configuration and returns it
     * 
     * @param configurationName the name of the configuration
     * @return the Configuration
     * @throws ConfigurationManagerException
     */
    public Configuration load(String configurationName) throws ConfigurationManagerException;
	
	/**
	 * This method loads a configuration using a specific parser and returns it
	 * 
	 * @param configurationName the name of the configuration
	 * @param parser the parser that should be used
	 * @return the Configuration
	 * @throws ConfigurationManagerException
	 */
    public Configuration load(String configurationName,ConfigurationParser parser) throws ConfigurationManagerException;
	
    /**
     * This method should store all categories and properties.
     * 
     * @param configuration the Configuration that should be saved
     * @throws ConfigurationManagerException  
     */
    public void store(Configuration configuration) throws ConfigurationManagerException;
    
}

