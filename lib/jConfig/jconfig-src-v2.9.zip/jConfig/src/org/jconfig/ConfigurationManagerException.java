package org.jconfig;

public class ConfigurationManagerException extends Exception
{
	public ConfigurationManagerException (String msg)
	{
		super(msg);
	}
}

