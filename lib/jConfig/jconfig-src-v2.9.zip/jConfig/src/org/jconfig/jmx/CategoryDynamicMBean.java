package org.jconfig.jmx;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import javax.management.Attribute;
import javax.management.AttributeNotFoundException;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanConstructorInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanNotificationInfo;
import javax.management.MBeanOperationInfo;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.RuntimeOperationsException;

import org.jconfig.Category;
import org.jconfig.Configuration;
import org.jconfig.ConfigurationManager;

/**
 * This MBean represents a Category contained in a Configuration <br><br>
 * 
 * Attributes: 
 * <ul><li>Its own name</li>
 * <li>One attribute for each property the category contains</li></ul>
 * <br>
 * Operations: None
 * 
 *@author     Eduardo Macarron emacarron@euskalnet.net
 */
public class CategoryDynamicMBean extends AbstractDynamicMBean {

	private MBeanConstructorInfo[] dConstructors = new MBeanConstructorInfo[1];

	private ArrayList alAttributes = new ArrayList();

	private String dClassName = this.getClass().getName();

	private MBeanOperationInfo[] dOperations = new MBeanOperationInfo[0];
	private String dDescription =
		"This MBean acts as a management facade for categories.";

	private ObjectName objectName;	

	// dont keep an instance, it changes when reloading
	private String configurationName;
	private String categoryName;

	public CategoryDynamicMBean(
		ObjectName objectName,
		String configurationName,
		String categoryName) {

		this.configurationName = configurationName;
		this.categoryName = categoryName;
		this.objectName = objectName;
		buildDynamicMBeanInfo();
	}

	private void buildDynamicMBeanInfo() {

		Constructor[] constructors = this.getClass().getConstructors();
		dConstructors[0] =
			new MBeanConstructorInfo(
				"CategoryDynamicMBean(): Constructs a CategoryDynamicMBean instance",
				constructors[0]);

		// categoryName		
		alAttributes.add(
			new MBeanAttributeInfo(
				"name",
				"java.lang.String",
				"The name of this Category.",
				true,
				false,
				false));

		// now we have to crate one attribute per property found
		Configuration configuration =
			ConfigurationManager.getConfiguration(configurationName);
		Category category = configuration.getCategory(categoryName);
		Properties properties = category.getProperties();
		Enumeration propertiesEnum = properties.keys();

		while (propertiesEnum.hasMoreElements()) {

			String propertyName = (String) propertiesEnum.nextElement();

			alAttributes
				.add(new MBeanAttributeInfo(
					propertyName,
					"java.lang.String",
					"The name of this Property.",
					true,
					true,
			//clickable
			false));
		}
	}
	
	public MBeanInfo getMBeanInfo() {

		MBeanAttributeInfo[] attribs =
			new MBeanAttributeInfo[alAttributes.size()];
		alAttributes.toArray(attribs);

		MBeanInfo mb =
			new MBeanInfo(
				dClassName,
				dDescription,
				attribs,
				dConstructors,
				dOperations,
				new MBeanNotificationInfo[0]);
		
		return mb;
	}

	public Object invoke(
		String operationName,
		Object params[],
		String signature[])
		throws MBeanException, ReflectionException {

		// there are no operations on categories

		return null;
	}

	public Object getAttribute(String attributeName)
		throws AttributeNotFoundException, MBeanException, ReflectionException {

		// Check attributeName is not null to avoid NullPointerException later on
		if (attributeName == null) {
			throw new RuntimeOperationsException(
				new IllegalArgumentException("Attribute name cannot be null"),
				"Cannot invoke a getter of "
					+ dClassName
					+ " with null attribute name");
		}

		Object value = null;

		// Check for a recognized attributeName and call the corresponding getter
		if (attributeName.equals("name")) {
			value = categoryName;
		} else {
			Configuration configuration =
				ConfigurationManager.getConfiguration(configurationName);
			Category category = configuration.getCategory(categoryName);

			if (category.getProperty(attributeName) != null) {
				value = category.getProperty(attributeName);
			}
		}

		// there is no way to know if attribute exists on Configuration....
		if (false)
			throw (
				new AttributeNotFoundException(
					"Cannot find "
						+ attributeName
						+ " attribute in "
						+ dClassName));
		
		return value;
	}

	public void setAttribute(Attribute attribute)
		throws
			AttributeNotFoundException,
			InvalidAttributeValueException,
			MBeanException,
			ReflectionException {

		// Check attribute is not null to avoid NullPointerException later on
		if (attribute == null) {
			throw new RuntimeOperationsException(
				new IllegalArgumentException("Attribute cannot be null"),
				"Cannot invoke a setter of "
					+ dClassName
					+ " with null attribute");
		}

		String attributeName = attribute.getName();
		Object value = attribute.getValue();

		if (attributeName == null) {
			throw new RuntimeOperationsException(
				new IllegalArgumentException("Attribute name cannot be null"),
				"Cannot invoke the setter of "
					+ dClassName
					+ " with null attribute name");
		}
		

		Configuration configuration =
			ConfigurationManager.getConfiguration(configurationName);
		Category category = configuration.getCategory(categoryName);
		category.setProperty(attributeName, (String) value);
	}

	public void postRegister(java.lang.Boolean registrationDone) {
		// there are no MBeans to create		
	}
}
