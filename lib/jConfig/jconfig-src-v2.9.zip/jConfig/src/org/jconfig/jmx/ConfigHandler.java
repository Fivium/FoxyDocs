/*
 *  ConfigHandler.java
 *
 *  Created on 7. August 2002, 10:08
 */
package org.jconfig.jmx;

import java.io.File;
import java.net.URL;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManager;
import org.jconfig.handler.XMLFileHandler;
/**
 *@author     mecky
 *@created    7. August 2002
 */
public class ConfigHandler implements ConfigHandlerMBean {

    private String resourceName;
    private String configName;

    /**
     *  Constructor for the ConfigHandler object
     */
    public ConfigHandler() {        
    }
    

    /**
     *  Gets the configurationName attribute of the ConfigHandler object
     *
     *@return    The configurationName value
     */
    public String getConfigurationName() {
        return configName;
    }


    /**
     *  Gets the fileName attribute of the ConfigHandler object
     *
     *@return    The fileName value
     */
    public String getResourceName() {
        return resourceName;
    }
   
    /**
     *  Sets the configurationName attribute of the ConfigHandler object
     *
     *@param  configName  The new configurationName value
     */
    public void setConfigurationName(String configName) {
        if ( resourceName != null ) {
            load(resourceName,configName);
        }
        this.configName = configName;
    }


    /**
     *  Sets the fileName attribute of the ConfigHandler object
     *
     *@param  fileName  The new fileName value
     */
    public void setResourceName(String resourceName) {
        if ( configName != null ) {
            load(resourceName,configName);
        }
        this.resourceName = resourceName;
    }

    /**
     *  Description of the Method
     *
     *@return    Description of the Return Value
     */
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("ConfigHandler:\n");
        buffer.append("Resourcename:");
        buffer.append(resourceName);
        buffer.append("\nConfigname:");
        buffer.append(configName);        
        return buffer.toString();
    }


    /**
     *  Description of the Method
     */
    public void forceReload() {
        load(resourceName,configName);        
    }

    /**
     *  Gets the name attribute of the ConfigHandler object
     *
     *@return    The name value
     */
    public String getName() {
        return "jConfig:" + configName;
    }
    
    // Changed so that it can also read from URLs.
    // Thanx to Guy Rouillier <guyr@masergy.com> for the pathc
    private void load(String resourceName,String configName) {        
    	try {
            if ( configName == null ) {
                configName = "default";
            }
            ConfigurationManager myConfig = ConfigurationManager.getInstance();
            URL url = null;
            // If the string has a protocol on it, we'll assume it's an absolute
            // URL.  Otherwise, we'll assume it's a resource known to the 
            // classloader.
            if (resourceName.indexOf("://") >= 0)
               {
               url = new URL(resourceName);
               } // end if
            else
               {
               ClassLoader cl = Thread.currentThread().getContextClassLoader();
               url = cl.getResource(resourceName);
               } // end else

            if (url != null) {
                File file = new File(url.getFile());
                XMLFileHandler handler = new XMLFileHandler(file.getAbsolutePath());
                myConfig.load(handler, configName);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String showConfiguration() {
        Configuration myConfig = ConfigurationManager.getConfiguration(configName);
        if ( myConfig != null ) {
            StringBuffer buffer = new StringBuffer();
            buffer.append("<pre>");
            buffer.append(myConfig.toString());
            buffer.append("</pre>");
            return buffer.toString();
        }
        else {
            return null;
        }
    }
    
    public void removeProperty(String name, String category) {
        Configuration config = ConfigurationManager.getConfiguration(configName);
        config.removeProperty(name, category);
    }
    
    public void saveConfiguration() throws Exception {
        ConfigurationManager.getInstance().save(configName);
    }
    
    public void setProperty(String name, String value, String category) {
        Configuration config = ConfigurationManager.getConfiguration(configName);
        config.setProperty(name, value, category);
    }
    
}
