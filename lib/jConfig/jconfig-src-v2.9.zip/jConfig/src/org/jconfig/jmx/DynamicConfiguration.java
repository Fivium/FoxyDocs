/*
 * DynamicConfigurationMBean.java
 *
 * Created on 3. Mai 2004, 17:06
 */

package org.jconfig.jmx;

import javax.management.MBeanRegistration;
import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.jconfig.Configuration;
import org.jconfig.ConfigurationManager;
/**
 *
 * @author  mecky
 */
public class DynamicConfiguration implements DynamicConfigurationMBean, MBeanRegistration {
        
    private MBeanServer mBeanServer;
    private String name;
    private ObjectName objectName;
    
    public DynamicConfiguration() {
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
        Configuration config = ConfigurationManager.getConfiguration(name);
        loadConfiguration(name);
    }
    
    public void postDeregister() {
    }
    
    public void postRegister(Boolean booleanParam) {
    }
    
    public void preDeregister() throws java.lang.Exception {
    }
    
    public ObjectName preRegister(MBeanServer mBeanServer, ObjectName objectName) throws java.lang.Exception {
        this.mBeanServer = mBeanServer;
        this.objectName = objectName;
        return objectName;
    }
    
    public ObjectName loadConfiguration(String name) {
        
        System.out.println("loadConfiguration called:"+name);
        
        // test if MBean has been already loaded
        // it can also be tested asking directly to MBeanServer
        /*
        for (int i = 0; i < alAttributes.size(); i++) {
            MBeanAttributeInfo mai = (MBeanAttributeInfo) alAttributes.get(i);
            if (mai.getName().equalsIgnoreCase("configuration=" + name))
                return null; // shoud throw an exception??
        }
        */
        return registerConfigurationMBean(name);
    }
    
    ObjectName registerConfigurationMBean(String name) {
        
        ObjectName configurationObjectName = null;
        try {
            configurationObjectName =
            new ObjectName(objectName.getDomain(), "configuration", name);
            ConfigurationDynamicMBean configurationMBean =
            new ConfigurationDynamicMBean(configurationObjectName, name);
            mBeanServer.registerMBean(configurationMBean, configurationObjectName);
            
            // tenemos un atributo nuevo
            /*
            alAttributes
            .add(new MBeanAttributeInfo(
            "configuration=" + name,
            "javax.management.ObjectName",
            "The " + name + " configuration.",
            true,
            true,
            // this makes the object clickable
            false));
             */
            
        } catch (Exception e) {
            //log.error(
            //	"Could not add configurationMBean for [" + name + "].",
            //	e);
            e.printStackTrace();
        }
        return objectName;
    }
    
}
