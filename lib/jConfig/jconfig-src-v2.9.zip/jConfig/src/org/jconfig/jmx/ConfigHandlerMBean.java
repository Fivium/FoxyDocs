/*
 * ConfigurationHandlerMBean.java
 *
 * Created on 7. August 2002, 10:01
 */

package org.jconfig.jmx;

/**
 *
 * @author  mecky
 */
public interface ConfigHandlerMBean {
        
    public void setResourceName(String fileName);
    
    public String getResourceName();
        
    public void setConfigurationName(String configName);
    
    public String getConfigurationName();
            
    public void forceReload();
    
    public String showConfiguration();
    
    public void setProperty(String name,String value,String category);
    
    public void saveConfiguration() throws Exception;
    
    public void removeProperty(String name,String category);
            
}
