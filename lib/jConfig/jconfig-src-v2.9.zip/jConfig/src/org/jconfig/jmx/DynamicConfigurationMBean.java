/*
 * DynamicConfiguration.java
 *
 * Created on 3. Mai 2004, 17:05
 */

package org.jconfig.jmx;

/**
 *
 * @author  mecky
 */
public interface DynamicConfigurationMBean {
    
    public void setName(String name);
    
    public String getName();
}
