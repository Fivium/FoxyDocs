package org.jconfig.jmx;

//import org.apache.log4j.Logger;
import java.lang.reflect.Constructor;
import java.util.ArrayList;

import javax.management.Attribute;
import javax.management.AttributeNotFoundException;
import javax.management.DynamicMBean;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanConstructorInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanNotificationInfo;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanParameterInfo;
import javax.management.NotificationBroadcasterSupport;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.RuntimeOperationsException;

import org.jconfig.ConfigurationManager;

/**
 * It is the root MBean of jConfig JMX <br>
 * It creates one ConfigurationDynamicMBean per Configuration it founds <br><br>
 *
 * Has only one operation named "addConfiguration". This operation loads a
 * configuration on memory calling ConfigurationManager.getConfiguration(name)
 * and creates an associated ConfigurationDynamicMBean.
 *
 *@author     Eduardo Macarron emacarron@euskalnet.net
 */

public class ConfigurationManagerDynamicMBean extends AbstractDynamicMBean implements DynamicMBean {
    
    private MBeanConstructorInfo[] dConstructors = new MBeanConstructorInfo[1];
    // only one operation, loadConfiguration
    private MBeanOperationInfo[] dOperations = new MBeanOperationInfo[1];
    
    private NotificationBroadcasterSupport nbs =
    new NotificationBroadcasterSupport();
    
    private ArrayList alAttributes = new ArrayList();
    
    private String dClassName = this.getClass().getName();
    private String dDescription =
    "This MBean acts as a management facade for ConfigurationManager";
    
    private ObjectName objectName;
/*
        private static Logger log =
                Logger.getLogger(ConfigurationManagerDynamicMBean.class);
 */
    public ConfigurationManagerDynamicMBean() {
        try {
            objectName = new ObjectName("user:configuration=DynamicConfiguration");
            buildDynamicMBeanInfo();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
        /*
        public ConfigurationManagerDynamicMBean(ObjectName objectName) {
                buildDynamicMBeanInfo();
                this.objectName = objectName;
        }
         */
    
    private void buildDynamicMBeanInfo() {
        System.out.println("----------------------------------------------------- buildDynamicMBeanInfo()");
        Constructor[] constructors = this.getClass().getConstructors();
        dConstructors[0] =
        new MBeanConstructorInfo(
        "HierarchyDynamicMBean(): Constructs a ConfigurationManagerDynamicMBean instance",
        constructors[0]);
                /*
                dConstructors[1] =
                        new MBeanConstructorInfo(
                                "HierarchyDynamicMBean(): Constructs a ConfigurationManagerDynamicMBean instance",
                                constructors[1]);
                 */
        // parameter information
        // this MBean is able to create new configurations
        
        MBeanParameterInfo[] params = new MBeanParameterInfo[1];
        params[0] =
        new MBeanParameterInfo(
        "name",
        "java.lang.String",
        "Create a Configuration");
        
        dOperations[0] =
            new MBeanOperationInfo(
            "loadConfiguration",
            "loadConfiguration(): loads a Configuration",
            params,
            "javax.management.ObjectName",
            MBeanOperationInfo.ACTION);
        String[] names = ConfigurationManager.getInstance().getConfigurationNames();
        System.out.println("----------------------------------------------------- buildDynamicMBeanInfo loading all configs");
        for ( int i = 0; i < names.length;i++) {
            System.out.println("----------------------------------------------------- buildDynamicMBeanInfo config:"+names[i]);
            loadConfiguration(names[i]);
        }
    }
    
    public void setName(String name) {
        loadConfiguration(name);
    }
    
    public String getName() {
        return "my name";
    }
    // method that adds a ConfigurationMBean
    public ObjectName loadConfiguration(String name) {
        
        System.out.println("loadConfiguration called:"+name);
        
        // test if MBean has been already loaded
        // it can also be tested asking directly to MBeanServer
        for (int i = 0; i < alAttributes.size(); i++) {
            MBeanAttributeInfo mai = (MBeanAttributeInfo) alAttributes.get(i);
            if (mai.getName().equalsIgnoreCase("configuration=" + name))
                return null; // shoud throw an exception??
        }
        
        return registerConfigurationMBean(name);
    }
    
    ObjectName registerConfigurationMBean(String name) {
        
        ObjectName configurationObjectName = null;
        try {
            configurationObjectName =
            new ObjectName(objectName.getDomain(), "configuration", name);
            ConfigurationDynamicMBean configurationMBean =
            new ConfigurationDynamicMBean(configurationObjectName, name);
            server.registerMBean(configurationMBean, configurationObjectName);
            
            // tenemos un atributo nuevo
            alAttributes
            .add(new MBeanAttributeInfo(
            "configuration=" + name,
            "javax.management.ObjectName",
            "The " + name + " configuration.",
            true,
            true,
            // this makes the object clickable
            false));
            
        } catch (Exception e) {
            //log.error(
            //	"Could not add configurationMBean for [" + name + "].",
            //	e);
        }
        return objectName;
    }
/*
        protected Logger getLogger() {
                return log;
        }
 */
    public MBeanInfo getMBeanInfo() {
        
        //log.debug("getMBeanInfo called.");
        
        MBeanAttributeInfo[] attribs =
        new MBeanAttributeInfo[alAttributes.size()];
        alAttributes.toArray(attribs);
        
        return new MBeanInfo(
        dClassName,
        dDescription,
        attribs,
        dConstructors,
        dOperations,
        new MBeanNotificationInfo[0]);
    }
    
    public MBeanNotificationInfo[] getNotificationInfo() {
        return nbs.getNotificationInfo();
    }
    
    public Object invoke(
    String operationName,
    Object params[],
    String signature[])
    throws MBeanException, ReflectionException {
        
        if (operationName == null) {
            throw new RuntimeOperationsException(
            new IllegalArgumentException("Operation name cannot be null"),
            "Cannot invoke a null operation in " + dClassName);
        }
        // Check for a recognized operation name and call the corresponding operation
        if (operationName.equals("loadConfiguration")) {
            return loadConfiguration((String) params[0]);
        } else {
            throw new ReflectionException(
            new NoSuchMethodException(operationName),
            "Cannot find the operation "
            + operationName
            + " in "
            + dClassName);
        }
    }
    
    public Object getAttribute(String attributeName)
    throws AttributeNotFoundException, MBeanException, ReflectionException {
        
        // Check attributeName is not null to avoid NullPointerException later on
        if (attributeName == null) {
            throw new RuntimeOperationsException(
            new IllegalArgumentException("Attribute name cannot be null"),
            "Cannot invoke a getter of "
            + dClassName
            + " with null attribute name");
        }
        
        //log.debug("Called getAttribute with [" + attributeName + "].");
        
        // Check for a recognized attributeName and call the corresponding getter
        if (attributeName.startsWith("configuration")) {
            try {
                return new ObjectName(
                objectName.getDomain() + ":" + attributeName);
            } catch (Exception e) {
                e.printStackTrace();
                            /*
                                log.error(
                                        "Could not create ObjectName "
                                                + objectName.getDomain()
                                                + ":"
                                                + attributeName);
                             */
            }
        }
        
        // If attributeName has not been recognized throw an AttributeNotFoundException
        throw (
        new AttributeNotFoundException(
        "Cannot find "
        + attributeName
        + " attribute in "
        + dClassName));
    }
    
    public void postRegister(java.lang.Boolean registrationDone) {
        // called when registration is done
        // here we have to get every Configuration object and add it to Va
        
        //log.debug("postRegister is called.");
        
        ConfigurationManager configMngr = ConfigurationManager.getInstance();
        String[] configNames = configMngr.getConfigurationNames();
        for (int i = 0; i < configNames.length; i++) {
            registerConfigurationMBean(configNames[i]);
        }
    }
    
    public void setAttribute(Attribute attribute)
    throws
    AttributeNotFoundException,
    InvalidAttributeValueException,
    MBeanException,
    ReflectionException {
        
        // Check attribute is not null to avoid NullPointerException later on
        if (attribute == null) {
            throw new RuntimeOperationsException(
            new IllegalArgumentException("Attribute cannot be null"),
            "Cannot invoke a setter of "
            + dClassName
            + " with null attribute");
        }        
        String name = attribute.getName();
        Object value = attribute.getValue();
        System.out.println("-------------------------------------------set:"+name+" value:"+value);
        if (name == null) {
            throw new RuntimeOperationsException(
            new IllegalArgumentException("Attribute name cannot be null"),
            "Cannot invoke the setter of "
            + dClassName
            + " with null attribute name");
        }
    }
}
